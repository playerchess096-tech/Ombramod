import sys
from audiolib import *
from gen_sfx import thump_layer

def tine(f, dur=2.2, vel=1.0, r=None):
    tt = T(dur)
    x = (np.sin(2 * np.pi * f * tt) * np.exp(-tt * 3.2)
         + 0.45 * np.sin(2 * np.pi * f * 2.76 * tt) * np.exp(-tt * 8)
         + 0.18 * np.sin(2 * np.pi * f * 5.4 * tt) * np.exp(-tt * 15))
    x += 0.15 * np.exp(-tt * 120) * np.sin(2 * np.pi * f * 7.1 * tt)
    return x * vel

def midi(n): return 440.0 * 2 ** ((n - 69) / 12.0)

def music_box_track(d, progression, seed, droop=0.14, wrong=0.12, tempo=0.43):
    r = rngs(seed); n = int(d * SR)
    L = np.zeros(n); R = np.zeros(n); t = 0.0; bar = 0
    while t < d - 3.0:
        chord = progression[bar % len(progression)]
        pattern = [0, 1, 2, 3, 2, 1] if bar % 2 == 0 else [0, 2, 1, 3, 1, 2]
        for k, idx in enumerate(pattern):
            prog = t / d
            slow = 1.0 - droop * prog ** 2
            note = chord[idx % len(chord)]
            if r.random() < wrong * prog: note += int(r.choice([1, -1, 6]))
            f = midi(note) * slow * (1 + 0.003 * r.standard_normal())
            s = tine(f, 2.4, vel=0.55 + 0.25 * r.random())
            pan = 0.5 + 0.35 * np.sin(t * 0.9)
            place(L, s * (1 - pan) * 1.4, t); place(R, s * pan * 1.4, t)
            t += tempo / slow
        bar += 1
    L = reverb(L, 2.6, 0.5, seed=seed)[:n]; R = reverb(R, 2.6, 0.5, seed=seed + 1)[:n]
    tt = T(d); tick = (r.random(n) > 0.9992) * r.standard_normal(n) * 0.04
    L += bp(tick, 2000, 6000, 2); R += bp(np.roll(tick, 300), 2000, 6000, 2)
    return L, R

def finish(L, R, peak=0.9, fin=1.5, fout=3.0):
    x = np.stack([L, R], axis=1)
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    for c in (0, 1): x[:, c] = fade(x[:, c], fin, fout)
    return x

def drone_isolation(d=72):
    n = int(d * SR); tt = T(d); L = np.zeros(n); R = np.zeros(n)
    tin = np.sin(phase(8300 + 12 * np.sin(2 * np.pi * 0.07 * tt))) * 0.035 * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 23.0 - 1.0))
    sub = (np.sin(2 * np.pi * 38 * tt) + np.sin(2 * np.pi * 38.6 * tt)) * 0.18 * (0.6 + 0.4 * np.sin(2 * np.pi * tt / 13))
    for ch, seed in ((L, 1), (R, 2)):
        wind = tv_filter(noise(d, rngs(seed * 17)), lambda t: 350 + 220 * np.sin(2 * np.pi * t / 19.0) + 100 * np.sin(2 * np.pi * t / 7.3), q=1.2) * 0.30
        wind *= 0.55 + 0.45 * np.sin(2 * np.pi * tt / 11.0 + seed)
        ch += wind
    L += tin + sub; R += tin * 0.9 + sub
    r = rngs(55)
    for _ in range(7):
        t0 = r.uniform(4, d - 6); pan = r.uniform(0.15, 0.85)
        k = np.zeros(int(1.5 * SR))
        for j in range(3): thump_layer(k, 0.0 + j * 0.19, 140, 70, 0.5, 20, r)
        k = reverb(lp(k, 300), 1.4, 0.45)
        place(L, k * (1 - pan) * 0.6, t0); place(R, k * pan * 0.6, t0)
    return finish(L, R)

def drone_sky(d=75):
    n = int(d * SR); tt = T(d); r = rngs(77); L = np.zeros(n); R = np.zeros(n)
    for ch, sd in ((L, 0), (R, 1)):
        stack = np.zeros(n)
        for f, a in ((55.0, 1.0), (77.8, 0.8), (110.0, 0.6), (155.6, 0.4)):
            for det in (-0.004, 0.0, 0.004):
                stack += a * signal.sawtooth(phase(np.full(n, f * (1 + det + 0.001 * sd)))) * 0.12
        stack = tv_filter(stack, lambda t: 250 + 400 * (0.5 + 0.5 * np.sin(2 * np.pi * t / 21.0)), kind="low")
        stack *= 0.55 + 0.45 * np.sin(2 * np.pi * tt / 14.0 + sd)
        ch += stack
        choir = np.zeros(n)
        for f in (880.0, 1244.5, 1760.0):
            choir += np.sin(phase(f + 6 * np.sin(2 * np.pi * tt / (9 + 2 * sd)))) * 0.02
        ch += choir * (0.4 + 0.6 * np.sin(2 * np.pi * tt / 17 + 2 * sd) ** 2)
    for _ in range(6):
        t0 = r.uniform(2, d - 8); pan = r.uniform(0.2, 0.8); ln = r.uniform(3.0, 5.5)
        rm = lp(noise(ln, r), 120, 3) * 4.0 * np.sin(np.pi * np.clip(T(ln) / ln, 0, 1)) ** 1.5
        place(L, rm * (1 - pan), t0); place(R, rm * pan, t0)
    return finish(L, R)

def drone_memory(d=70):
    L, R = music_box_track(d, [[57, 60, 64, 69], [55, 59, 62, 67], [53, 57, 60, 65], [52, 56, 59, 64]], 303, droop=0.22, wrong=0.22, tempo=0.9)
    n = int(d * SR); tt = T(d)
    pad = (np.sin(2 * np.pi * 110 * tt) + np.sin(2 * np.pi * 130.8 * tt) + np.sin(2 * np.pi * 164.8 * tt)) * 0.06 * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 15))
    r = rngs(404); wh = tv_filter(noise(d, r), lambda t: 1500 + 800 * np.sin(2 * np.pi * t / 9), q=3) * 0.05 * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 6.5))
    return finish(L + pad + wh, R + pad * 0.9 + np.roll(wh, 4000))

def drone_hunt(d=68):
    n = int(d * SR); tt = T(d); r = rngs(909); L = np.zeros(n); R = np.zeros(n)
    t = 1.0
    while t < d - 2:
        prog = t / d; bpm = 58 + 52 * prog
        k = np.zeros(int(0.7 * SR)); thump_layer(k, 0.0, 85, 36, 1.0, 10, r); thump_layer(k, 0.22, 95, 44, 0.6, 12, r)
        place(L, k * (0.5 + 0.4 * prog), t); place(R, k * (0.5 + 0.4 * prog), t)
        t += 60.0 / bpm
    f = 73.4 * (1 + 0.26 * (tt / d))
    for ch, sd in ((L, 0), (R, 1)):
        s = signal.sawtooth(phase(f * (1 + 0.003 * sd))) + signal.sawtooth(phase(f * 1.5 * (1 - 0.003 * sd))) * 0.6
        s = tv_filter(s, lambda t: 200 + 900 * (t / d), kind="low") * 0.18 * (tt / d) ** 0.7
        ch += np.tanh(s * 2.0)
    for _ in range(9):
        t0 = r.uniform(5, d - 6); ln = r.uniform(0.8, 1.8); pan = r.uniform(0.15, 0.85)
        sc = tv_filter(noise(ln, r), lambda t: 900 + 3500 * t / ln, q=6) * 0.5 * np.sin(np.pi * np.clip(T(ln) / ln, 0, 1))
        place(L, sc * (1 - pan), t0); place(R, sc * pan, t0)
    return finish(L, R, fout=2.0)

def victory(d=22):
    n = int(d * SR); tt = T(d); L = np.zeros(n); R = np.zeros(n); r = rngs(1001)
    env = np.minimum(1, tt / 6.0) * np.clip((d - tt) / 4.0, 0, 1)
    for f, a in ((73.4, 0.8), (110.0, 0.7), (146.8, 0.7), (185.0, 0.6), (220.0, 0.6), (293.7, 0.5), (370.0, 0.35), (440.0, 0.3)):
        for ch, det in ((L, -0.0015), (R, 0.0015)):
            ch += np.sin(phase(np.full(n, f * (1 + det))) + 0.5 * np.sin(2 * np.pi * 0.2 * tt)) * a * 0.09 * env
    for t0 in (6.0, 9.5, 12.5, 15.5):
        for k in range(3):
            ln = 0.18; q = T(ln)
            ch = np.sin(phase(3600 + 1800 * (q / ln) + 400 * np.sin(2 * np.pi * 30 * q))) * np.sin(np.pi * q / ln) * 0.12
            pan = r.uniform(0.2, 0.8)
            place(L, ch * (1 - pan), t0 + k * 0.28); place(R, ch * pan, t0 + k * 0.28)
    for t0, m in ((2.0, 74), (8.0, 78), (11.0, 81), (14.0, 86)):
        s = tine(midi(m), 3.0, 0.4); place(L, s, t0); place(R, s * 0.9, t0)
    L = reverb(L, 3.0, 0.35, seed=1)[:n]; R = reverb(R, 3.0, 0.35, seed=2)[:n]
    return finish(L, R, fin=1.0, fout=4.0)

def ending_alt(d=26):
    L, R = music_box_track(d, [[57, 61, 64, 69], [59, 62, 66, 71], [54, 57, 61, 66], [56, 59, 63, 68]], 2002, droop=0.0, wrong=0.0, tempo=0.62)
    n = int(d * SR); tt = T(d); r = rngs(2003)
    pad = np.zeros(n)
    for f in (110.0, 138.6, 164.8, 220.0, 277.2):
        pad += np.sin(phase(np.full(n, f)) + 0.4 * np.sin(2 * np.pi * 0.13 * tt)) * 0.05
    pad *= np.minimum(1, tt / 5.0) * np.clip((d - tt) / 6.0, 0, 1)
    air = tv_filter(noise(d, r), lambda t: 2200 + 500 * np.sin(2 * np.pi * t / 8), q=2) * 0.03 * np.minimum(1, tt / 8)
    return finish(L + pad + air, R + pad + np.roll(air, 5000), fin=1.0, fout=4.0)

if __name__ == "__main__":
    which = sys.argv[1:] or ["all"]
    jobs = {"drone_isolation": drone_isolation, "drone_sky": drone_sky, "drone_memory": drone_memory,
            "drone_hunt": drone_hunt, "victory": victory, "ending_alt": ending_alt}
    mb = lambda: music_box_track(36, [[57, 60, 64, 69], [55, 59, 62, 67], [53, 57, 60, 65], [52, 56, 59, 64]], 123)
    tot = 0
    names = list(jobs.keys()) + ["music_box"] if which == ["all"] else which
    for nm in names:
        x = finish(*mb()) if nm == "music_box" else jobs[nm]()
        assert np.isfinite(x).all(), nm
        s = save(nm, x, stereo=True, q=4); tot += s
        print(f"{nm:16s} {len(x)/SR:5.1f}s  {s/1024:8.1f} KB", flush=True)
    print("TOTALE KB:", round(tot / 1024, 1))
