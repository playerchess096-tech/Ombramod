import numpy as np, subprocess, os, wave
from scipy import signal

SR = 44100
OUT = "/home/claude/OmbraMod/src/main/resources/assets/ombra/sounds"
os.makedirs(OUT, exist_ok=True)

def T(d): return np.arange(int(d * SR)) / SR
def rngs(seed): return np.random.default_rng(seed)
def noise(d, r): return r.standard_normal(int(d * SR))

def _sos(kind, fc, order):
    if kind == "bp":
        lo, hi = fc
        return signal.butter(order, [max(lo, 10), min(hi, SR / 2 - 200)], "band", fs=SR, output="sos")
    return signal.butter(order, min(fc, SR / 2 - 200), kind, fs=SR, output="sos")

def lp(x, fc, order=4): return signal.sosfilt(_sos("low", fc, order), x)
def hp(x, fc, order=4): return signal.sosfilt(_sos("high", fc, order), x)
def bp(x, lo, hi, order=2): return signal.sosfilt(_sos("bp", (lo, hi), order), x)

def norm(x, peak=0.9):
    return x / (np.max(np.abs(x)) + 1e-9) * peak

def fade(x, fin=0.005, fout=0.05):
    x = x.copy(); n = len(x)
    a = min(int(fin * SR), n // 2); b = min(int(fout * SR), n // 2)
    if a > 0: x[:a] *= np.linspace(0, 1, a)
    if b > 0: x[-b:] *= np.linspace(1, 0, b)
    return x

def reverb(x, rt=1.2, wet=0.25, seed=5, damp=5000):
    r = rngs(seed); n = int(rt * SR)
    ir = r.standard_normal(n) * np.exp(-np.arange(n) / (SR * rt / 6.0))
    ir = lp(ir, damp, 2); ir /= np.sqrt(np.sum(ir ** 2)) + 1e-9
    y = signal.fftconvolve(x, ir)
    out = np.zeros(len(y)); out[:len(x)] += x * (1 - wet); out += y * wet * 1.4
    return out

def tv_filter(x, fc_fn, q=2.0, kind="bp", block=1024):
    out = np.zeros_like(x); zi = np.zeros(2)
    for i in range(0, len(x), block):
        seg = x[i:i + block]
        fc = float(np.clip(fc_fn(i / SR), 40, SR / 2 - 600))
        if kind == "bp": b, a = signal.iirpeak(fc, q, fs=SR)
        else: b, a = signal.butter(2, fc, "low", fs=SR)
        y, zi = signal.lfilter(b, a, seg, zi=zi)
        out[i:i + len(seg)] = y
    return out

def phase(f): return 2 * np.pi * np.cumsum(f) / SR

def bitcrush(x, bits=5, hold=4):
    q = 2 ** bits
    x = np.round(x * q) / q
    if hold > 1: x = np.repeat(x[::hold], hold)[:len(x)]
    return x

def place(out, snip, t0):
    i = int(t0 * SR)
    if i >= len(out): return
    m = min(len(snip), len(out) - i)
    out[i:i + m] += snip[:m]

def save(name, x, stereo=False, q=4):
    x = np.clip(x, -1, 1)
    wavp = f"/tmp/{name}.wav"
    data = (x * 32767).astype(np.int16)
    with wave.open(wavp, "wb") as w:
        w.setnchannels(2 if stereo else 1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(data.tobytes())
    out = os.path.join(OUT, name + ".ogg")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", wavp, "-c:a", "libvorbis",
                    "-q:a", str(q), "-ac", "2" if stereo else "1", out], check=True)
    os.remove(wavp)
    return os.path.getsize(out)
