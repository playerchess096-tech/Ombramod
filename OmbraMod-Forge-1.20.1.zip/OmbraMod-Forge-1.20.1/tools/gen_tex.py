import numpy as np, math, random
from PIL import Image, ImageDraw, ImageFilter, ImageChops

BASE = "/home/claude/OmbraMod/src/main/resources/assets/ombra/textures/"
rng = np.random.default_rng(42); rnd = random.Random(42)

# ---------- Entità: UV 64x64 stile humanoid ----------
REG = {  # (x0,y0,x1,y1) inclusivi di tutte le facce di ogni parte
    "head": (0, 0, 31, 15), "body": (16, 16, 39, 31), "rarm": (40, 16, 55, 31),
    "rleg": (0, 16, 15, 31), "larm": (32, 48, 47, 63), "lleg": (16, 48, 31, 63),
}
def shadow():
    a = np.zeros((64, 64, 4), np.uint8)
    for name, (x0, y0, x1, y1) in REG.items():
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                v = 10 + int(rng.integers(-3, 5)); g = 0
                if rng.random() < 0.07: v += int(rng.integers(8, 22))        # sfilacciature chiare
                if name in ("larm", "rarm", "lleg", "rleg") and (y - y0) > 8 and rng.random() < 0.18:
                    v += 12                                                    # bordi sfilacciati
                a[y, x] = (v, v, v + 5 + g, 255)
    # volto: leggermente più chiaro al centro, occhi incavati neri
    for y in range(8, 16):
        for x in range(8, 16):
            d = abs(x - 11.5) + abs(y - 11.5) * 0.7
            v = int(24 - d * 2.2) + int(rng.integers(-2, 3))
            a[y, x] = (max(8, v), max(8, v), max(10, v + 4), 255)
    for ex in ((9, 10), (13, 14)):
        for x in ex:
            for y in (11, 12): a[y, x] = (0, 0, 0, 255)
    for x in (10, 11, 12, 13): a[14, x] = (4, 2, 3, 255)     # bocca sottile
    Image.fromarray(a, "RGBA").save(BASE + "entity/shadow.png")

def eyes(name, core, halo):
    a = np.zeros((64, 64, 4), np.uint8)
    pts = [(9, 11), (10, 11), (9, 12), (10, 12), (13, 11), (14, 11), (13, 12), (14, 12)]
    for (x, y) in pts:
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                xx, yy = x + dx, y + dy
                if 8 <= xx <= 15 and 8 <= yy <= 15 and a[yy, xx, 3] == 0: a[yy, xx] = (*halo, 95)
    for (x, y) in pts: a[y, x] = (*core, 255)
    Image.fromarray(a, "RGBA").save(BASE + f"entity/{name}.png")

# ---------- Jumpscare ----------
def noisy_ellipse(cx, cy, rx, ry, jit, n=90):
    pts = []
    for i in range(n):
        t = 2 * math.pi * i / n
        j = 1 + rnd.uniform(-jit, jit)
        pts.append((cx + math.cos(t) * rx * j, cy + math.sin(t) * ry * j))
    return pts

def jumpscare(idx):
    S = 1024; im = Image.new("RGB", (S, S), (0, 0, 0)); d = ImageDraw.Draw(im)
    for r in range(520, 0, -8):                                   # alone rosso scuro dietro la testa
        c = int(40 * (1 - r / 520) ** 1.6); d.ellipse((512 - r, 520 - r, 512 + r, 520 + r), fill=(c, 0, 0))
    cx, cy = 512, 560 + idx * 12
    for k in range(40):                                           # testa con ombreggiatura
        s = 1 - k / 40; col = int(28 + 150 * (k / 40) ** 1.3 * (0.9 + 0.1 * idx))
        d.polygon(noisy_ellipse(cx, cy - k * 1.2, 330 * s + 10, 450 * s + 10, 0.015), fill=(col, col - 4, col - 6))
    for _ in range(9):                                            # crepe
        x, y = cx + rnd.randint(-150, 150), cy - 380
        pts = [(x, y)]
        for _ in range(9): x += rnd.randint(-45, 45); y += rnd.randint(30, 70); pts.append((x, y))
        d.line(pts, fill=(18, 14, 14), width=rnd.randint(3, 7))
    ey = 470 + idx * 10
    for sx in (-1, 1):                                            # orbite
        ex = cx + sx * 135
        d.polygon([(ex - 95, ey + 10), (ex - 20, ey - 55 + idx * 8), (ex + 70, ey - 25), (ex + 95 * sx * -1 + 0, ey + 35), (ex + 5, ey + 70)], fill=(0, 0, 0))
        if idx == 0: d.ellipse((ex - 13, ey - 4, ex + 13, ey + 22), fill=(245, 245, 245))
        if idx == 1:
            d.ellipse((ex - 60, ey - 30, ex + 60, ey + 50), fill=(235, 235, 240)); d.ellipse((ex - 9, ey + 2, ex + 9, ey + 24), fill=(0, 0, 0))
        if idx == 2:
            for t in range(5): d.line([(ex - 40 + t * 20, ey + 60), (ex - 44 + t * 20 + rnd.randint(-6, 6), ey + 200 + rnd.randint(0, 120))], fill=(8, 6, 6), width=6)
            d.ellipse((ex - 6, ey + 6, ex + 6, ey + 18), fill=(250, 250, 250))
    d.polygon([(cx - 14, 640), (cx - 3, 700), (cx - 28, 690)], fill=(10, 8, 8)); d.polygon([(cx + 14, 640), (cx + 3, 700), (cx + 28, 690)], fill=(10, 8, 8))
    top, bot = 780, 960 + idx * 20                                 # bocca
    d.polygon(noisy_ellipse(cx, (top + bot) // 2, 235, (bot - top) // 2, 0.03, 60), fill=(0, 0, 0))
    n = 11
    for i in range(n):
        x = cx - 200 + i * 400 / (n - 1); h = rnd.randint(45, 95)
        d.polygon([(x - 17, top + 12), (x + 17, top + 12), (x + rnd.randint(-5, 5), top + 12 + h)], fill=(225, 220, 205))
        h2 = rnd.randint(35, 80)
        d.polygon([(x - 15, bot - 12), (x + 15, bot - 12), (x + rnd.randint(-5, 5), bot - 12 - h2)], fill=(215, 210, 195))
    im = im.resize((512, 512), Image.LANCZOS).filter(ImageFilter.GaussianBlur(0.9))
    a = np.asarray(im).astype(np.float32)
    a += rng.normal(0, 14, a.shape)                                # grana
    a[::4, :, :] *= 0.86                                           # scanline
    a[:, :, 0] = np.roll(a[:, :, 0], 4, axis=1); a[:, :, 2] = np.roll(a[:, :, 2], -4, axis=1)   # aberrazione cromatica
    yy, xx = np.mgrid[0:512, 0:512]; vig = 1 - 0.65 * (((xx - 256) ** 2 + (yy - 256) ** 2) / (256 ** 2 * 2)) ** 1.2
    a *= vig[:, :, None]
    Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").save(BASE + f"gui/jumpscare_{idx}.png", optimize=True)

# ---------- Oggetti 16x16 ----------
def item_page():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rectangle((3, 1, 12, 14), fill=(222, 206, 170), outline=(70, 52, 34))
    for p in ((3, 1), (4, 1), (12, 14), (11, 14), (12, 13), (7, 1), (10, 1), (3, 14)): im.putpixel(p, (0, 0, 0, 0))
    for y, xs in ((4, (5, 6, 7, 9, 10)), (6, (5, 6, 8, 9, 10, 11)), (8, (5, 7, 8, 9, 11))):
        for x in xs: im.putpixel((x, y), (112, 86, 56, 255))
    for p in ((9, 10), (10, 10), (10, 11), (9, 11), (11, 11), (10, 12)): im.putpixel(p, (122, 14, 16, 255))
    im.save(BASE + "item/torn_page.png")

def item_shard():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.polygon([(8, 0), (12, 5), (10, 14), (7, 15), (4, 10), (5, 4)], fill=(22, 16, 36), outline=(70, 46, 104))
    for p in ((7, 2), (7, 4), (6, 6), (6, 8)): im.putpixel(p, (130, 96, 180, 255))
    for p in ((8, 7), (9, 9), (8, 10)): im.putpixel(p, (96, 0, 130, 255))
    im.save(BASE + "item/black_shard.png")

def item_symbol():
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0)); d = ImageDraw.Draw(im)
    d.rectangle((2, 2, 13, 13), fill=(62, 62, 68), outline=(26, 26, 32))
    for _ in range(14): im.putpixel((rnd.randint(3, 12), rnd.randint(3, 12)), (80, 80, 88, 255))
    red = (196, 20, 32, 255)
    d.line([(8, 4), (4, 11)], fill=red); d.line([(8, 4), (12, 11)], fill=red); d.line([(4, 11), (12, 11)], fill=red)
    im.putpixel((8, 8), (250, 230, 230, 255)); im.putpixel((8, 9), red)
    im.save(BASE + "item/unknown_symbol.png")

def item_heart():
    art = ["................", "................", "...KKKK....KKKK.", "..KRRRRK..KRRRRK", ".KRRrrRRKKRRRRRK",
           ".KRrWrRRRRRRRRRK", ".KRrrRRRRRRRRRRK", ".KRRRRRRRRRRRRRK", "..KRRRRRRRRRRRK.", "...KRRRRRRRRRK..",
           "....KRRRRRRRK...", ".....KRRRRRK....", "......KRRRK.....", ".......KRK......", "........K.......", "................"]
    pal = {"K": (14, 0, 6, 255), "R": (122, 8, 24, 255), "r": (176, 26, 42, 255), "W": (236, 130, 140, 255)}
    im = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    for y, row in enumerate(art):
        assert len(row) == 16, (y, row)
        for x, c in enumerate(row):
            if c in pal: im.putpixel((x, y), pal[c])
    for p in ((8, 6), (8, 7), (9, 8), (7, 9), (8, 10)): im.putpixel(p, (44, 0, 12, 255))   # vene scure
    im.save(BASE + "item/shadow_heart.png")

if __name__ == "__main__":
    shadow()
    eyes("shadow_eyes", (255, 255, 255), (200, 220, 255))
    eyes("shadow_eyes_red", (255, 30, 30), (255, 0, 0))
    eyes("shadow_eyes_blue", (130, 210, 255), (60, 140, 255))
    for i in range(3): jumpscare(i)
    item_page(); item_shard(); item_symbol(); item_heart()
    print("texture ok")
