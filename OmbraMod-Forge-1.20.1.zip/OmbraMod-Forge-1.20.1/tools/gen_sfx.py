from audiolib import *

def thump_layer(out, t0, f0, f1, amp, dec, r):
    tt = T(0.5)
    f = f1 + (f0 - f1) * np.exp(-tt * 22)
    s = np.sin(phase(f)) * np.exp(-tt * dec)
    click = lp(noise(0.5, r), 220) * np.exp(-tt * 70) * 0.6
    place(out, (s + click) * amp, t0)

def heartbeat():
    r = rngs(1); out = np.zeros(int(1.1 * SR))
    thump_layer(out, 0.02, 78, 40, 1.0, 11, r)
    thump_layer(out, 0.31, 92, 46, 0.7, 13, r)
    out = reverb(lp(out, 420), 0.6, 0.15)
    return fade(norm(out, 0.92), 0.002, 0.1)

def whisper(seed, d=3.4):
    r = rngs(seed); n = int(d * SR); tt = T(d)
    base = noise(d, r); env = np.zeros(n); pos = 0.2
    while pos < d - 0.5:
        ln = r.uniform(0.10, 0.34); amp = r.uniform(0.45, 1.0)
        i0 = int(pos * SR); i1 = min(n, int((pos + ln) * SR))
        if i1 - i0 > 4: env[i0:i1] += np.hanning(i1 - i0) ** 1.4 * amp
        pos += ln + r.uniform(0.02, 0.2)
    f1 = bp(base, 450, 850) * 0.7; f2 = bp(base, 1200, 2100); f3 = bp(base, 2500, 3800) * 0.8; f4 = hp(base, 5500) * 0.5
    m1 = 0.6 + 0.4 * np.sin(2 * np.pi * r.uniform(0.6, 1.4) * tt + r.uniform(0, 6.28))
    m2 = 0.6 + 0.4 * np.sin(2 * np.pi * r.uniform(0.8, 1.8) * tt + r.uniform(0, 6.28))
    x = (f1 * m1 + f2 * m2 + f3 + f4) * env
    return fade(norm(reverb(x, 1.6, 0.4, seed=seed), 0.85), 0.01, 0.25)

def formants(x, A, B, m):
    ya = sum(g * bp(x, lo, hi, 2) for lo, hi, g in A)
    yb = sum(g * bp(x, lo, hi, 2) for lo, hi, g in B)
    return ya * (1 - m) + yb * m

def scream():
    r = rngs(7); d = 3.2; n = int(d * SR); tt = T(d)
    rise = np.clip(tt / 1.0, 0, 1); fall = np.clip((tt - 1.6) / 1.6, 0, 1)
    f0 = 430 + 520 * np.sin(0.5 * np.pi * rise) ** 1.3 - 420 * fall
    f0 = f0 + 28 * np.sin(2 * np.pi * 7.2 * tt) + 45 * np.sin(2 * np.pi * 12.5 * tt) * np.clip(tt / 0.4, 0, 1)
    f0 = f0 * (1 + 0.32 * lp(noise(d, r), 40, 2))
    ph = phase(f0)
    src = signal.sawtooth(ph) + 0.55 * signal.sawtooth(2 * ph + 0.7) + 0.35 * signal.sawtooth(0.5 * ph + 1.9)
    m = np.clip(tt / d * 1.4, 0, 1)
    A = [(600, 1000, 1.0), (1300, 1800, 0.8), (2500, 3300, 0.6)]
    B = [(300, 500, 1.0), (2000, 2600, 0.9), (3200, 4200, 0.6)]
    v = formants(src, A, B, m)
    breath = bp(noise(d, r), 2500, 9000, 2) * 0.5
    env = np.minimum(1, tt / 0.015) * np.exp(-np.clip(tt - 2.0, 0, None) * 2.2) * (0.88 + 0.12 * np.sin(2 * np.pi * 11 * tt))
    x = (v + breath) * env
    x = np.tanh(x / (np.max(np.abs(x)) + 1e-9) * 3.9)
    sub = np.sin(phase(70 - 35 * np.clip(tt / 0.8, 0, 1))) * np.exp(-tt * 4) * 0.9
    x = reverb(x * 0.75 + sub * 0.5, 0.9, 0.18)
    return fade(norm(x, 0.97), 0.001, 0.2)

def static_burst(d=1.4):
    r = rngs(3); n = int(d * SR); x = np.zeros(n); pos = 0
    while pos < n:
        ln = int(r.uniform(0.005, 0.06) * SR); gap = int(r.uniform(0.002, 0.05) * SR)
        seg = r.standard_normal(ln) * r.uniform(0.3, 1.0)
        if r.random() < 0.35: seg = np.sign(seg) * 0.7
        m = min(ln, n - pos); x[pos:pos + m] = seg[:m]; pos += ln + gap
    x = bp(bitcrush(x, 5, 6), 300, 9000)
    tone = np.sin(phase(2000 + 1500 * np.sin(2 * np.pi * 3 * T(d)))) * 0.15 * (r.random(n) > 0.7)
    return fade(norm(x + tone, 0.9), 0.003, 0.05)

def door_creak(d=2.4):
    r = rngs(9); n = int(d * SR); tt = T(d)
    f = 140 + 90 * np.sin(2 * np.pi * 0.45 * tt) ** 2 + 260 * np.clip(tt / d, 0, 1) ** 2
    f = f * (1 + 0.6 * lp(noise(d, r), 30, 2))
    s = signal.sawtooth(phase(f), 0.3)
    am = lp(0.5 + 0.5 * np.sign(np.sin(phase(18 + 10 * np.sin(2 * np.pi * 0.8 * tt)))), 120, 2)
    sq = np.sin(phase(900 + 500 * np.sin(2 * np.pi * 0.6 * tt) + 300 * tt)) * 0.25
    x = (s * am * 0.8 + sq * am) * (np.sin(np.pi * np.clip(tt / d, 0, 1)) ** 0.6)
    x = np.tanh(bp(x, 180, 3500, 2) * 2.0)
    return fade(norm(reverb(x, 0.9, 0.2), 0.9), 0.01, 0.15)

def bell(f0=170, d=7.0):
    r = rngs(11); tt = T(d)
    ratios = [0.5, 1, 1.19, 1.56, 2.0, 2.51, 3.0, 4.1, 5.4]
    amps = [0.5, 1, 0.6, 0.5, 0.4, 0.3, 0.25, 0.15, 0.1]
    decs = [0.35, 0.5, 0.7, 0.8, 1.0, 1.3, 1.5, 2.0, 2.6]
    x = np.zeros(len(tt))
    for k, (rt, a, dc) in enumerate(zip(ratios, amps, decs)):
        x += a * np.sin(2 * np.pi * f0 * rt * tt + k) * np.exp(-tt * dc)
        x += 0.5 * a * np.sin(2 * np.pi * (f0 * rt + 0.7 + 0.2 * k) * tt) * np.exp(-tt * dc)
    x += bp(noise(d, r), 800, 4000, 2) * np.exp(-tt * 40) * 0.8
    return fade(norm(reverb(x, 2.2, 0.3), 0.9), 0.001, 0.4)

def thump(d=1.7):
    r = rngs(13); tt = T(d)
    x = np.sin(phase(26 + 60 * np.exp(-tt * 9))) * np.exp(-tt * 3.2)
    x += lp(noise(d, r), 160) * np.exp(-tt * 8) * 1.2
    return fade(norm(reverb(np.tanh(x * 1.8), 1.0, 0.2), 0.95), 0.001, 0.2)

def riser(d=4.5):
    r = rngs(15); tt = T(d); p = tt / d
    nz = tv_filter(noise(d, r), lambda t: 200 + 7500 * (t / d) ** 2, 1.8) * 2.2
    saw = signal.sawtooth(phase(80 + 330 * p ** 2)) * 0.5 + signal.sawtooth(phase(82 + 335 * p ** 2)) * 0.5
    x = (nz + lp(saw, 2500, 2) * 0.8) * (p ** 2.2) * (1 + 0.3 * np.sin(2 * np.pi * (3 + 9 * p) * tt))
    x = np.tanh(x * 1.2)
    return fade(norm(x, 0.9), 0.02, 0.01)

def breath(d=6.5):
    r = rngs(17); n = int(d * SR); tt = T(d)
    env = np.zeros(n)
    for t0, ln, a in ((0.4, 1.3, 0.7), (1.9, 1.7, 1.0), (4.0, 1.2, 0.6), (5.3, 1.0, 0.8)):
        i0 = int(t0 * SR); i1 = min(n, int((t0 + ln) * SR))
        env[i0:i1] += np.hanning(i1 - i0) ** 1.3 * a
    base = noise(d, r)
    x = (bp(base, 500, 3500, 2) + 0.6 * bp(base, 150, 400, 2)) * env
    x *= 0.7 + 0.3 * np.sin(2 * np.pi * 33 * tt)
    return fade(norm(reverb(x, 1.0, 0.2), 0.8), 0.02, 0.2)

def growl(d=2.6):
    r = rngs(19); n = int(d * SR); tt = T(d)
    f = (64 - 10 * tt / d) * (1 + 0.08 * np.sin(2 * np.pi * 28 * tt))
    s = signal.sawtooth(phase(f)) + 0.5 * signal.sawtooth(phase(f * 2.01))
    x = lp(s, 700, 3) + lp(noise(d, r), 900, 2) * 0.35
    x *= np.sin(np.pi * np.clip(tt / d, 0, 1)) ** 0.7
    return fade(norm(reverb(np.tanh(x * 1.5), 0.8, 0.2), 0.9), 0.02, 0.15)

def shadow_hurt(d=0.9):
    r = rngs(21); tt = T(d)
    f = 950 - 650 * np.clip(tt / d, 0, 1) ** 0.7 + 40 * np.sin(2 * np.pi * 30 * tt)
    s = signal.sawtooth(phase(f)) + 0.5 * signal.sawtooth(phase(f * 1.5))
    x = bp(s, 400, 4000, 2) * np.exp(-tt * 3.0) + bp(noise(d, r), 1500, 6000, 2) * np.exp(-tt * 9) * 0.5
    x = np.tanh(x * 2.8)
    return fade(norm(reverb(x, 0.5, 0.15), 0.95), 0.002, 0.1)

def shadow_death(d=5.6):
    r = rngs(23); tt = T(d); p = tt / d
    f = 430 * np.exp(-p * 2.1) + 50 + 14 * np.sin(2 * np.pi * 5.5 * tt)
    s = signal.sawtooth(phase(f)) + 0.6 * signal.sawtooth(phase(f * 0.5))
    x = lp(s, 1800, 2) * np.exp(-p * 1.2)
    x += bp(noise(d, r), 300, 5000, 2) * (np.exp(-p * 4) * 0.6 + 0.2 * np.exp(-((p - 0.8) ** 2) / 0.01))
    x = np.tanh(x * 1.6)
    return fade(norm(reverb(x, 2.0, 0.35), 0.95), 0.003, 0.5)

def teleport(d=1.3):
    r = rngs(25); tt = T(d); p = tt / d
    nz = tv_filter(noise(d, r), lambda t: 8000 * np.exp(-3.5 * t / d) + 200, 1.4) * 2.0
    s = np.sin(phase(1500 * np.exp(-3.2 * p) + 70))
    x = (nz * 0.7 + s * 0.5) * np.sin(np.pi * np.clip(p, 0, 1)) ** 0.5
    return fade(norm(reverb(x, 0.8, 0.25), 0.9), 0.005, 0.15)

def glitch(d=1.2):
    r = rngs(27); n = int(d * SR); x = np.zeros(n); pos = 0
    while pos < n:
        ln = int(r.uniform(0.01, 0.07) * SR); f = r.uniform(120, 3500)
        seg = np.sin(2 * np.pi * f * np.arange(ln) / SR) * r.uniform(0.3, 1) + r.standard_normal(ln) * r.uniform(0, 0.5)
        reps = int(r.integers(1, 5))
        for _ in range(reps):
            m = min(ln, n - pos)
            if m <= 0: break
            x[pos:pos + m] = seg[:m]; pos += ln
        pos += int(r.uniform(0.0, 0.04) * SR)
    return fade(norm(bp(bitcrush(x, 4, 3), 200, 9000), 0.9), 0.002, 0.05)

def sting(d=1.7):
    r = rngs(29); tt = T(d); p = tt / d
    x = np.zeros(len(tt))
    for f in (440, 466, 622, 659, 880):
        ff = f * (1 + 0.9 * p ** 1.5)
        x += signal.sawtooth(phase(ff)) * 0.3
    x = bp(x, 300, 6000, 2) * (p ** 1.3) * np.exp(-np.clip(tt - 1.2, 0, None) * 12)
    x += bp(noise(d, r), 1000, 7000, 2) * np.exp(-np.clip(tt - 1.2, 0, None) * 12) * 0.3 * p
    return fade(norm(np.tanh(x * 2.0), 0.9), 0.01, 0.01)

def rumble(d=4.2):
    r = rngs(31); tt = T(d)
    x = lp(noise(d, r), 90, 4) * 3.0 * (0.6 + 0.4 * np.sin(2 * np.pi * 8 * tt))
    x += np.sin(phase(32 + 4 * np.sin(2 * np.pi * 0.7 * tt))) * 0.8
    x *= np.minimum(1, tt / 0.4) * np.exp(-np.clip(tt - 1.5, 0, None) * 0.9)
    return fade(norm(np.tanh(x), 0.95), 0.01, 0.3)

if __name__ == "__main__":
    items = {
        "heartbeat": heartbeat(), "whisper_a": whisper(11), "whisper_b": whisper(22), "whisper_c": whisper(33, 3.8),
        "scream": scream(), "static": static_burst(), "door_creak": door_creak(), "bell": bell(),
        "thump": thump(), "riser": riser(), "breath": breath(), "growl": growl(),
        "shadow_hurt": shadow_hurt(), "shadow_death": shadow_death(), "teleport": teleport(),
        "glitch": glitch(), "sting": sting(), "rumble": rumble(),
    }
    tot = 0
    for k, v in items.items():
        assert np.isfinite(v).all(), k
        s = save(k, v, stereo=False, q=5); tot += s
        print(f"{k:14s} {len(v)/SR:5.2f}s  peak={np.max(np.abs(v)):.2f}  {s/1024:7.1f} KB")
    print("TOTALE SFX KB:", round(tot / 1024, 1))
