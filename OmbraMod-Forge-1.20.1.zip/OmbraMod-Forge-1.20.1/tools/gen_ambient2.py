from audiolib import *
from gen_ambient import finish, tine, midi
from gen_sfx import bell

def drone_cave(d=66):
    n = int(d * SR); tt = T(d); r = rngs(4040); L = np.zeros(n); R = np.zeros(n)
    hum = (np.sin(2 * np.pi * 45 * tt) + 0.7 * np.sin(2 * np.pi * 67.4 * tt + 1)) * 0.12 * (0.6 + 0.4 * np.sin(2 * np.pi * tt / 17))
    L += hum; R += hum
    for ch, sd in ((L, 5), (R, 6)):
        w = tv_filter(noise(d, rngs(sd)), lambda t: 500 + 300 * np.sin(2 * np.pi * t / 23), q=1.0) * 0.25
        ch += w * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 13 + sd))
    for _ in range(26):  # gocce
        t0 = r.uniform(1, d - 3); f = r.uniform(900, 2000); pan = r.uniform(0.1, 0.9); q = T(0.6)
        dr = np.sin(phase(f * (1 + 0.5 * np.exp(-q * 40)))) * np.exp(-q * 22) * 0.3
        dr = reverb(dr, 2.0, 0.55, seed=int(t0 * 10))[:int(1.6 * SR)]
        place(L, dr * (1 - pan), t0); place(R, dr * pan, t0)
    for _ in range(5):  # raschi lontani
        t0 = r.uniform(4, d - 6); ln = r.uniform(1.5, 3.0); pan = r.uniform(0.2, 0.8)
        sc = tv_filter(noise(ln, r), lambda t: 300 + 1400 * t / ln, q=5) * 0.45 * np.sin(np.pi * np.clip(T(ln) / ln, 0, 1))
        place(L, sc * (1 - pan), t0); place(R, sc * pan, t0)
    for _ in range(3):  # lamenti gravi
        t0 = r.uniform(8, d - 10); ln = 5.0; q = T(ln)
        g = signal.sawtooth(phase(60 + 25 * np.sin(np.pi * q / ln))) * np.sin(np.pi * q / ln) ** 2
        g = lp(g, 400, 3) * 0.35
        place(L, g, t0); place(R, g * 0.9, t0)
    return finish(L, R)

def drone_nether(d=64):
    n = int(d * SR); tt = T(d); r = rngs(5050); L = np.zeros(n); R = np.zeros(n)
    for f, a in ((98.0, 1.0), (123.5, 0.8), (147.0, 0.7), (196.0, 0.4)):
        for ch, det in ((L, -0.002), (R, 0.002)):
            vib = 1.5 * np.sin(2 * np.pi * 0.2 * tt + f)
            ch += np.sin(phase(f * (1 + det) + vib)) * a * 0.06 * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 16 + f))
    for ch, sd in ((L, 7), (R, 8)):
        lava = tv_filter(noise(d, rngs(sd)), lambda t: 140 + 90 * np.sin(2 * np.pi * t / 9), kind="low") * 1.4
        ch += lava * (0.5 + 0.5 * np.sin(2 * np.pi * tt / 11))
        cr = np.zeros(n)
        idx = r.integers(0, n, size=int(d * 55))
        cr[idx] = r.standard_normal(len(idx)) * r.uniform(0.2, 1.0, size=len(idx))
        ch += bp(cr, 1200, 6000, 2) * 0.35
    for _ in range(4):
        t0 = r.uniform(6, d - 12); pan = r.uniform(0.2, 0.8)
        b = bell(f0=r.uniform(75, 95), d=8.0) * 0.5
        place(L, b * (1 - pan), t0); place(R, b * pan, t0)
    return finish(L, R)

if __name__ == "__main__":
    tot = 0
    for nm, fn in (("drone_cave", drone_cave), ("drone_nether", drone_nether)):
        x = fn(); assert np.isfinite(x).all(), nm
        s = save(nm, x, stereo=True, q=4); tot += s
        print(f"{nm:14s} {len(x)/SR:5.1f}s  {s/1024:8.1f} KB", flush=True)
