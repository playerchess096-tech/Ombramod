# L'Ombra — The Shadow (mod horror per Minecraft Forge 1.20.1)

Un'entità persistente che ti **osserva, ti parla nella chat e cresce con i tuoi progressi**, dall'inizio della
sopravvivenza fino a uno scontro finale difficilissimo. Solo la **spada di netherite** può ucciderla.

- Minecraft **Java Edition 1.20.1** · Forge **47.x** · Java **17**
- Codice Java in `src/main/java`, tutto in italiano (battute, comandi, messaggi)
- 27 suoni originali sintetizzati + texture create da zero (nessun asset di terzi) → il jar finale pesa circa **8 MB**
- Elenco completo delle 50 funzioni e di dove stanno nel codice: **FUNZIONI.md**

> ⚠️ Importante: questo progetto è stato scritto e controllato (sintassi, flusso, coerenza di suoni/risorse) **senza poterlo
> compilare contro Forge**, perché nell'ambiente in cui è stato creato non c'era accesso a Internet per scaricare Minecraft/Forge.
> Alla prima build potrebbe quindi uscire qualche piccolo errore di API: copia l'errore che ti dà Gradle e fallo correggere.

---

## 1. Come ottenere il file .jar

Ti serve **JDK 17** (es. Temurin 17). Poi scegli una delle due strade.

### Strada A (consigliata): dentro l'MDK ufficiale di Forge
1. Scarica l'**MDK per Minecraft 1.20.1** da https://files.minecraftforge.net (versione 47.x, pulsante *Mdk*) ed estrailo.
2. Cancella la cartella `src` dell'MDK e **copiaci al suo posto la cartella `src` di questo zip**.
3. Nel `gradle.properties` dell'MDK imposta `mod_id=ombra` (le altre voci possono restare quelle di default).
4. Apri un terminale nella cartella dell'MDK e lancia:
   - Windows: `gradlew.bat build`
   - Linux/Mac: `./gradlew build`
5. Il mod è in `build/libs/ombra-1.0.0.jar` (o col nome che dà il tuo `gradle.properties`).

### Strada B: questo progetto completo
Questo zip contiene già `build.gradle`, `settings.gradle` e `gradle.properties` pronti. Manca solo il *wrapper* di Gradle:
copia `gradlew`, `gradlew.bat` e la cartella `gradle/` dall'MDK ufficiale dentro questa cartella, poi `gradlew build`.

### Provarlo senza installare niente
`gradlew runClient` avvia Minecraft con la mod già caricata (crea un mondo e scrivi `/gamemode survival`).

## 2. Installazione
Copia `ombra-1.0.0.jar` nella cartella `mods` di Minecraft 1.20.1 con Forge installato. Funziona sia in singleplayer sia in multiplayer
(va installata sul server **e** sui client).

## 3. Come funziona (in breve)

**Le ondate** (si salvano nel mondo: uscire e rientrare non le azzera; ogni obiettivo scatta una sola volta)

| # | Nome | Quando |
|---|------|--------|
| 1 | Osservazione | sempre attiva: si manifesta raramente, messaggi misteriosi, piccoli eventi |
| 2 | Persecuzione | dopo 15 minuti di gioco (configurabile): ti segue, compare nelle caverne, brevi inseguimenti |
| 3 | La caccia comincia | primo set completo di armatura di **ferro** |
| 4 | Bagliore | primo **diamante** |
| 5 | Fuoco profondo | primo ingresso nel **Nether** |
| 6 | Imboscata | primo set completo di armatura di **diamante** |
| 7 | Il Prescelto | primo set completo di armatura di **netherite**: si prepara allo scontro |
| 8 | Sotto lo sguardo | dopo aver ucciso l'**Ender Dragon** |
| 9 | Caccia finale | quando le ondate 3–8 sono tutte superate: compare per lo scontro finale |

**Combattimento**: ferro, diamante, asce, archi, balestre, tridenti, esplosioni, fuoco... **non** la toccano (reagisce con suoni,
messaggi, arretra o ti ignora). Solo la spada di netherite fa danno vero. Ha 500 PS, mosse con **preavviso** (rumore profondo,
occhi rossi, braccia alzate), poi resta **vulnerabile** per alcuni secondi (occhi azzurri): colpiscila allora. A circa il 13% di
salute **finge di morire** e tenta un'unica imboscata. Se vince il giocatore parte il finale (e il **finale segreto** se hai letto
tutte le 8 pagine strappate prima), e l'Ombra non ritorna più… a meno che attivi la **Modalità Incubo**: tieni in mano il
**Cuore dell'Ombra** (il drop finale), **Maiusc + clic destro**.

## 4. Provare tutto subito: i comandi (servono permessi da operatore)
```
/ombra status                 stato di ondate, tensione, rabbia, indizi...
/ombra wave <1-9>             sblocca un'ondata
/ombra event <nome>           lancia un evento (TAB per l'elenco: footsteps, door, heartbeat, watcher, jumpscare, chase, isolation...)
/ombra spawn <modo>           evoca l'Ombra (watch, stalk, chase, ambush, duel...)
/ombra tension <0-100>        imposta la tensione
/ombra clue                   leggi la prossima pagina del diario
/ombra jumpscare              prova il jumpscare
/ombra nightmare              attiva/disattiva la Modalità Incubo
/ombra reset                  azzera il tuo profilo
```
Nella scheda creativa **"L'Ombra"** trovi l'uovo di evocazione e tutti gli oggetti. Per provare lo scontro: `/give @s netherite_sword`,
poi `/ombra spawn duel` (o colpisci con la spada un'Ombra evocata).

## 5. Configurazione: `config/ombra-common.toml`
- `chat.*` — nome in chat, stile `<Ombra>` come un giocatore vero o `[Ombra]` rosso, oppure chat disattivata
- `pacing.eventFrequency` — frequenza degli eventi (0.2 = rarissimi, 3 = frequentissimi) · `wave2Minutes` · `affectCreative`
- `effects.jumpscareLevel` — **0 = nessun jumpscare**, 1 = solo suono+titolo, 2 = + schermo che trema, 3 = + volto e accecamento
- `effects.jumpscareCooldownMinutes` (default 20) · `screenShake` · `visualGlitches` · `soundVolume`
- `world.*` — disattiva torce che si spengono, alberi/segni, strutture sotterranee
- `combat.shadowHealth` · `damageMultiplier` · `allowStrongWeapons` (+ `strongWeaponDamage`: se vuoi che anche armi con più di 8 di danno
  possano ucciderla, come nel tuo primo messaggio; di default vale la regola "solo spada di netherite")

## 6. Sicurezza e prestazioni
- Gli effetti visivi sono **solo overlay e camera** sul client: non toccano file, mondo o impostazioni.
- Le torce spente sono **sempre riaccese** (anche dopo un crash: sono salvate nel mondo e ripristinate all'avvio/chiusura).
- Strutture e alberi modificati solo su roccia/alberi naturali e lontano dai chunk dove il giocatore ha costruito.
- Ogni sequenza passa dal pianificatore interno: niente blocchi del gioco. Il controllo principale gira una volta al secondo.
- In multiplayer ogni giocatore ha la **sua** Ombra, i suoi messaggi e il suo profilo: nessun messaggio duplicato.

## 7. Struttura del progetto
```
src/main/java/com/gamernoob/ombra/
  OmbraMod.java            punto d'ingresso
  config/                  configurazione
  entity/ShadowEntity      l'Ombra: IA a stati, combattimento, boss bar, falsa morte
  director/                ShadowDirector (regista), Waves (ondate), HorrorEvents (eventi), WorldFx (mondo), Fx (chat/suoni/titoli)
  story/                   Dialogue (battute), Clues (indizi), Personality
  data/                    profili dei giocatori salvati nel mondo
  item/, registry/, net/, command/, events/
  client/                  renderer, occhi luminosi, effetti schermo (shake, glitch, jumpscare, cielo rosso, isolamento)
src/main/resources/        mods.toml, suoni (.ogg), texture, lingue, modelli
tools/                     script Python usati per sintetizzare suoni e texture (puoi rigenerarli o modificarli)
```
