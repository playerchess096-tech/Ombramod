# Le 50 funzioni: dove stanno e come funzionano

Sigle: **SE** = `entity/ShadowEntity`, **SD** = `director/ShadowDirector`, **HE** = `director/HorrorEvents`, **WF** = `director/WorldFx`,
**WV** = `director/Waves`, **DL** = `story/Dialogue`, **CF** = `client/ClientFx`. Dove un effetto è un'approssimazione di ciò che
chiedeva il prompt, c'è scritto chiaramente.

## 1. Intelligenza e comportamento
| # | Funzione | Implementazione |
|---|----------|-----------------|
| 1 | Memoria delle azioni | `PlayerProfile.memory` (ultime 24 azioni: diamanti, spawner, morti, sonno, Nether, base, resti antichi). `DL.memoryLine` le cita con le coordinate, anche nelle stanze della memoria e col Frammento nero |
| 2 | Personalità dinamica | `Personality`: silenziosa / provocatoria / aggressiva / amichevole, cambia ogni 4–9 minuti e pesa battute ed eventi (SD.modifier) |
| 3 | Osservazione a distanza | evento WATCHER: `WF.findWatchSpot` sceglie colline, alberi o imbocchi di caverna con linea di vista |
| 4 | Reazione allo sguardo | `SE.trackGaze/reactToGaze`: si immobilizza con la testa inclinata, sparisce o si teletrasporta lontano |
| 5 | Apprendimento abitudini | `PlayerProfile.habits` conta i secondi per chunk; i punti frequentati pesano nella scelta di dove apparire e generano battute |
| 6 | Curiosità | `PlayerProfile.curiosity` sale con profondità, oggetti preziosi (netherite, nether star, elytra...) e vicinanza a spawner/sculk. **Approssimazione**: le "strutture rare" sono riconosciute da questi blocchi, non da tutte le strutture del gioco |
| 7 | Finta amicizia | arco di 5 messaggi rassicuranti (con carillon) poi rivelazione con passi e battuta (`HE.friendly`) |
| 8 | Territorialità | la base si riconosce dai blocchi piazzati (≥ 45 per chunk; letti/forni/casse/tavoli contano di più); attorno alla base più apparizioni, segni e battute |
| 9 | Rabbia | `anger`: +6 per colpo con arma inefficace, +14 se rompi un suo simbolo (teschio/terra delle anime); rende l'inseguimento più veloce e la personalità più aggressiva |
| 10 | Simulazione di intelligenza | stati WATCH / STALK / CHASE / AMBUSH / RETREAT + silenzi obbligati dopo ogni apparizione (`silenceUntil`) |

## 2. Eventi e manipolazione del mondo
| # | Funzione | Implementazione |
|---|----------|-----------------|
| 11 | Torce che si spengono | `WF.extinguishTorches`: le torce vicine spariscono e **tornano da sole**; elenco salvato nel mondo e ripristino forzato a avvio/chiusura |
| 12 | Strutture misteriose | evento STRUCTURE: altare sotterraneo scavato **solo in roccia naturale**, mai nei chunk costruiti dal giocatore |
| 13 | Alberi innaturali | `WF.corruptTree`: tronco scuro, terra delle anime e teschio alla base (il teschio è un "simbolo": rompilo e l'Ombra si arrabbia) |
| 14 | Animali terrorizzati | ANIMALS: fuggono oppure restano fermi a fissare un punto vuoto, con versi alterati (tono basso) |
| 15 | Villaggi silenziosi | VILLAGERS: i villager restano immobili a fissarti e i loro versi vengono silenziati **sul client del giocatore** |
| 16 | Falsi tunnel | evento TUNNEL: passaggio scavato in una parete di caverna, porta a stanza vuota o vicolo cieco; entrandoci l'Ombra parla |
| 17 | Segnali sul terreno | SIGNS: scia di impronte (particelle d'inchiostro) e anime che si avvicina senza rivelare dove |
| 18 | Eco nelle caverne | CAVE_ECHO: lo stesso rumore ripetuto 3 volte, ritardato e da direzioni diverse |
| 19 | Cielo anomalo | SKY: nebbia/orizzonte e velo rossi, fulmine lontano, drone. **Approssimazione**: non cambia la skybox, tinge nebbia e schermo |
| 20 | Oggetti misteriosi | ITEM_DROP: Pagina strappata (indizio), Frammento nero e Simbolo sconosciuto (temporanei: si sbriciolano dopo 10 min) |

## 3. Combattimento e debolezze
| # | Funzione | Implementazione |
|---|----------|-----------------|
| 21 | Immunità alle armi normali | `SE.hurt`: ogni danno che non sia colpo in mischia di un giocatore con arma letale viene annullato (frecce, tridenti lanciati, esplosioni, fuoco...). `/kill` e il vuoto passano, per i test |
| 22 | Unica arma letale | `SE.isLethalWeapon`: controllo reale sulla spada di netherite impugnata. Opzione config per ammettere anche armi con danno > soglia |
| 23 | Reazioni agli attacchi inefficaci | `SE.onIneffective`: ignora, arretra, ringhia o risponde «Quello non può uccidermi» |
| 24 | Resistenza soprannaturale | 500 PS (config), armatura, immune a effetti; fuori dalla finestra di vulnerabilità incassa solo il 35% |
| 25 | Attacchi con preavviso | colpo ad area preceduto da rumore profondo, occhi rossi e braccia alzate (26 tick) |
| 26 | Teletrasporto tattico | `SE.tacticalTeleport`: ricompare alle spalle, con ricarica di 10–14 s |
| 27 | Fase di vulnerabilità | dopo ogni colpo ad area è lenta per 4–5 s con occhi azzurri; allora i colpi valgono il 100% |
| 28 | Falsa sconfitta | al 13% di salute cade a terra, resta immobile ~6 s, poi un'unica imboscata (danno ×1.8) e riprende furiosa |
| 29 | Tracce del combattimento | `WF.lingeringTraces`: particelle scure ed eco sorda dopo ogni colpo ad area e dopo la morte |
| 30 | Morte definitiva | `SE.die` + `SD.onShadowDefeated` + `WV.playFinale`: animazione, suono, messaggi, ricompensa (Cuore, Nether Star, Frammenti d'eco, Diario). Il profilo resta `defeated`: l'Ombra non ricompare |

## 4. Ondate e progressione (`Waves`, salvate in `OmbraData`)
| # | Funzione | Implementazione |
|---|----------|-----------------|
| 31 | Ondate basate sul tempo | difficoltà = ondate + tensione + ore di gioco + rabbia; ondata 2 dopo `wave2Minutes`; nessun combattimento obbligato (periodi di calma e silenzi) |
| 32 | 1ª ondata di osservazione | sempre attiva: eventi rari e leggeri |
| 33 | 2ª ondata di persecuzione | pedinamento, caverne, brevi inseguimenti |
| 34 | 3ª ondata: armatura di ferro | `SD.trackProgress`, scatta **una sola volta** (flag `F_IRON`) |
| 35 | 4ª ondata: primo diamante | flag `F_DIAMOND` |
| 36 | 5ª ondata: Nether | flag `F_NETHER` (anche via evento cambio dimensione) |
| 37 | 6ª ondata: armatura di diamante | flag `F_DIAMOND_ARMOR` |
| 38 | 7ª ondata: armatura di netherite | flag `F_NETHERITE_ARMOR`: l'Ombra riconosce che sei pronto |
| 39 | 8ª ondata: Ender Dragon | `LivingDeathEvent` sul drago → messaggio «ti osservavo dall'inizio» |
| 40 | 9ª ondata: caccia finale | si accoda quando 3–8 sono superate; se hai la spada di netherite compare per il duello, altrimenti ti insegue e ti dice di cercarla |

## 5. Eventi avanzati, atmosfera e finali segreti
| # | Funzione | Implementazione |
|---|----------|-----------------|
| 41 | Tensione invisibile | `PlayerProfile.tension` (0–100): ogni evento la alza, buio/profondità/vita bassa/presenza dell'Ombra la fanno salire, la calma la fa scendere; aumenta frequenza e intensità |
| 42 | Falsi errori visivi | GLITCH e FAKE_ERROR: barre di interferenza, testo corrotto, finti errori in chat. Solo overlay/testo, **nessun file toccato** |
| 43 | Messaggi di morte personalizzati | `DL.deathLine`: per causa (caduta, fuoco, annegamento, esplosione, mob, freccia, fame, vuoto, magia, wither, soffocamento, Ombra) e per numero di morti |
| 44 | Sistema di indizi | 8 pagine strappate (`Clues`) che spiegano chi è, perché ti segue e perché serve il netherite |
| 45 | Stanze della memoria | MEMORY_ROOM: stanza sotterranea di blackstone/ossidiana piangente; entrandoci l'Ombra ricorda eventi passati della partita |
| 46 | Evento di isolamento | ISOLATION: il client silenzia musica/ambiente/mob per 45–75 s, drone sonoro, messaggio «non c'è nessuno qui» |
| 47 | Inseguimento cinematografico | CHASE: battito crescente, glitch e tremori man mano che si avvicina; finisce con la luce (blocco luminoso ≥ 12 per ~3.5 s), in base, o dopo ~45 s |
| 48 | Evento durante la pioggia | RAIN: silhouette visibile solo nei lampi, sempre più vicina; la pioggia moltiplica anche i tuoni |
| 49 | Finale alternativo | se hai letto tutte e 8 le pagine prima di sconfiggerla: scena speciale «Eri tu», con il numero delle tue morti, musica dedicata e Totem dell'Immortalità |
| 50 | Modalità incubo rigiocabile | Cuore dell'Ombra (Maiusc + clic destro) o `/ombra nightmare`: ondate accelerate, Ombra con +50% PS e +40% danno, eventi a catena. Regola della spada di netherite invariata |

## Requisiti tecnici
- **Probabilità, intervalli, condizioni**: ogni evento ha livello minimo, peso e ricarica (`HorrorEvent`) + modificatori per personalità, pioggia, notte, caverne, base.
- **Ondate salvate**: nel profilo del giocatore dentro `OmbraData` (SavedData del mondo).
- **Obiettivi una sola volta**: bitmask `flags` e `waves` nel profilo.
- **Multiplayer**: messaggi ed effetti solo al giocatore interessato; una sola Ombra per giocatore; tutto è lato server tranne gli overlay.
- **Effetti controllati**: tutte le sequenze passano dallo `Scheduler`; gli effetti client sono overlay/camera.
- **Jumpscare rari e configurabili**: cooldown ≥ 20 min (+ casuale), solo da ondata 3, livello 0–3 in config.

## Come sono stati creati suoni e texture
`tools/` contiene gli script Python (numpy/scipy/Pillow + ffmpeg) che sintetizzano i 27 suoni (.ogg) e le texture. Nessun asset di terzi.
