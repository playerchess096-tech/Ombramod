package com.gamernoob.ombra.director;

import com.gamernoob.ombra.config.OmbraConfig;
import com.gamernoob.ombra.net.FxPacket;
import com.gamernoob.ombra.net.ModNet;
import com.gamernoob.ombra.util.Rnd;
import com.gamernoob.ombra.util.Scheduler;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetSubtitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Ponte unico verso chat, titoli, suoni, particelle ed effetti client. Tutto e' controllato e a prova di blocco. */
public final class Fx {
    private static final Map<UUID, Long> LAST_SAY = new HashMap<>();

    private Fx() {}

    // ------------------------------------------------------------------ chat

    public static Component chatComponent(String text) {
        String name = OmbraConfig.CHAT_NAME.get();
        if (OmbraConfig.CHAT_AS_PLAYER.get()) return Component.literal("<" + name + "> " + text);
        return Component.literal("[" + name + "] ").withStyle(ChatFormatting.DARK_RED)
                .append(Component.literal(text).withStyle(ChatFormatting.GRAY));
    }

    public static void say(ServerPlayer p, String text) {
        say(p, text, false);
    }

    /** L'Ombra parla nella chat (solo al giocatore interessato: nessun messaggio duplicato in multiplayer). */
    public static void say(ServerPlayer p, String text, boolean force) {
        if (p == null || text == null || text.isEmpty() || !OmbraConfig.CHAT_ENABLED.get()) return;
        long now = Scheduler.now();
        Long last = LAST_SAY.get(p.getUUID());
        if (!force && last != null && now - last < 30L) return;
        LAST_SAY.put(p.getUUID(), now);
        p.sendSystemMessage(chatComponent(text));
    }

    public static void sayLater(ServerPlayer p, int ticks, String text) {
        Scheduler.laterFor(p.getUUID(), ticks, pl -> say(pl, text, true));
    }

    public static void raw(ServerPlayer p, String legacyText) {
        p.sendSystemMessage(Component.literal(legacyText));
    }

    public static void action(ServerPlayer p, String text) {
        p.sendSystemMessage(Component.literal(text), true);
    }

    // ------------------------------------------------------------------ titoli

    public static void title(ServerPlayer p, String title, String subtitle, int in, int stay, int out) {
        p.connection.send(new ClientboundSetTitlesAnimationPacket(in, stay, out));
        p.connection.send(new ClientboundSetSubtitleTextPacket(Component.literal(subtitle)));
        p.connection.send(new ClientboundSetTitleTextPacket(Component.literal(title)));
    }

    /** Titolo "disturbato": lampeggia tra testo corrotto e testo vero. */
    public static void glitchTitle(ServerPlayer p, String text) {
        UUID id = p.getUUID();
        for (int i = 0; i < 6; i++) {
            final boolean clean = i % 2 == 1;
            Scheduler.laterFor(id, i * 4, pl -> {
                Component c = clean
                        ? Component.literal(text).withStyle(ChatFormatting.DARK_RED, ChatFormatting.BOLD)
                        : Component.literal(corrupt(text)).withStyle(ChatFormatting.RED, ChatFormatting.OBFUSCATED);
                pl.connection.send(new ClientboundSetTitlesAnimationPacket(0, 12, 6));
                pl.connection.send(new ClientboundSetTitleTextPacket(c));
            });
        }
    }

    public static String corrupt(String s) {
        String noise = "█▓▒░#@%&?!";
        StringBuilder sb = new StringBuilder();
        for (char ch : s.toCharArray()) {
            if (ch != ' ' && Rnd.chance(0.45D)) sb.append(noise.charAt(Rnd.range(0, noise.length() - 1)));
            else sb.append(ch);
        }
        return sb.toString();
    }

    // ------------------------------------------------------------------ suoni

    private static float vol(float v) {
        return (float) (v * OmbraConfig.SOUND_VOLUME.get());
    }

    /** Suono "dentro la testa" del giocatore (non posizionale). */
    public static void soundSelf(ServerPlayer p, SoundEvent s, float volume, float pitch) {
        p.playNotifySound(s, SoundSource.HOSTILE, vol(volume), pitch);
    }

    public static void soundSelfAmbient(ServerPlayer p, SoundEvent s, float volume, float pitch) {
        p.playNotifySound(s, SoundSource.AMBIENT, vol(volume), pitch);
    }

    /** Suono posizionale: viene da una direzione precisa. */
    public static void soundAt(ServerLevel l, SoundEvent s, double x, double y, double z, float volume, float pitch) {
        l.playSound(null, x, y, z, s, SoundSource.HOSTILE, vol(volume), pitch);
    }

    // ------------------------------------------------------------------ particelle e client

    public static void particles(ServerLevel l, ParticleOptions o, double x, double y, double z, int n, double spread, double speed) {
        l.sendParticles(o, x, y, z, n, spread, spread, spread, speed);
    }

    public static void send(ServerPlayer p, int kind, int dur, int power) {
        if (kind == FxPacket.SHAKE && !OmbraConfig.SCREEN_SHAKE.get()) return;
        if ((kind == FxPacket.GLITCH || kind == FxPacket.CLOSE || kind == FxPacket.RED_SKY) && !OmbraConfig.VISUAL_GLITCHES.get()) return;
        ModNet.sendTo(p, new FxPacket(kind, dur, power, 0));
    }

    public static void send(ServerPlayer p, int kind, int dur, int power, int extra) {
        ModNet.sendTo(p, new FxPacket(kind, dur, power, extra));
    }
}
