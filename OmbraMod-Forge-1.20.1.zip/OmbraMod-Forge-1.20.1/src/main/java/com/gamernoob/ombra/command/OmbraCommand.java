package com.gamernoob.ombra.command;

import com.gamernoob.ombra.data.OmbraData;
import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.director.HorrorEvent;
import com.gamernoob.ombra.director.HorrorEvents;
import com.gamernoob.ombra.director.ShadowDirector;
import com.gamernoob.ombra.director.Waves;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.gamernoob.ombra.story.Clues;
import com.gamernoob.ombra.story.Personality;
import com.gamernoob.ombra.util.Util;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** Comandi di prova (servono i permessi da operatore): /ombra status | wave | event | spawn | tension | clue | nightmare | jumpscare | reset */
public final class OmbraCommand {
    private OmbraCommand() {}

    private static final List<String> EVENTS = Arrays.stream(HorrorEvent.values()).map(e -> e.name().toLowerCase(Locale.ROOT)).toList();
    private static final List<String> MODES = Arrays.stream(ShadowEntity.Mode.values()).map(m -> m.name().toLowerCase(Locale.ROOT)).toList();

    public static void register(CommandDispatcher<CommandSourceStack> d) {
        d.register(Commands.literal("ombra").requires(s -> s.hasPermission(2))
                .then(Commands.literal("status").executes(c -> status(c.getSource())))
                .then(Commands.literal("wave").then(Commands.argument("n", IntegerArgumentType.integer(1, 9))
                        .executes(c -> wave(c.getSource(), IntegerArgumentType.getInteger(c, "n")))))
                .then(Commands.literal("event").then(Commands.argument("nome", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(EVENTS, b))
                        .executes(c -> event(c.getSource(), StringArgumentType.getString(c, "nome")))))
                .then(Commands.literal("spawn").then(Commands.argument("modo", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(MODES, b))
                        .executes(c -> spawn(c.getSource(), StringArgumentType.getString(c, "modo")))))
                .then(Commands.literal("tension").then(Commands.argument("v", IntegerArgumentType.integer(0, 100))
                        .executes(c -> tension(c.getSource(), IntegerArgumentType.getInteger(c, "v")))))
                .then(Commands.literal("clue").executes(c -> clue(c.getSource())))
                .then(Commands.literal("nightmare").executes(c -> nightmare(c.getSource())))
                .then(Commands.literal("jumpscare").executes(c -> jumpscare(c.getSource())))
                .then(Commands.literal("reset").executes(c -> reset(c.getSource()))));
    }

    private static void msg(CommandSourceStack src, String text) {
        src.sendSuccess(() -> Component.literal("§6[Ombra]§r " + text), false);
    }

    private static int status(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerProfile pr = ShadowDirector.profile(p);
        msg(src, "ondate " + pr.level() + "/9 (bit " + Integer.toBinaryString(pr.waves) + "), in coda " + Integer.toBinaryString(pr.pending)
                + ", tensione " + Math.round(pr.tension) + ", rabbia " + Math.round(pr.anger) + ", curiosità " + Math.round(pr.curiosity));
        msg(src, "personalità " + Personality.of(pr) + ", indizi " + Integer.bitCount(pr.clues & Clues.ALL) + "/8, morti " + pr.deaths
                + ", base " + (pr.hasBase ? pr.baseX + " " + pr.baseY + " " + pr.baseZ : "nessuna")
                + ", sconfitta " + pr.defeated + ", incubo " + pr.nightmare + ", caccia finale " + pr.huntActive);
        return 1;
    }

    private static int wave(CommandSourceStack src, int n) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerProfile pr = ShadowDirector.profile(p);
        pr.defeated = false;
        Waves.queue(pr, n);
        ShadowDirector.state(p.getUUID()).lastWaveSec = 0L;
        msg(src, "ondata " + n + " in arrivo entro un secondo.");
        return 1;
    }

    private static int event(CommandSourceStack src, String name) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        HorrorEvent ev;
        try {
            ev = HorrorEvent.valueOf(name.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            src.sendFailure(Component.literal("Evento sconosciuto: " + name));
            return 0;
        }
        PlayerProfile pr = ShadowDirector.profile(p);
        pr.jumpscareReadyAt = 0L;
        boolean ok = HorrorEvents.run(ev, p, pr, ShadowDirector.state(p.getUUID()), OmbraData.get(p.server));
        msg(src, ok ? "evento " + ev + " eseguito." : "evento " + ev + " non applicabile qui (serve altro contesto: buio, pioggia, caverna...).");
        return ok ? 1 : 0;
    }

    private static int spawn(CommandSourceStack src, String mode) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ShadowEntity.Mode m;
        try {
            m = ShadowEntity.Mode.valueOf(mode.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            src.sendFailure(Component.literal("Modo sconosciuto: " + mode));
            return 0;
        }
        ShadowEntity old = ShadowDirector.shadowOf(p);
        if (old != null) old.vanish(false);
        ServerLevel level = p.serverLevel();
        BlockPos spot = Util.findSpot(level, p.blockPosition(), 8.0D, 14.0D, 30, null);
        if (spot == null) {
            src.sendFailure(Component.literal("Nessuno spazio libero vicino a te."));
            return 0;
        }
        ShadowEntity e = ShadowDirector.spawnShadow(p, spot, m, m == ShadowEntity.Mode.DUEL ? 0 : 1500);
        msg(src, e != null ? "Ombra evocata in modo " + m + "." : "Impossibile evocare l'Ombra.");
        return e != null ? 1 : 0;
    }

    private static int tension(CommandSourceStack src, int v) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ShadowDirector.profile(p).tension = v;
        msg(src, "tensione = " + v);
        return 1;
    }

    private static int clue(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        Clues.discover(p, ShadowDirector.profile(p));
        return 1;
    }

    private static int nightmare(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        Waves.toggleNightmare(p, ShadowDirector.profile(p));
        return 1;
    }

    private static int jumpscare(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerProfile pr = ShadowDirector.profile(p);
        pr.jumpscareReadyAt = 0L;
        boolean ok = HorrorEvents.jumpscare(p, pr);
        if (!ok) src.sendFailure(Component.literal("Jumpscare disattivati nella configurazione (jumpscareLevel = 0)."));
        return ok ? 1 : 0;
    }

    private static int reset(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ShadowEntity e = ShadowDirector.shadowOf(p);
        if (e != null) e.vanish(false);
        OmbraData data = OmbraData.get(p.server);
        data.profiles.put(p.getUUID(), new PlayerProfile());
        data.setDirty();
        ShadowDirector.resetState(p.getUUID());
        msg(src, "profilo azzerato: si ricomincia da capo.");
        return 1;
    }
}
