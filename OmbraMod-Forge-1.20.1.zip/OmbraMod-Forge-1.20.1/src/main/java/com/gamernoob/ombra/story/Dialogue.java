package com.gamernoob.ombra.story;

import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.gamernoob.ombra.util.Rnd;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;

import java.util.Locale;

/** Tutte le battute dell'Ombra (in italiano), scelte in base a personalita', fase, morte e ricordi. */
public final class Dialogue {
    private Dialogue() {}

    private static String pick(String[] a) {
        return a[Rnd.range(0, a.length - 1)];
    }

    // ---------- battute generiche per personalita' ----------
    private static final String[] TAUNT = {
            "Cammini piano, come chi sa di essere seguito.",
            "Hai chiuso la porta? Non serve.",
            "Sento il rumore del tuo piccone. Anche da sottoterra.",
            "Non voltarti. Tanto non cambia niente.",
            "Quanto ancora pensi di scavare?",
            "Il tuo cuore batte forte. Lo sento da qui.",
            "Bella casa. Sarebbe un peccato se fosse... vuota.",
            "Hai paura del buio? Dovresti averne di ciò che ci vive.",
            "Sono più vicino di quanto credi.",
            "Ogni blocco che rompi è un passo verso di me.",
            "Fai pure finta di non vedermi.",
            "Hai guardato nell'angolo? No? Meglio così.",
            "Cosa stai cercando? Io lo so già.",
            "Non sei solo. Non lo sei mai stato.",
            "Che bel mondo. Peccato sia mio.",
            "Respira piano. Ti sento."
    };
    private static final String[] AGGR = {
            "Smettila di scappare.",
            "Ti trovo sempre.",
            "Corri. Mi piace quando corri.",
            "Non c'è luce abbastanza per te.",
            "Basta giochi.",
            "Questo mondo è mio. Tu sei di passaggio.",
            "Ti prendo.",
            "Più ti nascondi, più rumore fai.",
            "Hai i secondi contati.",
            "Girati. Voglio vederti in faccia.",
            "Ti sento dietro ogni parete.",
            "Non c'è posto dove io non arrivi."
    };
    private static final String[] FRIEND = {
            "Tutto bene? Mi sembri stanco.",
            "Non preoccuparti, sono qui.",
            "Hai fatto un ottimo lavoro con quella base.",
            "Se hai bisogno di me, chiama.",
            "Che bella giornata per scavare, vero?",
            "Mi fai compagnia. Lo sai?",
            "Resta vicino alla luce. Per sicurezza.",
            "Io non ti farei mai del male."
    };
    private static final String[] FRIENDLY_ARC = {
            "Ehi... c'è qualcuno qui? Sono Ombra. Sono arrivato da poco, scusa se ti disturbo.",
            "Bel posto che hai scelto. Posso restare un po' vicino a te?",
            "Se hai bisogno di una mano con le miniere, chiedimi pure. Conosco bene il sottosuolo.",
            "Sai, mi fai compagnia. Da molto tempo non parlavo con nessuno.",
            "Ho una cosa da dirti. Ma non qui. Guardati alle spalle."
    };
    private static final String[] REVEAL = {
            "Scherzavo. Ti osservo da quando hai messo piede in questo mondo.",
            "Credevi davvero che fossi un compagno di avventure?",
            "Il compagno perfetto è quello che non ti lascia mai solo. Neanche sottoterra."
    };

    public static int friendlyArcLength() {
        return FRIENDLY_ARC.length;
    }

    public static String friendlyArc(int stage) {
        return FRIENDLY_ARC[Math.max(0, Math.min(FRIENDLY_ARC.length - 1, stage))];
    }

    public static String reveal() {
        return pick(REVEAL);
    }

    /** Una battuta secondo la personalita' attuale (puo' essere null per l'Ombra silenziosa). */
    public static String line(PlayerProfile pr) {
        return switch (Personality.of(pr)) {
            case SILENT -> Rnd.chance(0.4) ? Rnd.of("...", ". . .", "…") : null;
            case TAUNTING -> pick(TAUNT);
            case AGGRESSIVE -> pick(AGGR);
            case FRIENDLY -> pick(FRIEND);
        };
    }

    // ---------- memoria ----------
    private static final String[] MEM_DIAMOND = {
            "Ti ricordi cosa hai trovato nella caverna? Io sì. Diamanti, vicino a {x} {y} {z}.",
            "Quei diamanti a {x} {y} {z}... brillavano come occhi.",
            "Hai scavato fino a {x} {y} {z}. Io ti guardavo dall'oscurità."
    };
    private static final String[] MEM_SPAWNER = {
            "Quella gabbia a {x} {y} {z}... l'hai spezzata. Ricordo il rumore.",
            "Hai liberato qualcosa a {x} {y} {z}. Non era solo."
    };
    private static final String[] MEM_DEATH = {
            "Sei morto a {x} {y} {z}. Il tuo corpo era ancora caldo quando sono arrivato.",
            "Laggiù, a {x} {y} {z}, ho tenuto qualcosa di tuo.",
            "Ricordo come sei caduto, a {x} {y} {z}. Non ho distolto lo sguardo."
    };
    private static final String[] MEM_SLEEP = {
            "L'ultima volta che hai dormito ero lì, accanto al letto.",
            "Mentre dormivi ti ho contato i respiri."
    };
    private static final String[] MEM_NETHER = {
            "Il portale che hai acceso... lo vedo ancora bruciare.",
            "Il Nether ti ha lasciato entrare. Non è stato un caso."
    };
    private static final String[] MEM_BASE = {
            "La tua base a {x} {y} {z}: la finestra a est non si chiude mai del tutto.",
            "Ho fatto il giro della tua casa. Più volte."
    };
    private static final String[] MEM_ANCIENT = {
            "Resti antichi a {x} {y} {z}. Appartenevano a qualcuno che conoscevo.",
            "Hai strappato quel metallo alla roccia. Ricorda ancora il fuoco."
    };

    /** Cita un'azione passata del giocatore, oppure null se non ricorda nulla di utile. */
    public static String memoryLine(ServerPlayer p, PlayerProfile pr) {
        if (pr.memory.isEmpty()) return null;
        PlayerProfile.Memory m = pr.memory.get(Rnd.range(0, pr.memory.size() - 1));
        String[] pool = switch (m.type) {
            case "DIAMOND" -> MEM_DIAMOND;
            case "SPAWNER" -> MEM_SPAWNER;
            case "DEATH" -> MEM_DEATH;
            case "SLEEP" -> MEM_SLEEP;
            case "NETHER" -> MEM_NETHER;
            case "BASE" -> MEM_BASE;
            case "ANCIENT" -> MEM_ANCIENT;
            default -> null;
        };
        if (pool == null) return null;
        return pick(pool).replace("{x}", String.valueOf(m.x)).replace("{y}", String.valueOf(m.y)).replace("{z}", String.valueOf(m.z));
    }

    // ---------- morte ----------
    private static final String[] D_FALL = {"Ti ho visto cadere. Non ho fatto niente.", "La gravità: la mia alleata più fedele.", "Cadere è facile. Rialzarsi molto meno."};
    private static final String[] D_FIRE = {"Il fuoco ti ha preso. Io non c'entro. Stavolta.", "Sembravi così sicuro vicino alla lava.", "Odore di bruciato... lo riconosco."};
    private static final String[] D_DROWN = {"L'acqua non perdona chi dimentica di respirare.", "Che silenzio, sotto la superficie. Mi piace."};
    private static final String[] D_EXPL = {"Un botto, e poi niente. Che pulito.", "Quel Creeper mi ha rubato il divertimento."};
    private static final String[] D_MOB = {"Sconfitto da qualcosa di così piccolo?", "Non sono stato io. Questa volta."};
    private static final String[] D_ARROW = {"Da lontano, senza guardarti in faccia. Quasi come me.", "Una freccia. Elegante."};
    private static final String[] D_STARVE = {"La fame è paziente. Io di più.", "Avresti dovuto mangiare."};
    private static final String[] D_VOID = {"Il vuoto ti ha chiamato. Io no. Non ancora.", "Sei caduto dove io vivo."};
    private static final String[] D_MAGIC = {"La magia è un debito. Qualcuno lo ha riscosso.", "Pozioni e incantesimi... ti fidi di cose che non capisci."};
    private static final String[] D_WITHER = {"Il decadimento ti ha preso piano. Lo capisco."};
    private static final String[] D_SUFF = {"Murato vivo. Che ironia per un minatore.", "Il buio ti è entrato nei polmoni."};
    private static final String[] D_SHADOW = {"Te l'avevo detto.", "Ti ho preso.", "Non scappi dall'ombra. Sei dentro di lei."};
    private static final String[] D_GENERIC = {"Un'altra morte. Le conto tutte.", "Ricomincia. Io ricordo.", "Sei tornato. Mi fa piacere."};
    private static final String[] D_COUNT = {"Questa è la tua morte numero {deaths}. Le conservo tutte.", "{deaths} volte. E io c'ero sempre."};

    /** Frase di morte scelta in base a causa, numero di morti e fase. */
    public static String deathLine(ServerPlayer p, PlayerProfile pr, DamageSource src) {
        String id = src.getMsgId() == null ? "" : src.getMsgId();
        Entity attacker = src.getEntity();
        if (pr.deaths >= 3 && Rnd.chance(0.35)) {
            return pick(D_COUNT).replace("{deaths}", String.valueOf(pr.deaths));
        }
        String[] pool;
        if (attacker instanceof ShadowEntity) pool = D_SHADOW;
        else if (id.contains("fall") || id.equals("flyIntoWall")) pool = D_FALL;
        else if (id.toLowerCase(Locale.ROOT).contains("fire") || id.equals("lava") || id.equals("hotFloor")) pool = D_FIRE;
        else if (id.contains("drown")) pool = D_DROWN;
        else if (id.contains("explosion") || id.contains("fireworks")) pool = D_EXPL;
        else if (id.equals("starve")) pool = D_STARVE;
        else if (id.equals("outOfWorld") || id.equals("genericKill")) pool = D_VOID;
        else if (id.toLowerCase(Locale.ROOT).contains("magic") || id.equals("sonic_boom")) pool = D_MAGIC;
        else if (id.equals("wither")) pool = D_WITHER;
        else if (id.equals("inWall") || id.equals("cramming")) pool = D_SUFF;
        else if (id.contains("arrow") || id.contains("trident") || id.equals("mobProjectile") || id.equals("thrown")) pool = D_ARROW;
        else if (attacker != null) pool = D_MOB;
        else pool = D_GENERIC;
        return pick(pool);
    }

    // ---------- reazioni ad azioni del giocatore ----------
    private static final String[] SLEEP = {
            "Hai dormito bene? Io non dormo mai. Resto a guardare.",
            "Mentre dormivi ero seduto accanto al tuo letto.",
            "Hai sognato? Io c'ero.",
            "Il letto è comodo? Ne ho visto uno uguale in un altro mondo."
    };
    private static final String[] DIAMOND_ORE = {
            "Brillano, vero? Anch'io le noto da lontano.",
            "Diamanti. Ora hai qualcosa da perdere.",
            "Tutto quel luccichio mi ricorda gli occhi di chi hai lasciato indietro."
    };
    private static final String[] ANCIENT = {
            "Resti antichi... non dovresti toccarli.",
            "Quel metallo ricorda. Ricordi anche tu?"
    };
    private static final String[] SPAWNER = {
            "Una gabbia... qualcuno l'ha costruita. Non io.",
            "Lì sotto c'è fame. Meglio non svegliarla.",
            "Spezzi le gabbie. Chi libererai domani?"
    };
    private static final String[] SPAWNER_NEAR = {
            "Lo senti? Questo posto era vivo, prima.",
            "Non toccare quella gabbia. O toccala. Mi diverte comunque."
    };

    public static String sleepLine() { return pick(SLEEP); }
    public static String diamondOreLine() { return pick(DIAMOND_ORE); }
    public static String ancientLine() { return pick(ANCIENT); }
    public static String spawnerLine() { return pick(SPAWNER); }
    public static String spawnerNearLine() { return pick(SPAWNER_NEAR); }

    // ---------- combattimento ----------
    private static final String[] GAZE = {"Mi hai visto.", "Non guardarmi.", "Ah... mi hai trovato.", "Girati. Subito."};
    private static final String[] INEFFECTIVE = {
            "Quello non può uccidermi.",
            "Ferro, pietra, legno... niente di tutto questo mi riguarda.",
            "Mi fai il solletico.",
            "Serve ben altro per spezzare un'ombra."
    };
    private static final String[] DUEL_START = {
            "Ora sì. Vediamo se sei degno di quella lama.",
            "La spada di netherite... finalmente."
    };

    public static String gazeLine() { return pick(GAZE); }
    public static String ineffectiveLine() { return pick(INEFFECTIVE); }
    public static String duelStart() { return pick(DUEL_START); }

    public static String duelPhase(int phase) {
        return phase == 2 ? "Sei più forte di quanto pensassi." : "Non finirà così!";
    }

    public static String fakeDeath() { return Rnd.of("Ah... è finita...", "Così... si spegne un'ombra..."); }

    public static String ambushAfterFake() {
        return Rnd.of("Pensavi fosse finita? L'ombra non muore senza un ultimo morso.",
                "Mai voltare le spalle a un'ombra che cade.");
    }

    public static String chaseStart() { return Rnd.of("Corri.", "Ti do un po' di vantaggio. Non servirà."); }
    public static String chaseEnd() { return Rnd.of("Mi stanco. Per ora.", "La luce ti ha salvato. Stavolta."); }
    public static String isolation() { return Rnd.of("Non c'è nessuno qui. Solo noi due.", "Senti? Il mondo ha smesso di respirare."); }
    public static String isolationEnd() { return "Tornerà il rumore. Ma ti ricorderai com'era."; }
    public static String villageLine() { return Rnd.of("I villager lo sanno. Loro mi vedono sempre.", "Guardali. Hanno paura di ciò che hanno già visto."); }
    public static String rainLine() { return Rnd.of("La pioggia nasconde i passi... non gli occhi.", "Ogni lampo ti mostra un passo in più."); }
    public static String territorialLine() {
        return Rnd.of("Questa casa ora è mia. Tu puoi restare.", "Ho messo il mio segno intorno alla tua base.", "Dormi pure. La mia porta è sempre aperta.");
    }
    public static String habitLine() { return Rnd.of("Passi sempre da qui. Ho imparato la tua strada.", "Questa strada la conosco a memoria, ormai."); }
    public static String curiosityLine() {
        return Rnd.of("Cosa porti con te? Fa un rumore che mi piace.", "Più scendi in basso, più mi interessi.", "Hai trovato qualcosa che non andava trovato.");
    }
    public static String roomLine() { return Rnd.of("Sapevo che saresti arrivato fin qui.", "Questo posto è fatto di ciò che hai lasciato indietro."); }
    public static String tunnelLine() { return Rnd.of("Qui non c'è niente. Proprio come volevo.", "Hai seguito il tunnel. Tutti lo seguono."); }
    public static String symbolBroken() { return Rnd.of("Hai spezzato il mio segno. Questo non lo dimentico.", "Non toccare ciò che è mio."); }
    public static String allCluesLine() { return "Hai raccolto tutte le pagine. Allora sai già chi sono. O chi sei."; }

    private static final String[][] FAKE_ERRORS = {
            {"§c[Server] §7Exception in thread \"main\" java.lang.NullPointerException", "§8    at ombra.Shadow.watch(Unknown Source) §7...ti sto guardando"},
            {"§c[Errore] §7Impossibile caricare il chunk (0, 0): §kXXXXXXXX", "§8    il mondo ti sta aspettando"},
            {"§4§k#####§r §cERRORE 0x0000DEAD§r §4§k#####", "§8    perché stai ancora giocando?"}
    };

    public static String[] fakeError() {
        return FAKE_ERRORS[Rnd.range(0, FAKE_ERRORS.length - 1)];
    }

    public static String jumpTitle() { return Rnd.of("TI VEDO", "NON GUARDARE", "ERI TU", "DIETRO DI TE"); }

    // ---------- ondate ----------
    public static final String[] WAVE_NAMES = {
            "", "Osservazione", "Persecuzione", "La caccia comincia", "Bagliore", "Fuoco profondo",
            "Imboscata", "Il Prescelto", "Sotto lo sguardo", "Caccia finale"
    };

    public static String waveLine(int wave) {
        return switch (wave) {
            case 2 -> Rnd.of("Ora ti seguirò. Non perderò più il tuo odore.", "Hai fatto abbastanza rumore. Adesso ti cerco.");
            case 3 -> "Ferro. Ti senti al sicuro dentro quel metallo? Il ferro non ferma ciò che non ha corpo. La vera caccia è appena iniziata.";
            case 4 -> "Il tuo primo diamante. Luccica bene tra le tue mani... peccato non possa tenerlo a lungo.";
            case 5 -> "Il fuoco ti ha lasciato entrare. Qui sotto non sono mai stato così vicino.";
            case 6 -> "Ti vesti di luce. Ora sei visibile da molto, molto lontano.";
            case 7 -> "Netherite. Sei diventato abbastanza forte da affrontarmi. Lo sento. Preparati: ti aspetto dove la luce finisce.";
            case 8 -> "Il drago è caduto. Pensavi fosse il più grande dei tuoi nemici? Ti sto osservando fin dall'inizio. Da quando hai piantato il primo albero.";
            case 9 -> "Basta attese. Prendi la lama nata dal fuoco profondo. Io ti aspetto.";
            default -> "Ti osservo.";
        };
    }

    // ---------- risposte ai messaggi del giocatore ----------
    /** Risposta a parole chiave scritte dal giocatore in chat, o null se non c'e' niente da dire. */
    public static String reply(String raw, boolean hasNetheriteSword) {
        String s = raw.toLowerCase(Locale.ROOT);
        if (s.contains("herobrine")) return Rnd.of("Non pronunciare quel nome. Non è lui che ti guarda.", "Herobrine? Un nome per sentirti meno solo.");
        if (s.contains("ti uccido") || s.contains("ti ammazzo") || s.contains("morirai") || s.contains("i will kill")) {
            return hasNetheriteSword ? "Quella lama... la sento da qui. Allora sai già come finisce." : "Con cosa? Hai le mani vuote. O quasi.";
        }
        if (s.contains("chi sei") || s.contains("who are you")) return Rnd.of("Sono ciò che resta quando nessuno ti ricorda.", "Chiedimelo quando avrai letto tutte le pagine.");
        if (s.contains("basta") || s.contains("smettila") || s.contains("vattene") || s.contains("leave me")) return Rnd.of("Non decidi tu quando finisce.", "Posso andarmene. Ma non lo faccio.");
        if (s.contains("aiuto") || s.contains("help")) return Rnd.of("Nessuno ti sente. Solo io.", "Eccomi. Sono sempre io che ti sento.");
        if (s.contains("ombra") || s.contains("shadow")) return Rnd.of("Mi hai chiamato?", "Dillo ancora. Mi piace sentirlo.");
        if (s.contains("ciao") || s.contains("hello") || s.equals("hi") || s.contains("salve")) return Rnd.of("Ciao. Ti vedo.", "Ciao. Sei sempre stato qui, vero?");
        return null;
    }
}
