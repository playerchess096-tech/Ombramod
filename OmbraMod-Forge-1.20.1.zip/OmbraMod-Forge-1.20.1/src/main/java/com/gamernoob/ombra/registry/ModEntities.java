package com.gamernoob.ombra.registry;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.entity.ShadowEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, OmbraMod.MODID);

    private ModEntities() {}

    public static final RegistryObject<EntityType<ShadowEntity>> SHADOW = ENTITIES.register("shadow",
            () -> EntityType.Builder.of(ShadowEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.3F)
                    .clientTrackingRange(10)
                    .fireImmune()
                    .build(OmbraMod.MODID + ":shadow"));
}
