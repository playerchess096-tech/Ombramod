package com.gamernoob.ombra.events;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.command.OmbraCommand;
import com.gamernoob.ombra.director.ShadowDirector;
import com.gamernoob.ombra.director.WorldFx;
import com.gamernoob.ombra.util.Scheduler;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerWakeUpEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Collegamento tra gli eventi di Forge (lato server) e il direttore dell'Ombra. */
@Mod.EventBusSubscriber(modid = OmbraMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ForgeEvents {
    private ForgeEvents() {}

    @SubscribeEvent
    public static void serverTick(TickEvent.ServerTickEvent e) {
        if (e.phase == TickEvent.Phase.END) ShadowDirector.serverTick();
    }

    @SubscribeEvent
    public static void serverStarted(ServerStartedEvent e) {
        Scheduler.clear();
        ShadowDirector.reset();
        WorldFx.restoreTorches(e.getServer(), true);
    }

    @SubscribeEvent
    public static void serverStopping(ServerStoppingEvent e) {
        WorldFx.restoreTorches(e.getServer(), true);
        Scheduler.clear();
    }

    @SubscribeEvent
    public static void login(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ShadowDirector.onLogin(sp);
    }

    @SubscribeEvent
    public static void logout(PlayerEvent.PlayerLoggedOutEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ShadowDirector.onLogout(sp);
    }

    @SubscribeEvent
    public static void respawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ShadowDirector.onRespawn(sp);
    }

    @SubscribeEvent
    public static void dimension(PlayerEvent.PlayerChangedDimensionEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ShadowDirector.onDimensionChange(sp, e.getTo());
    }

    @SubscribeEvent
    public static void death(LivingDeathEvent e) {
        LivingEntity victim = e.getEntity();
        if (victim.level().isClientSide()) return;
        if (victim instanceof ServerPlayer sp) {
            ShadowDirector.onPlayerDeath(sp, e.getSource());
        } else if (victim instanceof EnderDragon && victim.level() instanceof ServerLevel sl) {
            ShadowDirector.onDragonKilled(sl);
        }
    }

    @SubscribeEvent
    public static void breakBlock(BlockEvent.BreakEvent e) {
        if (e.getPlayer() instanceof ServerPlayer sp) ShadowDirector.onBlockBroken(sp, e.getState(), e.getPos());
    }

    @SubscribeEvent
    public static void placeBlock(BlockEvent.EntityPlaceEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp && e.getLevel() instanceof Level lv) {
            ShadowDirector.onBlockPlaced(sp, e.getPlacedBlock(), e.getPos(), lv);
        }
    }

    @SubscribeEvent
    public static void wake(PlayerWakeUpEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ShadowDirector.onWake(sp);
    }

    @SubscribeEvent
    public static void chat(ServerChatEvent e) {
        final ServerPlayer sp = e.getPlayer();
        final String text = e.getRawText();
        sp.server.execute(() -> ShadowDirector.onChat(sp, text));
    }

    @SubscribeEvent
    public static void commands(RegisterCommandsEvent e) {
        OmbraCommand.register(e.getDispatcher());
    }
}
