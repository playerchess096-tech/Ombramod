package com.gamernoob.ombra.director;

/** Catalogo degli eventi horror: livello minimo (numero di ondate sbloccate), peso e ricarica in secondi. */
public enum HorrorEvent {
    MESSAGE(1, 10, 40),
    FRIENDLY(1, 0, 100),
    FOOTSTEPS(1, 10, 120),
    DOOR(1, 6, 150),
    THUNDER(1, 5, 180),
    HEARTBEAT(1, 5, 150),
    WATCHER(1, 8, 180),
    ANIMALS(1, 5, 240),
    CAVE_ECHO(1, 7, 120),
    RAIN(1, 8, 240),
    TORCHES(2, 5, 240),
    SIGNS(2, 5, 200),
    FAKE_JOIN(2, 4, 600),
    DARKNESS(2, 4, 300),
    VILLAGERS(2, 4, 480),
    TREES(2, 3, 600),
    ITEM_DROP(2, 3, 600),
    STALK(2, 6, 360),
    SKY(3, 3, 600),
    GLITCH(3, 4, 240),
    FAKE_ERROR(3, 3, 480),
    STRUCTURE(3, 2, 900),
    TUNNEL(3, 2, 900),
    CHASE(2, 4, 600),
    JUMPSCARE(3, 2, 600),
    MEMORY_ROOM(4, 1, 1200),
    ISOLATION(4, 2, 900),
    AMBUSH(4, 3, 420);

    public final int minLevel;
    public final int weight;
    public final int cooldown;

    HorrorEvent(int minLevel, int weight, int cooldown) {
        this.minLevel = minLevel;
        this.weight = weight;
        this.cooldown = cooldown;
    }
}
