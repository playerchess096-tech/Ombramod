package com.gamernoob.ombra.director;

import com.gamernoob.ombra.data.OmbraData;
import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.gamernoob.ombra.net.FxPacket;
import com.gamernoob.ombra.registry.ModSounds;
import com.gamernoob.ombra.story.Dialogue;
import com.gamernoob.ombra.story.Personality;
import com.gamernoob.ombra.util.Scheduler;
import com.gamernoob.ombra.util.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

import java.util.UUID;

/**
 * Le nove ondate. Ondata 1 (Osservazione) e' sempre attiva, la 2 (Persecuzione) scatta col tempo, le 3-8 scattano
 * UNA sola volta al primo completamento di ogni obiettivo, la 9 (Caccia finale) quando le altre sono tutte superate.
 * Le ondate sbloccate sono salvate nel profilo: uscire e rientrare non le azzera.
 */
public final class Waves {
    private Waves() {}

    /** Mette in coda un'ondata (non viene sbloccata subito: c'e' un intervallo tra una e l'altra). */
    public static void queue(PlayerProfile pr, int wave) {
        int bit = 1 << (wave - 1);
        if ((pr.waves & bit) == 0) pr.pending |= bit;
    }

    public static void process(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st) {
        // la caccia finale si accoda quando le ondate 3..8 sono tutte sbloccate
        if (!pr.hasWave(9) && (pr.waves & 0xFC) == 0xFC && (pr.pending & 0x100) == 0 && !pr.defeated) queue(pr, 9);
        if (pr.pending == 0) return;
        long gap = pr.nightmare ? 35L : 75L;
        if (st.lastWaveSec != 0L && pr.seconds - st.lastWaveSec < gap) return;
        int wave = Integer.numberOfTrailingZeros(pr.pending) + 1;
        unlock(p, pr, st, wave);
    }

    private static void unlock(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st, int wave) {
        int bit = 1 << (wave - 1);
        pr.waves |= bit;
        pr.pending &= ~bit;
        st.lastWaveSec = pr.seconds;
        st.waveBurstUntil = pr.seconds + 150;
        st.lastEventSec = pr.seconds;
        pr.tension = Math.min(100.0F, pr.tension + 18.0F + wave * 2.0F);
        UUID id = p.getUUID();
        Fx.soundSelf(p, ModSounds.BELL.get(), 0.9F, 0.8F);
        Fx.title(p, "§4Ondata " + wave, "§7" + Dialogue.WAVE_NAMES[wave], 10, 50, 20);
        Fx.sayLater(p, 60, Dialogue.waveLine(wave));
        Scheduler.laterFor(id, 140, pl -> themed(pl, wave));
    }

    /** Evento a tema che segue l'annuncio di ogni ondata. */
    private static void themed(ServerPlayer p, int wave) {
        PlayerProfile pr = ShadowDirector.profile(p);
        ShadowDirector.State st = ShadowDirector.state(p.getUUID());
        OmbraData data = OmbraData.get(p.server);
        switch (wave) {
            case 2 -> HorrorEvents.stalk(p, pr, st);
            case 3 -> HorrorEvents.chase(p, pr, st);
            case 4 -> {
                HorrorEvents.darkness(p, pr);
                HorrorEvents.watcher(p, pr, st, data);
            }
            case 5 -> {
                Fx.soundSelfAmbient(p, ModSounds.DRONE_NETHER.get(), 0.7F, 1.0F);
                HorrorEvents.stalk(p, pr, st);
            }
            case 6 -> HorrorEvents.ambush(p, pr, st);
            case 7 -> {
                HorrorEvents.glitch(p, pr);
                HorrorEvents.watcher(p, pr, st, data);
            }
            case 8 -> HorrorEvents.isolation(p, pr);
            default -> {
                // l'ondata 9 e' gestita da finalHunt()
            }
        }
    }

    // =================================================================== caccia finale

    /** Chiamato ogni secondo: se la caccia e' attiva e l'Ombra non c'e', la fa comparire (duello se hai la spada). */
    public static void finalHunt(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st) {
        if (pr.hasWave(9) && !pr.defeated && !pr.huntActive) {
            pr.huntActive = true;
            Fx.soundSelfAmbient(p, ModSounds.DRONE_HUNT.get(), 0.9F, 1.0F);
            Fx.send(p, FxPacket.CLOSE, 80, 70);
        }
        if (!pr.huntActive || pr.defeated) return;
        if (ShadowDirector.shadowOf(p) != null) return;
        if (pr.seconds < pr.silenceUntil || st.lastHuntSpawnSec + 20 > pr.seconds) return;
        ServerLevel level = p.serverLevel();
        BlockPos spot = Util.findSpot(level, p.blockPosition(), 14.0D, 22.0D, 20, null);
        if (spot == null) return;
        st.lastHuntSpawnSec = pr.seconds;
        if (ShadowDirector.hasNetheriteSword(p)) {
            ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.DUEL, 0);
            if (e != null) {
                Fx.say(p, Dialogue.duelStart(), true);
                Fx.soundSelf(p, ModSounds.RISER.get(), 1.0F, 1.0F);
            }
        } else {
            ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.CHASE, 1100);
            if (e != null) {
                pr.silenceUntil = pr.seconds + 200;
                Fx.sayLater(p, 40, "Non sei pronto. Cerca nel Nether il metallo che mi taglia. Poi torna da me.");
            }
        }
    }

    // =================================================================== modalita' incubo

    public static void toggleNightmare(ServerPlayer p, PlayerProfile pr) {
        if (!pr.nightmare) {
            pr.nightmare = true;
            pr.defeated = false;
            pr.huntActive = false;
            pr.nightmareRuns++;
            pr.waves = 0b11;
            pr.pending = 0;
            pr.tension = 20.0F;
            pr.anger = 10.0F;
            pr.silenceUntil = pr.seconds + 20;
            pr.personality = Personality.AGGRESSIVE.ordinal();
            pr.personalityUntil = pr.seconds + 400;
            if (pr.hasFlag(PlayerProfile.F_IRON)) queue(pr, 3);
            if (pr.hasFlag(PlayerProfile.F_DIAMOND)) queue(pr, 4);
            if (pr.hasFlag(PlayerProfile.F_NETHER)) queue(pr, 5);
            if (pr.hasFlag(PlayerProfile.F_DIAMOND_ARMOR)) queue(pr, 6);
            if (pr.hasFlag(PlayerProfile.F_NETHERITE_ARMOR)) queue(pr, 7);
            if (pr.hasFlag(PlayerProfile.F_DRAGON)) queue(pr, 8);
            Fx.title(p, "§4MODALITÀ INCUBO", "§7L'Ombra è tornata. Più forte. Solo la spada di netherite può fermarla.", 10, 80, 30);
            Fx.soundSelf(p, ModSounds.THUMP.get(), 1.0F, 0.8F);
            Fx.sayLater(p, 90, "Credevi che fosse finita? Adesso so come ti muovi.");
        } else {
            pr.nightmare = false;
            pr.defeated = true;
            pr.huntActive = false;
            ShadowEntity e = ShadowDirector.shadowOf(p);
            if (e != null) e.vanish(false);
            Fx.action(p, "§7L'incubo si dissolve.");
        }
    }

    // =================================================================== finale

    private static void giveOrDrop(ServerPlayer p, ItemStack stack) {
        if (!p.getInventory().add(stack)) p.drop(stack, false);
    }

    /** Scena finale: normale oppure finale segreto (se hai trovato tutte le pagine prima di affrontarla). */
    public static void playFinale(ServerPlayer p, PlayerProfile pr, boolean alt) {
        UUID id = p.getUUID();
        Fx.send(p, FxPacket.CLEAR, 0, 0);
        p.removeEffect(MobEffects.DARKNESS);
        p.removeEffect(MobEffects.BLINDNESS);
        p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 200, 1));
        if (!alt) {
            Fx.soundSelfAmbient(p, ModSounds.VICTORY.get(), 1.0F, 1.0F);
            Fx.title(p, "§fL'OMBRA SVANISCE", "§7La lama nata dal fuoco profondo ha ricordato il suo nome.", 20, 90, 30);
            Fx.sayLater(p, 100, "Quella lama... l'unica che poteva.");
            Fx.sayLater(p, 200, "Mi chiamavo... non importa. Grazie per avermelo ricordato.");
            Fx.sayLater(p, 300, "Il mondo ti seguirà sempre. Ma io non ti seguirò più.");
            Scheduler.laterFor(id, 420, pl -> Fx.action(pl, "§6Modalità Incubo sbloccata: usa il Cuore dell'Ombra (Maiusc + clic destro)."));
        } else {
            Fx.soundSelfAmbient(p, ModSounds.ENDING_ALT.get(), 1.0F, 1.0F);
            Fx.title(p, "§fERI TU", "§7Ogni morte che hai lasciato indietro...", 20, 100, 30);
            Fx.sayLater(p, 120, "Ti ho raccontato tutto, ora lo sai.");
            Fx.sayLater(p, 240, "Ogni volta che sei morto, qualcosa di te è rimasto sotto la roccia. "
                    + pr.deaths + " volte. Le ho conservate tutte.");
            Fx.sayLater(p, 380, "Non ero io a seguirti. Eri tu che non riuscivi a lasciare andare ciò che avevi perso.");
            Fx.sayLater(p, 520, "Ora le restituisco. Cammina leggero.");
            Scheduler.laterFor(id, 640, pl -> {
                Fx.title(pl, "§6FINALE SEGRETO", "§eL'Ombra ha trovato la pace", 20, 90, 40);
                giveOrDrop(pl, new ItemStack(Items.TOTEM_OF_UNDYING));
            });
            Scheduler.laterFor(id, 800, pl -> Fx.action(pl, "§6Modalità Incubo sbloccata: usa il Cuore dell'Ombra (Maiusc + clic destro)."));
        }
    }
}
