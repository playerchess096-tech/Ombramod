package com.gamernoob.ombra.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Dati dell'Ombra salvati nel mondo: profili dei giocatori, chunk costruiti, torce spente, stanze, simboli. */
public class OmbraData extends SavedData {
    public static final String NAME = "ombra_data";
    public static final int BUILT_THRESHOLD = 8;
    public static final int BASE_THRESHOLD = 45;

    /** Una torcia spenta che va riaccesa (persistita, cosi' non si perde mai). */
    public static final class TorchEntry {
        public String dim;
        public int x;
        public int y;
        public int z;
        public int kind;
        public int face;
        public long at;
    }

    /** Una stanza nascosta: quando il giocatore ci entra l'Ombra parla. */
    public static final class RoomEntry {
        public String dim;
        public int x;
        public int y;
        public int z;
        public int kind;
        public String text = "";
        public boolean done;
    }

    public final Map<UUID, PlayerProfile> profiles = new HashMap<>();
    public final Map<Long, Integer> built = new HashMap<>();
    public final List<TorchEntry> torches = new ArrayList<>();
    public final List<RoomEntry> rooms = new ArrayList<>();
    public final Set<Long> symbols = new HashSet<>();
    public boolean anyVictory;

    public static OmbraData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(OmbraData::load, OmbraData::new, NAME);
    }

    public PlayerProfile profile(UUID id) {
        return profiles.computeIfAbsent(id, k -> new PlayerProfile());
    }

    public void placed(int chunkX, int chunkZ, int weight) {
        built.merge(ChunkPos.asLong(chunkX, chunkZ), weight, Integer::sum);
        if (built.size() > 6000) built.values().removeIf(v -> v < 3);
        setDirty();
    }

    public int builtCount(int chunkX, int chunkZ) {
        return built.getOrDefault(ChunkPos.asLong(chunkX, chunkZ), 0);
    }

    public boolean isBuilt(int chunkX, int chunkZ) {
        return builtCount(chunkX, chunkZ) >= BUILT_THRESHOLD;
    }

    public boolean isBuiltAt(BlockPos pos) {
        return isBuilt(pos.getX() >> 4, pos.getZ() >> 4);
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag pl = new ListTag();
        for (Map.Entry<UUID, PlayerProfile> e : profiles.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putUUID("id", e.getKey());
            c.put("data", e.getValue().save());
            pl.add(c);
        }
        tag.put("profiles", pl);

        ListTag bl = new ListTag();
        for (Map.Entry<Long, Integer> e : built.entrySet()) {
            CompoundTag c = new CompoundTag();
            c.putLong("k", e.getKey());
            c.putInt("v", e.getValue());
            bl.add(c);
        }
        tag.put("built", bl);

        ListTag tl = new ListTag();
        for (TorchEntry t : torches) {
            CompoundTag c = new CompoundTag();
            c.putString("dim", t.dim);
            c.putInt("x", t.x);
            c.putInt("y", t.y);
            c.putInt("z", t.z);
            c.putInt("kind", t.kind);
            c.putInt("face", t.face);
            c.putLong("at", t.at);
            tl.add(c);
        }
        tag.put("torches", tl);

        ListTag rl = new ListTag();
        for (RoomEntry r : rooms) {
            CompoundTag c = new CompoundTag();
            c.putString("dim", r.dim);
            c.putInt("x", r.x);
            c.putInt("y", r.y);
            c.putInt("z", r.z);
            c.putInt("kind", r.kind);
            c.putString("text", r.text);
            c.putBoolean("done", r.done);
            rl.add(c);
        }
        tag.put("rooms", rl);

        long[] sym = new long[symbols.size()];
        int i = 0;
        for (long l : symbols) sym[i++] = l;
        tag.putLongArray("symbols", sym);
        tag.putBoolean("anyVictory", anyVictory);
        return tag;
    }

    public static OmbraData load(CompoundTag tag) {
        OmbraData d = new OmbraData();
        ListTag pl = tag.getList("profiles", Tag.TAG_COMPOUND);
        for (int i = 0; i < pl.size(); i++) {
            CompoundTag c = pl.getCompound(i);
            d.profiles.put(c.getUUID("id"), PlayerProfile.load(c.getCompound("data")));
        }
        ListTag bl = tag.getList("built", Tag.TAG_COMPOUND);
        for (int i = 0; i < bl.size(); i++) {
            CompoundTag c = bl.getCompound(i);
            d.built.put(c.getLong("k"), c.getInt("v"));
        }
        ListTag tl = tag.getList("torches", Tag.TAG_COMPOUND);
        for (int i = 0; i < tl.size(); i++) {
            CompoundTag c = tl.getCompound(i);
            TorchEntry t = new TorchEntry();
            t.dim = c.getString("dim");
            t.x = c.getInt("x");
            t.y = c.getInt("y");
            t.z = c.getInt("z");
            t.kind = c.getInt("kind");
            t.face = c.getInt("face");
            t.at = c.getLong("at");
            d.torches.add(t);
        }
        ListTag rl = tag.getList("rooms", Tag.TAG_COMPOUND);
        for (int i = 0; i < rl.size(); i++) {
            CompoundTag c = rl.getCompound(i);
            RoomEntry r = new RoomEntry();
            r.dim = c.getString("dim");
            r.x = c.getInt("x");
            r.y = c.getInt("y");
            r.z = c.getInt("z");
            r.kind = c.getInt("kind");
            r.text = c.getString("text");
            r.done = c.getBoolean("done");
            d.rooms.add(r);
        }
        for (long l : tag.getLongArray("symbols")) d.symbols.add(l);
        d.anyVictory = tag.getBoolean("anyVictory");
        return d;
    }
}
