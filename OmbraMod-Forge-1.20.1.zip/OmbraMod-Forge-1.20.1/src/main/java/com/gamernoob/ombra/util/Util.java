package com.gamernoob.ombra.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.function.Predicate;

/** Funzioni geometriche e di mondo condivise da entita', eventi e direttore. */
public final class Util {
    private Util() {}

    public static final int SEA_LEVEL = 63;

    /** Direzione orizzontale "dietro" al giocatore (normalizzata). */
    public static Vec3 back(ServerPlayer p) {
        double yaw = Math.toRadians(p.getYRot());
        return new Vec3(Math.sin(yaw), 0.0, -Math.cos(yaw));
    }

    public static Vec3 front(ServerPlayer p) {
        Vec3 b = back(p);
        return new Vec3(-b.x, 0.0, -b.z);
    }

    /** Il giocatore sta guardando direttamente l'entita' (cono + linea di vista)? */
    public static boolean looking(ServerPlayer p, Entity e, double cos) {
        Vec3 look = p.getViewVector(1.0F).normalize();
        Vec3 to = new Vec3(e.getX() - p.getX(), e.getEyeY() - p.getEyeY(), e.getZ() - p.getZ());
        double len = to.length();
        if (len < 1.0E-4) return true;
        if (look.dot(to.scale(1.0 / len)) < cos) return false;
        return p.hasLineOfSight(e);
    }

    public static boolean passable(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.getCollisionShape(l, pos).isEmpty() && s.getFluidState().isEmpty();
    }

    public static boolean solidFloor(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.isFaceSturdy(l, pos, Direction.UP) && s.getFluidState().isEmpty();
    }

    public static boolean standable(ServerLevel l, BlockPos feet) {
        return passable(l, feet) && passable(l, feet.above()) && passable(l, feet.above(2)) && solidFloor(l, feet.below());
    }

    /** Cerca un punto dove una creatura alta puo' stare in piedi, in una corona attorno a un centro. */
    public static BlockPos findSpot(ServerLevel l, BlockPos around, double minR, double maxR, int tries, Predicate<BlockPos> extra) {
        for (int i = 0; i < tries; i++) {
            double ang = Rnd.range(0.0, Math.PI * 2.0);
            double r = Rnd.range(minR, maxR);
            int x = around.getX() + (int) Math.round(Math.cos(ang) * r);
            int z = around.getZ() + (int) Math.round(Math.sin(ang) * r);
            BlockPos s = standableColumn(l, x, around.getY(), z);
            if (s != null && (extra == null || extra.test(s))) return s;
        }
        return null;
    }

    public static BlockPos standableColumn(ServerLevel l, int x, int yRef, int z) {
        if (!l.hasChunkAt(new BlockPos(x, yRef, z))) return null;
        BlockPos.MutableBlockPos m = new BlockPos.MutableBlockPos(x, yRef + 8, z);
        int minY = l.getMinBuildHeight() + 1;
        for (int y = yRef + 8; y > Math.max(minY, yRef - 14); y--) {
            m.setY(y);
            if (standable(l, m)) return m.immutable();
        }
        return null;
    }

    /** Punto visibile dagli occhi del giocatore senza ostacoli? */
    public static boolean canSee(ServerPlayer p, Vec3 target) {
        Vec3 eye = p.getEyePosition();
        BlockHitResult r = p.level().clip(new ClipContext(eye, target, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        return r.getType() == HitResult.Type.MISS;
    }

    public static boolean underground(ServerLevel l, BlockPos pos) {
        if (l.dimension() == Level.NETHER) return true;
        return l.dimension() == Level.OVERWORLD && !l.canSeeSky(pos)
                && l.getBrightness(LightLayer.SKY, pos) <= 3 && pos.getY() < SEA_LEVEL + 8;
    }

    public static boolean night(ServerLevel l) {
        if (l.dimension() != Level.OVERWORLD) return false;
        long t = l.getDayTime() % 24000L;
        return t >= 13000L && t <= 23000L;
    }

    public static String dimId(Level l) {
        return l.dimension().location().toString();
    }

    public static double horizontalDist(Entity a, BlockPos b) {
        double dx = a.getX() - (b.getX() + 0.5);
        double dz = a.getZ() - (b.getZ() + 0.5);
        return Math.sqrt(dx * dx + dz * dz);
    }
}
