package com.gamernoob.ombra;

import com.gamernoob.ombra.config.OmbraConfig;
import com.gamernoob.ombra.net.ModNet;
import com.gamernoob.ombra.registry.ModEntities;
import com.gamernoob.ombra.registry.ModItems;
import com.gamernoob.ombra.registry.ModSounds;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * L'Ombra - mod horror psicologica per Minecraft Forge 1.20.1.
 * Un'entita' persistente che ti osserva, ti parla in chat e cresce con i tuoi progressi.
 */
@Mod(OmbraMod.MODID)
public class OmbraMod {
    public static final String MODID = "ombra";
    public static final Logger LOGGER = LogUtils.getLogger();

    public OmbraMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModSounds.SOUNDS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModItems.ITEMS.register(bus);
        ModItems.TABS.register(bus);
        bus.addListener(this::commonSetup);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, OmbraConfig.SPEC);
    }

    private void commonSetup(final FMLCommonSetupEvent event) {
        event.enqueueWork(ModNet::register);
    }
}
