package com.gamernoob.ombra.net;

import com.gamernoob.ombra.client.ClientFx;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Pacchetto server -> client per gli effetti visivi/sonori locali (solo overlay, nessun danno). */
public final class FxPacket {
    public static final int SHAKE = 1;
    public static final int CLOSE = 2;
    public static final int GLITCH = 3;
    public static final int JUMPSCARE = 4;
    public static final int RED_SKY = 5;
    public static final int ISOLATION = 6;
    public static final int FLASH = 7;
    public static final int STOP_MUSIC = 8;
    public static final int CLEAR = 9;
    public static final int VILLAGE_SILENCE = 10;

    public final int kind;
    public final int dur;
    public final int power;
    public final int extra;

    public FxPacket(int kind, int dur, int power, int extra) {
        this.kind = kind;
        this.dur = dur;
        this.power = power;
        this.extra = extra;
    }

    public static void encode(FxPacket m, FriendlyByteBuf buf) {
        buf.writeVarInt(m.kind);
        buf.writeVarInt(m.dur);
        buf.writeVarInt(m.power);
        buf.writeVarInt(m.extra);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        return new FxPacket(buf.readVarInt(), buf.readVarInt(), buf.readVarInt(), buf.readVarInt());
    }

    public static void handle(FxPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientFx.handle(msg)));
        c.setPacketHandled(true);
    }
}
