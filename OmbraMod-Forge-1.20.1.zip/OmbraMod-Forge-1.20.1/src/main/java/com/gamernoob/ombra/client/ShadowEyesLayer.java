package com.gamernoob.ombra.client;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Occhi luminosi: bianchi di norma, rossi durante gli attacchi preavvisati, azzurri quando e' vulnerabile. */
public class ShadowEyesLayer extends RenderLayer<ShadowEntity, ShadowModel> {
    private static final RenderType WHITE = RenderType.eyes(new ResourceLocation(OmbraMod.MODID, "textures/entity/shadow_eyes.png"));
    private static final RenderType RED = RenderType.eyes(new ResourceLocation(OmbraMod.MODID, "textures/entity/shadow_eyes_red.png"));
    private static final RenderType BLUE = RenderType.eyes(new ResourceLocation(OmbraMod.MODID, "textures/entity/shadow_eyes_blue.png"));

    public ShadowEyesLayer(RenderLayerParent<ShadowEntity, ShadowModel> parent) {
        super(parent);
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, ShadowEntity entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        RenderType type = entity.isTelegraphing() ? RED : (entity.isVulnerable() ? BLUE : WHITE);
        VertexConsumer vc = buffer.getBuffer(type);
        this.getParentModel().renderToBuffer(poseStack, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1.0F, 1.0F, 1.0F, 1.0F);
    }
}
