package com.gamernoob.ombra.director;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.config.OmbraConfig;
import com.gamernoob.ombra.data.OmbraData;
import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.gamernoob.ombra.registry.ModEntities;
import com.gamernoob.ombra.story.Clues;
import com.gamernoob.ombra.story.Dialogue;
import com.gamernoob.ombra.story.Personality;
import com.gamernoob.ombra.util.Rnd;
import com.gamernoob.ombra.util.Scheduler;
import com.gamernoob.ombra.util.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.SculkCatalystBlockEntity;
import net.minecraft.world.level.block.entity.SculkShriekerBlockEntity;
import net.minecraft.world.level.block.entity.SpawnerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Il "regista": ogni secondo osserva ogni giocatore, aggiorna tensione/rabbia/abitudini, sblocca le ondate,
 * sceglie gli eventi horror con probabilita', intervalli e condizioni (niente ripetizioni eccessive).
 */
public final class ShadowDirector {
    private ShadowDirector() {}

    /** Stato temporaneo (non salvato) di un giocatore. */
    public static final class State {
        public long nextEventSec;
        public long lastEventSec;
        public long lastWaveSec;
        public long waveBurstUntil;
        public long lastCuriositySec;
        public long lastTerritorySec;
        public long lastHabitSec;
        public long lastSpawnerSec;
        public long lastReplySec;
        public long lastHuntSpawnSec;
        public UUID shadowId;
        public String pendingDeathLine;
        public final Map<String, Long> cooldown = new HashMap<>();
    }

    private static final Map<UUID, State> STATES = new HashMap<>();
    private static int tickCounter;

    private static final Item[] VALUABLES = {
            Items.NETHERITE_INGOT, Items.NETHERITE_SCRAP, Items.ANCIENT_DEBRIS, Items.DIAMOND_BLOCK, Items.NETHER_STAR,
            Items.ELYTRA, Items.TOTEM_OF_UNDYING, Items.ENCHANTED_GOLDEN_APPLE, Items.BEACON, Items.DRAGON_EGG
    };

    public static State state(UUID id) {
        return STATES.computeIfAbsent(id, k -> new State());
    }

    public static PlayerProfile profile(ServerPlayer p) {
        return OmbraData.get(p.server).profile(p.getUUID());
    }

    public static void reset() {
        STATES.clear();
        tickCounter = 0;
    }

    public static void resetState(UUID id) {
        STATES.remove(id);
    }

    /** Un giocatore che ha gia' vinto (e non e' in modalita' incubo) viene lasciato in pace. */
    public static boolean active(PlayerProfile pr) {
        return !pr.defeated || pr.nightmare;
    }

    // =================================================================== ciclo principale

    public static void serverTick() {
        Scheduler.tick();
        tickCounter++;
        if (tickCounter % 20 != 0) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        OmbraData data = OmbraData.get(server);
        for (ServerPlayer p : new ArrayList<>(server.getPlayerList().getPlayers())) {
            try {
                secondTick(p, data);
            } catch (Exception ex) {
                OmbraMod.LOGGER.error("Errore nel direttore dell'Ombra", ex);
            }
        }
    }

    private static void secondTick(ServerPlayer p, OmbraData data) {
        if (p.isSpectator() || (p.isCreative() && !OmbraConfig.AFFECT_CREATIVE.get())) return;
        PlayerProfile pr = data.profile(p.getUUID());
        State st = state(p.getUUID());
        pr.seconds++;
        if (!active(pr)) return;
        ServerLevel level = p.serverLevel();

        trackProgress(p, pr);
        Waves.process(p, pr, st);
        trackWorld(p, pr, st, level);
        updateTension(p, pr, st, level);
        Personality.rotate(pr);
        validateShadow(p, pr, st);
        Waves.finalHunt(p, pr, st);
        HorrorEvents.roomTrigger(p, pr, data);
        scheduleEvents(p, pr, st, data, level);
        if (pr.seconds % 20 == 0) data.setDirty();
    }

    // =================================================================== progressi (ogni obiettivo scatta UNA sola volta)

    private static boolean wearing(ServerPlayer p, Item head, Item chest, Item legs, Item feet) {
        return p.getItemBySlot(EquipmentSlot.HEAD).is(head) && p.getItemBySlot(EquipmentSlot.CHEST).is(chest)
                && p.getItemBySlot(EquipmentSlot.LEGS).is(legs) && p.getItemBySlot(EquipmentSlot.FEET).is(feet);
    }

    public static boolean hasItem(ServerPlayer p, Item item) {
        for (ItemStack s : p.getInventory().items) {
            if (s.is(item)) return true;
        }
        for (ItemStack s : p.getInventory().offhand) {
            if (s.is(item)) return true;
        }
        return false;
    }

    public static boolean hasNetheriteSword(ServerPlayer p) {
        return hasItem(p, Items.NETHERITE_SWORD);
    }

    private static void trackProgress(ServerPlayer p, PlayerProfile pr) {
        if (!pr.hasFlag(PlayerProfile.F_IRON)
                && wearing(p, Items.IRON_HELMET, Items.IRON_CHESTPLATE, Items.IRON_LEGGINGS, Items.IRON_BOOTS)) {
            pr.flags |= PlayerProfile.F_IRON;
            Waves.queue(pr, 3);
        }
        if (!pr.hasFlag(PlayerProfile.F_DIAMOND) && hasItem(p, Items.DIAMOND)) {
            pr.flags |= PlayerProfile.F_DIAMOND;
            Waves.queue(pr, 4);
        }
        if (!pr.hasFlag(PlayerProfile.F_NETHER) && p.level().dimension() == Level.NETHER) {
            pr.flags |= PlayerProfile.F_NETHER;
            pr.addMemory("NETHER", Util.dimId(p.level()), p.blockPosition(), "");
            Waves.queue(pr, 5);
        }
        if (!pr.hasFlag(PlayerProfile.F_DIAMOND_ARMOR)
                && wearing(p, Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS)) {
            pr.flags |= PlayerProfile.F_DIAMOND_ARMOR;
            pr.addMemory("ARMOR", Util.dimId(p.level()), p.blockPosition(), "diamond");
            Waves.queue(pr, 6);
        }
        if (!pr.hasFlag(PlayerProfile.F_NETHERITE_ARMOR)
                && wearing(p, Items.NETHERITE_HELMET, Items.NETHERITE_CHESTPLATE, Items.NETHERITE_LEGGINGS, Items.NETHERITE_BOOTS)) {
            pr.flags |= PlayerProfile.F_NETHERITE_ARMOR;
            Waves.queue(pr, 7);
        }
        if (pr.seconds >= OmbraConfig.WAVE2_MINUTES.get() * 60L) Waves.queue(pr, 2);
    }

    // =================================================================== osservazione del giocatore

    private static boolean carriesValuables(ServerPlayer p) {
        for (Item it : VALUABLES) {
            if (hasItem(p, it)) return true;
        }
        return false;
    }

    private static void trackWorld(ServerPlayer p, PlayerProfile pr, State st, ServerLevel level) {
        BlockPos pos = p.blockPosition();
        long ck = ChunkPos.asLong(pos.getX() >> 4, pos.getZ() >> 4);
        pr.bumpHabit(ck);
        if (pr.seconds % 600 == 0) pr.decayHabits();

        // curiosita': profondita', oggetti preziosi, spawner e strutture rare nel chunk
        float cur = pr.curiosity;
        if (level.dimension() == Level.OVERWORLD) {
            if (pos.getY() < 0) cur += 0.4F;
            else if (pos.getY() < 30) cur += 0.15F;
        }
        if (pr.seconds % 5 == 0 && carriesValuables(p)) cur += 2.5F;
        if (pr.seconds % 4 == 0) {
            LevelChunk chunk = level.getChunkAt(pos);
            for (BlockEntity be : chunk.getBlockEntities().values()) {
                boolean rare = be instanceof SpawnerBlockEntity || be instanceof SculkShriekerBlockEntity || be instanceof SculkCatalystBlockEntity;
                if (rare && be.getBlockPos().distSqr(pos) < 12.0D * 12.0D) {
                    cur += 6.0F;
                    if (st.lastSpawnerSec + 300 < pr.seconds) {
                        st.lastSpawnerSec = pr.seconds;
                        Fx.say(p, Dialogue.spawnerNearLine());
                    }
                    break;
                }
            }
        }
        pr.curiosity = Mth.clamp(cur - 0.12F, 0.0F, 100.0F);
        if (pr.curiosity >= 60.0F && st.lastCuriositySec + 600 < pr.seconds) {
            st.lastCuriositySec = pr.seconds;
            Fx.say(p, Dialogue.curiosityLine());
            pr.tension = Math.min(100.0F, pr.tension + 3.0F);
        }
        // territorio: la base e' "sua"
        if (pr.hasBase && Util.horizontalDist(p, new BlockPos(pr.baseX, pr.baseY, pr.baseZ)) < 40.0D
                && st.lastTerritorySec + 900 < pr.seconds && Rnd.chance(0.02D)) {
            st.lastTerritorySec = pr.seconds;
            Fx.say(p, Dialogue.territorialLine());
        }
        // abitudini: le strade che percorri spesso
        if (pr.habitCount(ck) >= 90 && st.lastHabitSec + 900 < pr.seconds && Rnd.chance(0.02D)) {
            st.lastHabitSec = pr.seconds;
            Fx.say(p, Dialogue.habitLine());
        }
    }

    /** Tensione invisibile: sale con buio, profondita', vita bassa e presenza dell'Ombra; scende nei periodi di calma. */
    private static void updateTension(ServerPlayer p, PlayerProfile pr, State st, ServerLevel level) {
        float t = pr.tension;
        BlockPos pos = p.blockPosition();
        int light = level.getMaxLocalRawBrightness(pos);
        boolean shadowThere = shadowOf(p) != null;
        if (light <= 3) t += 0.25F;
        if (Util.underground(level, pos)) t += 0.10F;
        if (p.getHealth() < 7.0F) t += 0.15F;
        if (shadowThere) t += 0.20F;
        if (!shadowThere && pr.seconds - st.lastEventSec > 60) t -= 0.45F;
        if (light >= 12) t -= 0.10F;
        pr.anger = Math.max(0.0F, pr.anger - 0.02F);
        pr.tension = Mth.clamp(t, 3.0F * pr.level(), 100.0F);
    }

    // =================================================================== l'entita' fisica

    public static ShadowEntity shadowOf(ServerPlayer p) {
        State st = STATES.get(p.getUUID());
        if (st == null || st.shadowId == null) return null;
        Entity e = p.serverLevel().getEntity(st.shadowId);
        if (e instanceof ShadowEntity se && se.isAlive()) return se;
        return null;
    }

    public static ShadowEntity spawnShadow(ServerPlayer p, BlockPos pos, ShadowEntity.Mode mode, int life) {
        if (shadowOf(p) != null) return null;
        ServerLevel level = p.serverLevel();
        PlayerProfile pr = profile(p);
        ShadowEntity e = ModEntities.SHADOW.get().create(level);
        if (e == null) return null;
        e.moveTo(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, 0.0F, 0.0F);
        e.setup(p, mode, life, pr.nightmare);
        level.addFreshEntity(e);
        state(p.getUUID()).shadowId = e.getUUID();
        return e;
    }

    private static void validateShadow(ServerPlayer p, PlayerProfile pr, State st) {
        if (st.shadowId == null) return;
        if (shadowOf(p) == null) {
            st.shadowId = null;
            long quiet = pr.seconds + Rnd.range(25, 70) / (pr.nightmare ? 2 : 1);
            pr.silenceUntil = Math.max(pr.silenceUntil, quiet);
            st.lastEventSec = pr.seconds;
        }
    }

    public static void addAnger(ServerPlayer p, float v) {
        PlayerProfile pr = profile(p);
        pr.anger = Math.min(100.0F, pr.anger + v);
        pr.tension = Math.min(100.0F, pr.tension + v * 0.5F);
    }

    // =================================================================== scelta degli eventi

    private static double intensity(PlayerProfile pr, State st) {
        double hours = Math.min(1.0D, pr.seconds / (3.0D * 3600.0D));
        return 0.06D * pr.level() + 0.35D * (pr.tension / 100.0D) + 0.25D * hours + 0.15D * (pr.anger / 100.0D) + (pr.nightmare ? 0.25D : 0.0D);
    }

    private static int nextInterval(PlayerProfile pr, State st) {
        double base = 170.0D - 120.0D * Math.min(1.0D, intensity(pr, st));
        base /= OmbraConfig.EVENT_FREQUENCY.get();
        if (pr.seconds < st.waveBurstUntil) base *= 0.45D;
        if (pr.nightmare) base *= 0.6D;
        if (!pr.friendlyDone && Personality.of(pr) == Personality.FRIENDLY) base = Math.min(base, 100.0D);
        return (int) Math.max(20.0D, base * Rnd.range(0.7D, 1.4D));
    }

    private static double modifier(HorrorEvent e, Personality ps, boolean raining, boolean underground, boolean night,
                                   boolean nearBase, PlayerProfile pr) {
        double m = 1.0D;
        boolean intense = e == HorrorEvent.JUMPSCARE || e == HorrorEvent.CHASE || e == HorrorEvent.AMBUSH
                || e == HorrorEvent.ISOLATION || e == HorrorEvent.SKY;
        if (intense) m *= 0.5D + pr.tension / 100.0D;
        if (e == HorrorEvent.MESSAGE) {
            if (ps == Personality.SILENT) m *= 0.2D;
            else if (ps == Personality.TAUNTING) m *= 2.0D;
            else if (ps == Personality.FRIENDLY) m *= 1.5D;
        }
        if (e == HorrorEvent.FRIENDLY) m = (ps == Personality.FRIENDLY && !pr.friendlyDone && pr.level() <= 2) ? 30.0D : 0.0D;
        if ((e == HorrorEvent.FOOTSTEPS || e == HorrorEvent.HEARTBEAT) && ps == Personality.SILENT) m *= 1.5D;
        if (e == HorrorEvent.WATCHER) {
            if (night) m *= 1.5D;
            if (nearBase) m *= 1.5D;
        }
        if (e == HorrorEvent.CAVE_ECHO) m *= underground ? (ps == Personality.SILENT ? 3.0D : 2.0D) : 0.0D;
        if (e == HorrorEvent.THUNDER) m *= raining ? 3.0D : 1.0D;
        if (e == HorrorEvent.RAIN) m *= raining ? 6.0D : 0.0D;
        if (e == HorrorEvent.SIGNS && nearBase) m *= 2.0D;
        if (e == HorrorEvent.TORCHES && !OmbraConfig.TORCH_EVENTS.get()) m = 0.0D;
        if (e == HorrorEvent.TREES && (!OmbraConfig.WORLD_CHANGES.get() || underground)) m = 0.0D;
        if ((e == HorrorEvent.STRUCTURE || e == HorrorEvent.TUNNEL || e == HorrorEvent.MEMORY_ROOM)
                && (!OmbraConfig.STRUCTURES.get() || !underground)) m = 0.0D;
        if (e == HorrorEvent.STALK || e == HorrorEvent.CHASE || e == HorrorEvent.AMBUSH) {
            if (ps == Personality.FRIENDLY) m = 0.0D;
            else if (ps == Personality.AGGRESSIVE) m *= 2.5D;
        }
        if (e == HorrorEvent.JUMPSCARE) {
            if (OmbraConfig.JUMPSCARE_LEVEL.get() <= 0 || pr.seconds < pr.jumpscareReadyAt) m = 0.0D;
            else if (ps == Personality.AGGRESSIVE) m *= 1.5D;
        }
        if ((e == HorrorEvent.DARKNESS || e == HorrorEvent.GLITCH || e == HorrorEvent.FAKE_JOIN) && ps == Personality.TAUNTING) m *= 1.4D;
        if (e == HorrorEvent.AMBUSH && ps == Personality.AGGRESSIVE) m *= 1.2D;
        // un giocatore "interessante" (profondo, con oggetti preziosi, vicino a strutture rare) attira l'Ombra
        if (pr.curiosity >= 60.0F && (e == HorrorEvent.WATCHER || e == HorrorEvent.STALK
                || e == HorrorEvent.CAVE_ECHO || e == HorrorEvent.MESSAGE)) m *= 1.5D;
        return m;
    }

    private static void scheduleEvents(ServerPlayer p, PlayerProfile pr, State st, OmbraData data, ServerLevel level) {
        if (st.nextEventSec == 0L) st.nextEventSec = pr.seconds + Rnd.range(60, 140);
        if (pr.seconds < st.nextEventSec) return;
        if (pr.seconds < pr.silenceUntil) {
            st.nextEventSec = pr.silenceUntil + 5;
            return;
        }
        if (shadowOf(p) != null) {
            st.nextEventSec = pr.seconds + 10;
            return;
        }
        boolean ok = fire(p, pr, st, data, level);
        // modalita' incubo: combinazioni di eventi a catena
        if (ok && pr.nightmare && Rnd.chance(0.4D)) {
            UUID id = p.getUUID();
            Scheduler.laterFor(id, Rnd.range(80, 200), pl -> {
                PlayerProfile pr2 = profile(pl);
                State st2 = state(pl.getUUID());
                if (shadowOf(pl) == null) fire(pl, pr2, st2, OmbraData.get(pl.server), pl.serverLevel());
            });
        }
        st.nextEventSec = pr.seconds + nextInterval(pr, st);
    }

    /** Sceglie e lancia un evento (fino a 5 tentativi se le condizioni non sono soddisfatte). */
    public static boolean fire(ServerPlayer p, PlayerProfile pr, State st, OmbraData data, ServerLevel level) {
        Personality ps = Personality.of(pr);
        boolean raining = level.isRaining();
        boolean underground = Util.underground(level, p.blockPosition());
        boolean night = Util.night(level);
        boolean nearBase = pr.hasBase && Util.horizontalDist(p, new BlockPos(pr.baseX, pr.baseY, pr.baseZ)) < 90.0D;

        List<HorrorEvent> cand = new ArrayList<>();
        List<Double> weights = new ArrayList<>();
        for (HorrorEvent e : HorrorEvent.values()) {
            if (e.minLevel > pr.level()) continue;
            if (st.cooldown.getOrDefault(e.name(), 0L) > pr.seconds) continue;
            double w = Math.max(e.weight, e == HorrorEvent.FRIENDLY ? 1 : 0) * modifier(e, ps, raining, underground, night, nearBase, pr);
            if (w <= 0.0D) continue;
            cand.add(e);
            weights.add(w);
        }
        for (int attempt = 0; attempt < 5 && !cand.isEmpty(); attempt++) {
            double total = 0.0D;
            for (double w : weights) total += w;
            double r = Rnd.range(0.0D, total);
            int idx = 0;
            for (; idx < weights.size() - 1; idx++) {
                r -= weights.get(idx);
                if (r <= 0.0D) break;
            }
            HorrorEvent ev = cand.get(idx);
            cand.remove(idx);
            weights.remove(idx);
            boolean done;
            try {
                done = HorrorEvents.run(ev, p, pr, st, data);
            } catch (Exception ex) {
                OmbraMod.LOGGER.error("Errore nell'evento horror " + ev, ex);
                done = false;
            }
            if (done) {
                st.cooldown.put(ev.name(), pr.seconds + ev.cooldown);
                st.lastEventSec = pr.seconds;
                if (OmbraConfig.DEBUG.get()) OmbraMod.LOGGER.info("[Ombra] evento {} per {}", ev, p.getName().getString());
                return true;
            }
        }
        return false;
    }

    // =================================================================== reazioni alle azioni del giocatore

    public static void onLogin(ServerPlayer p) {
        OmbraData data = OmbraData.get(p.server);
        PlayerProfile pr = data.profile(p.getUUID());
        State st = state(p.getUUID());
        st.shadowId = null;
        st.nextEventSec = pr.seconds + Rnd.range(60, 140);
        if (!pr.introDone) {
            pr.introDone = true;
            pr.personality = Personality.FRIENDLY.ordinal();
            pr.personalityUntil = pr.seconds + 900;
            data.setDirty();
        }
    }

    public static void onLogout(ServerPlayer p) {
        ShadowEntity e = shadowOf(p);
        if (e != null) e.vanish(false);
        STATES.remove(p.getUUID());
    }

    public static void onPlayerDeath(ServerPlayer p, DamageSource src) {
        OmbraData data = OmbraData.get(p.server);
        PlayerProfile pr = data.profile(p.getUUID());
        State st = state(p.getUUID());
        pr.deaths++;
        pr.addMemory("DEATH", Util.dimId(p.level()), p.blockPosition(), src.getMsgId());
        pr.tension = Math.min(100.0F, pr.tension + 6.0F);
        if (pr.huntActive) pr.silenceUntil = pr.seconds + 180;
        if (active(pr)) st.pendingDeathLine = Dialogue.deathLine(p, pr, src);
        data.setDirty();
    }

    public static void onRespawn(ServerPlayer p) {
        State st = state(p.getUUID());
        if (st.pendingDeathLine == null) return;
        String line = st.pendingDeathLine;
        st.pendingDeathLine = null;
        PlayerProfile pr = profile(p);
        if (Personality.of(pr) == Personality.SILENT && Rnd.chance(0.5D)) return;
        Fx.sayLater(p, 70, line);
    }

    public static void onWake(ServerPlayer p) {
        PlayerProfile pr = profile(p);
        if (!active(pr)) return;
        pr.addMemory("SLEEP", Util.dimId(p.level()), p.blockPosition(), "");
        pr.tension = Math.min(100.0F, pr.tension + 2.0F);
        if (Rnd.chance(0.8D)) Fx.sayLater(p, 50, Dialogue.sleepLine());
    }

    public static void onBlockBroken(ServerPlayer p, BlockState state, BlockPos pos) {
        OmbraData data = OmbraData.get(p.server);
        PlayerProfile pr = data.profile(p.getUUID());
        if (!active(pr)) return;
        String dim = Util.dimId(p.level());
        if (state.is(Blocks.DIAMOND_ORE) || state.is(Blocks.DEEPSLATE_DIAMOND_ORE)) {
            pr.addMemory("DIAMOND", dim, pos, "");
            pr.curiosity = Math.min(100.0F, pr.curiosity + 8.0F);
            if (Rnd.chance(0.7D)) Fx.sayLater(p, 40, Dialogue.diamondOreLine());
        } else if (state.is(Blocks.ANCIENT_DEBRIS)) {
            pr.addMemory("ANCIENT", dim, pos, "");
            pr.curiosity = Math.min(100.0F, pr.curiosity + 10.0F);
            if (Rnd.chance(0.5D)) Fx.sayLater(p, 40, Dialogue.ancientLine());
        } else if (state.is(Blocks.SPAWNER)) {
            pr.addMemory("SPAWNER", dim, pos, "");
            pr.tension = Math.min(100.0F, pr.tension + 5.0F);
            Fx.sayLater(p, 30, Dialogue.spawnerLine());
        }
        if (data.symbols.remove(pos.asLong())) {
            addAnger(p, 14.0F);
            Fx.sayLater(p, 20, Dialogue.symbolBroken());
            data.setDirty();
        }
    }

    public static void onBlockPlaced(ServerPlayer p, BlockState state, BlockPos pos, Level level) {
        if (level.dimension() != Level.OVERWORLD) return;
        OmbraData data = OmbraData.get(p.server);
        int weight = 1;
        if (state.is(BlockTags.BEDS) || state.is(Blocks.CHEST) || state.is(Blocks.CRAFTING_TABLE)
                || state.is(Blocks.FURNACE) || state.is(Blocks.ENCHANTING_TABLE)) weight = 6;
        int cx = pos.getX() >> 4;
        int cz = pos.getZ() >> 4;
        data.placed(cx, cz, weight);
        int count = data.builtCount(cx, cz);
        PlayerProfile pr = data.profile(p.getUUID());
        if (count >= OmbraData.BASE_THRESHOLD && count > pr.baseWeight * 1.3D) {
            boolean first = !pr.hasBase;
            pr.hasBase = true;
            pr.baseX = pos.getX();
            pr.baseY = pos.getY();
            pr.baseZ = pos.getZ();
            pr.baseWeight = count;
            if (first && active(pr)) {
                pr.addMemory("BASE", Util.dimId(level), pos, "");
                Fx.sayLater(p, 20 * Rnd.range(90, 180), Dialogue.territorialLine());
            }
        }
    }

    public static void onDimensionChange(ServerPlayer p, ResourceKey<Level> to) {
        PlayerProfile pr = profile(p);
        if (to == Level.NETHER && !pr.hasFlag(PlayerProfile.F_NETHER)) {
            pr.flags |= PlayerProfile.F_NETHER;
            pr.addMemory("NETHER", Util.dimId(p.level()), p.blockPosition(), "");
            Waves.queue(pr, 5);
        }
    }

    public static void onDragonKilled(ServerLevel level) {
        for (ServerPlayer p : level.players()) {
            PlayerProfile pr = profile(p);
            if (!pr.hasFlag(PlayerProfile.F_DRAGON)) {
                pr.flags |= PlayerProfile.F_DRAGON;
                Waves.queue(pr, 8);
            }
        }
    }

    /** L'Ombra risponde a parole chiave scritte dal giocatore (con un ritardo credibile). */
    public static void onChat(ServerPlayer p, String text) {
        PlayerProfile pr = profile(p);
        if (!active(pr)) return;
        String reply = Dialogue.reply(text, hasNetheriteSword(p));
        if (reply == null) return;
        State st = state(p.getUUID());
        if (st.lastReplySec + 15 > pr.seconds) return;
        if (Personality.of(pr) == Personality.SILENT && Rnd.chance(0.7D)) return;
        st.lastReplySec = pr.seconds;
        pr.tension = Math.min(100.0F, pr.tension + 2.0F);
        Fx.sayLater(p, Rnd.range(25, 70), reply);
    }

    // =================================================================== vittoria

    public static void onShadowDefeated(ServerLevel level, ShadowEntity e, UUID killerId, UUID ownerId) {
        MinecraftServer srv = level.getServer();
        OmbraData data = OmbraData.get(srv);
        Set<UUID> involved = new LinkedHashSet<>();
        if (ownerId != null) involved.add(ownerId);
        if (killerId != null) involved.add(killerId);
        for (UUID id : involved) {
            ServerPlayer p = srv.getPlayerList().getPlayer(id);
            if (p == null) continue;
            PlayerProfile pr = data.profile(id);
            boolean alt = pr.clues == Clues.ALL;
            pr.defeated = true;
            pr.altEnding = alt;
            pr.nightmare = false;
            pr.huntActive = false;
            pr.anger = 0.0F;
            pr.tension = 0.0F;
            pr.silenceUntil = pr.seconds + 600;
            state(id).shadowId = null;
            Waves.playFinale(p, pr, alt);
        }
        data.anyVictory = true;
        data.setDirty();
    }
}
