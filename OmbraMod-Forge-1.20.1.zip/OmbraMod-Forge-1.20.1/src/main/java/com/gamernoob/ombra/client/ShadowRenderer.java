package com.gamernoob.ombra.client;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Silhouette alta e sottile, scurissima, con occhi che brillano. Da "morta" (falsa sconfitta) giace a terra. */
public class ShadowRenderer extends HumanoidMobRenderer<ShadowEntity, ShadowModel> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(OmbraMod.MODID, "textures/entity/shadow.png");

    public ShadowRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new ShadowModel(ctx.bakeLayer(ModelLayers.ZOMBIE)), 0.4F);
        this.addLayer(new ShadowEyesLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(ShadowEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(ShadowEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(0.92F, 1.28F, 0.92F);
    }

    @Override
    protected void setupRotations(ShadowEntity entity, PoseStack poseStack, float ageInTicks, float rotationYaw, float partialTicks) {
        super.setupRotations(entity, poseStack, ageInTicks, rotationYaw, partialTicks);
        if (entity.isFakeDead() && entity.deathTime == 0) poseStack.mulPose(Axis.ZP.rotationDegrees(90.0F));
    }
}
