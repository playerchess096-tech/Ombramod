package com.gamernoob.ombra.client;

import com.gamernoob.ombra.entity.ShadowEntity;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;

/** Modello umanoide dell'Ombra: testa inclinata quando e' "immobile", braccia alzate durante l'attacco preavvisato. */
public class ShadowModel extends HumanoidModel<ShadowEntity> {
    public ShadowModel(ModelPart root) {
        super(root);
    }

    @Override
    public void setupAnim(ShadowEntity e, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        super.setupAnim(e, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch);
        if (e.isTilted()) this.head.zRot = 0.45F;
        if (e.isTelegraphing()) {
            this.rightArm.xRot = -2.6F;
            this.leftArm.xRot = -2.6F;
        }
    }
}
