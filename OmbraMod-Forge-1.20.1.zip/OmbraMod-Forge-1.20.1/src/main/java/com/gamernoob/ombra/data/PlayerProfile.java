package com.gamernoob.ombra.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Tutto cio' che l'Ombra sa di un giocatore: progressi (ondate), tensione, rabbia, ricordi,
 * abitudini, base, indizi. Viene salvato nel mondo, quindi sopravvive a uscita/rientro.
 */
public class PlayerProfile {
    public static final int F_IRON = 1;
    public static final int F_DIAMOND = 2;
    public static final int F_NETHER = 4;
    public static final int F_DIAMOND_ARMOR = 8;
    public static final int F_NETHERITE_ARMOR = 16;
    public static final int F_DRAGON = 32;

    public static final int MAX_MEMORY = 24;
    public static final int MAX_HABITS = 80;

    /** Un'azione importante del giocatore che l'Ombra ricorda e puo' citare. */
    public static final class Memory {
        public final String type;
        public final String dim;
        public final int x;
        public final int y;
        public final int z;
        public final long sec;
        public final String extra;

        public Memory(String type, String dim, int x, int y, int z, long sec, String extra) {
            this.type = type;
            this.dim = dim;
            this.x = x;
            this.y = y;
            this.z = z;
            this.sec = sec;
            this.extra = extra == null ? "" : extra;
        }

        CompoundTag save() {
            CompoundTag t = new CompoundTag();
            t.putString("type", type);
            t.putString("dim", dim);
            t.putInt("x", x);
            t.putInt("y", y);
            t.putInt("z", z);
            t.putLong("sec", sec);
            t.putString("extra", extra);
            return t;
        }

        static Memory load(CompoundTag t) {
            return new Memory(t.getString("type"), t.getString("dim"), t.getInt("x"), t.getInt("y"), t.getInt("z"),
                    t.getLong("sec"), t.getString("extra"));
        }
    }

    public long seconds;
    public int waves = 1;
    public int pending;
    public int flags;
    public float tension;
    public float anger;
    public float curiosity;
    public int deaths;
    public int clues;
    public int friendlyStage;
    public int nightmareRuns;
    public boolean friendlyDone;
    public boolean defeated;
    public boolean altEnding;
    public boolean nightmare;
    public boolean huntActive;
    public boolean introDone;
    public int personality = 3;
    public long personalityUntil;
    public long silenceUntil;
    public long jumpscareReadyAt;
    public boolean hasBase;
    public int baseX;
    public int baseY;
    public int baseZ;
    public int baseWeight;

    public final List<Memory> memory = new ArrayList<>();
    public final Map<Long, Integer> habits = new HashMap<>();

    public int level() {
        return Integer.bitCount(waves);
    }

    public boolean hasWave(int n) {
        return (waves & (1 << (n - 1))) != 0;
    }

    public boolean hasFlag(int f) {
        return (flags & f) != 0;
    }

    public void addMemory(String type, String dim, BlockPos pos, String extra) {
        memory.add(new Memory(type, dim, pos.getX(), pos.getY(), pos.getZ(), seconds, extra));
        while (memory.size() > MAX_MEMORY) memory.remove(0);
    }

    public Memory lastMemory(String type) {
        for (int i = memory.size() - 1; i >= 0; i--) {
            if (memory.get(i).type.equals(type)) return memory.get(i);
        }
        return null;
    }

    public int habitCount(long chunkKey) {
        return habits.getOrDefault(chunkKey, 0);
    }

    public void bumpHabit(long chunkKey) {
        habits.merge(chunkKey, 1, Integer::sum);
        if (habits.size() > MAX_HABITS) {
            long worst = 0L;
            int min = Integer.MAX_VALUE;
            for (Map.Entry<Long, Integer> e : habits.entrySet()) {
                if (e.getValue() < min) {
                    min = e.getValue();
                    worst = e.getKey();
                }
            }
            habits.remove(worst);
        }
    }

    public void decayHabits() {
        habits.replaceAll((k, v) -> v * 85 / 100);
        habits.values().removeIf(v -> v <= 0);
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putLong("seconds", seconds);
        t.putInt("waves", waves);
        t.putInt("pending", pending);
        t.putInt("flags", flags);
        t.putFloat("tension", tension);
        t.putFloat("anger", anger);
        t.putFloat("curiosity", curiosity);
        t.putInt("deaths", deaths);
        t.putInt("clues", clues);
        t.putInt("friendlyStage", friendlyStage);
        t.putInt("nightmareRuns", nightmareRuns);
        t.putBoolean("friendlyDone", friendlyDone);
        t.putBoolean("defeated", defeated);
        t.putBoolean("altEnding", altEnding);
        t.putBoolean("nightmare", nightmare);
        t.putBoolean("huntActive", huntActive);
        t.putBoolean("introDone", introDone);
        t.putInt("personality", personality);
        t.putLong("personalityUntil", personalityUntil);
        t.putLong("silenceUntil", silenceUntil);
        t.putLong("jumpscareReadyAt", jumpscareReadyAt);
        t.putBoolean("hasBase", hasBase);
        t.putInt("baseX", baseX);
        t.putInt("baseY", baseY);
        t.putInt("baseZ", baseZ);
        t.putInt("baseWeight", baseWeight);
        ListTag mem = new ListTag();
        for (Memory m : memory) mem.add(m.save());
        t.put("memory", mem);
        ListTag hab = new ListTag();
        for (Map.Entry<Long, Integer> e : habits.entrySet()) {
            CompoundTag h = new CompoundTag();
            h.putLong("k", e.getKey());
            h.putInt("v", e.getValue());
            hab.add(h);
        }
        t.put("habits", hab);
        return t;
    }

    public static PlayerProfile load(CompoundTag t) {
        PlayerProfile p = new PlayerProfile();
        p.seconds = t.getLong("seconds");
        p.waves = t.contains("waves") ? t.getInt("waves") : 1;
        if (p.waves == 0) p.waves = 1;
        p.pending = t.getInt("pending");
        p.flags = t.getInt("flags");
        p.tension = t.getFloat("tension");
        p.anger = t.getFloat("anger");
        p.curiosity = t.getFloat("curiosity");
        p.deaths = t.getInt("deaths");
        p.clues = t.getInt("clues");
        p.friendlyStage = t.getInt("friendlyStage");
        p.nightmareRuns = t.getInt("nightmareRuns");
        p.friendlyDone = t.getBoolean("friendlyDone");
        p.defeated = t.getBoolean("defeated");
        p.altEnding = t.getBoolean("altEnding");
        p.nightmare = t.getBoolean("nightmare");
        p.huntActive = t.getBoolean("huntActive");
        p.introDone = t.getBoolean("introDone");
        p.personality = t.contains("personality") ? t.getInt("personality") : 3;
        p.personalityUntil = t.getLong("personalityUntil");
        p.silenceUntil = t.getLong("silenceUntil");
        p.jumpscareReadyAt = t.getLong("jumpscareReadyAt");
        p.hasBase = t.getBoolean("hasBase");
        p.baseX = t.getInt("baseX");
        p.baseY = t.getInt("baseY");
        p.baseZ = t.getInt("baseZ");
        p.baseWeight = t.getInt("baseWeight");
        ListTag mem = t.getList("memory", Tag.TAG_COMPOUND);
        for (int i = 0; i < mem.size(); i++) p.memory.add(Memory.load(mem.getCompound(i)));
        ListTag hab = t.getList("habits", Tag.TAG_COMPOUND);
        for (int i = 0; i < hab.size(); i++) {
            CompoundTag h = hab.getCompound(i);
            p.habits.put(h.getLong("k"), h.getInt("v"));
        }
        return p;
    }
}
