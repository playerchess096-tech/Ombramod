package com.gamernoob.ombra.util;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/** Piccoli aiuti per i numeri casuali (lato server, thread principale). */
public final class Rnd {
    private Rnd() {}

    public static int range(int lo, int hi) {
        return lo >= hi ? lo : ThreadLocalRandom.current().nextInt(lo, hi + 1);
    }

    public static double range(double lo, double hi) {
        return lo >= hi ? lo : ThreadLocalRandom.current().nextDouble(lo, hi);
    }

    public static boolean chance(double p) {
        return ThreadLocalRandom.current().nextDouble() < p;
    }

    public static boolean coin() {
        return ThreadLocalRandom.current().nextBoolean();
    }

    public static <T> T pick(List<T> list) {
        return list.get(ThreadLocalRandom.current().nextInt(list.size()));
    }

    @SafeVarargs
    public static <T> T of(T... items) {
        return items[ThreadLocalRandom.current().nextInt(items.length)];
    }
}
