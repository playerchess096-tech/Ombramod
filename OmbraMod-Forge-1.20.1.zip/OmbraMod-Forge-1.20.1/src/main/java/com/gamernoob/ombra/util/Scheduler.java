package com.gamernoob.ombra.util;

import com.gamernoob.ombra.OmbraMod;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

/**
 * Pianificatore di azioni ritardate (in tick di server). Tutte le sequenze horror
 * (passi, battiti, titoli disturbati...) passano da qui, cosi' non bloccano mai il gioco.
 */
public final class Scheduler {
    private record Task(long due, Runnable run) {}

    private static final List<Task> TASKS = new ArrayList<>();
    private static long now = 0;

    private Scheduler() {}

    public static long now() {
        return now;
    }

    public static void later(int ticks, Runnable r) {
        TASKS.add(new Task(now + Math.max(1, ticks), r));
    }

    /** Esegue l'azione solo se il giocatore e' ancora online (lo cerca per UUID al momento giusto). */
    public static void laterFor(UUID id, int ticks, Consumer<ServerPlayer> action) {
        later(ticks, () -> {
            MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
            if (server == null) return;
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            if (p != null) action.accept(p);
        });
    }

    public static void tick() {
        now++;
        if (TASKS.isEmpty()) return;
        List<Task> due = null;
        for (Iterator<Task> it = TASKS.iterator(); it.hasNext(); ) {
            Task t = it.next();
            if (t.due() <= now) {
                if (due == null) due = new ArrayList<>();
                due.add(t);
                it.remove();
            }
        }
        if (due == null) return;
        for (Task t : due) {
            try {
                t.run().run();
            } catch (Throwable ex) {
                OmbraMod.LOGGER.error("Errore in un'azione pianificata dell'Ombra", ex);
            }
        }
    }

    public static void clear() {
        TASKS.clear();
    }
}
