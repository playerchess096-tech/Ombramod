package com.gamernoob.ombra.config;

import net.minecraftforge.common.ForgeConfigSpec;

/** Configurazione comune (config/ombra-common.toml). Tutto e' regolabile, jumpscare compresi. */
public final class OmbraConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue CHAT_ENABLED;
    public static final ForgeConfigSpec.ConfigValue<String> CHAT_NAME;
    public static final ForgeConfigSpec.BooleanValue CHAT_AS_PLAYER;

    public static final ForgeConfigSpec.DoubleValue EVENT_FREQUENCY;
    public static final ForgeConfigSpec.BooleanValue AFFECT_CREATIVE;
    public static final ForgeConfigSpec.IntValue WAVE2_MINUTES;

    public static final ForgeConfigSpec.IntValue JUMPSCARE_LEVEL;
    public static final ForgeConfigSpec.IntValue JUMPSCARE_COOLDOWN_MIN;
    public static final ForgeConfigSpec.BooleanValue SCREEN_SHAKE;
    public static final ForgeConfigSpec.BooleanValue VISUAL_GLITCHES;
    public static final ForgeConfigSpec.DoubleValue SOUND_VOLUME;

    public static final ForgeConfigSpec.BooleanValue WORLD_CHANGES;
    public static final ForgeConfigSpec.BooleanValue TORCH_EVENTS;
    public static final ForgeConfigSpec.BooleanValue STRUCTURES;

    public static final ForgeConfigSpec.DoubleValue SHADOW_HEALTH;
    public static final ForgeConfigSpec.DoubleValue DAMAGE_MULT;
    public static final ForgeConfigSpec.BooleanValue ALLOW_STRONG_WEAPONS;
    public static final ForgeConfigSpec.DoubleValue STRONG_WEAPON_DAMAGE;
    public static final ForgeConfigSpec.BooleanValue DEBUG;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.comment("Chat dell'Ombra").push("chat");
        CHAT_ENABLED = b.comment("L'Ombra parla nella chat").define("enabled", true);
        CHAT_NAME = b.comment("Nome mostrato in chat").define("name", "Ombra");
        CHAT_AS_PLAYER = b.comment("true = <Ombra> messaggio (come un giocatore vero); false = [Ombra] in rosso")
                .define("asPlayer", true);
        b.pop();

        b.comment("Ritmo generale").push("pacing");
        EVENT_FREQUENCY = b.comment("Moltiplicatore della frequenza degli eventi (0.2 = molto rari, 3 = molto frequenti)")
                .defineInRange("eventFrequency", 1.0D, 0.1D, 5.0D);
        AFFECT_CREATIVE = b.comment("Gli eventi colpiscono anche chi e' in creativa (utile per provare la mod)")
                .define("affectCreative", true);
        WAVE2_MINUTES = b.comment("Minuti di gioco dopo cui inizia la seconda ondata (Persecuzione)")
                .defineInRange("wave2Minutes", 15, 1, 600);
        b.pop();

        b.comment("Effetti intensi").push("effects");
        JUMPSCARE_LEVEL = b.comment("0 = nessun jumpscare, 1 = solo suono e titolo, 2 = + schermo che trema, 3 = + volto a schermo e accecamento")
                .defineInRange("jumpscareLevel", 3, 0, 3);
        JUMPSCARE_COOLDOWN_MIN = b.comment("Minuti minimi tra due jumpscare")
                .defineInRange("jumpscareCooldownMinutes", 20, 3, 600);
        SCREEN_SHAKE = b.comment("Permetti lo schermo che trema").define("screenShake", true);
        VISUAL_GLITCHES = b.comment("Permetti glitch visivi, buio che si chiude, cielo rosso (solo overlay, nessun danno ai file)")
                .define("visualGlitches", true);
        SOUND_VOLUME = b.comment("Volume degli effetti sonori dell'Ombra")
                .defineInRange("soundVolume", 0.9D, 0.0D, 1.0D);
        b.pop();

        b.comment("Modifiche al mondo (tutte lontane dalle costruzioni del giocatore)").push("world");
        WORLD_CHANGES = b.comment("Alberi innaturali e segni sul terreno").define("worldChanges", true);
        TORCH_EVENTS = b.comment("Le torce vicine si spengono per un po' (poi tornano)").define("torchEvents", true);
        STRUCTURES = b.comment("Altari, tunnel falsi e stanze della memoria sotterranee").define("structures", true);
        b.pop();

        b.comment("Combattimento").push("combat");
        SHADOW_HEALTH = b.comment("Salute massima dell'Ombra (si applica alle nuove apparizioni)")
                .defineInRange("shadowHealth", 500.0D, 50.0D, 5000.0D);
        DAMAGE_MULT = b.comment("Moltiplicatore del danno inflitto dall'Ombra")
                .defineInRange("damageMultiplier", 1.0D, 0.1D, 4.0D);
        ALLOW_STRONG_WEAPONS = b.comment("Se true, anche le armi con danno superiore alla soglia (oltre alla spada di netherite) possono ucciderla")
                .define("allowStrongWeapons", false);
        STRONG_WEAPON_DAMAGE = b.comment("Soglia di danno per allowStrongWeapons")
                .defineInRange("strongWeaponDamage", 8.0D, 1.0D, 100.0D);
        b.pop();

        b.comment("Debug").push("debug");
        DEBUG = b.comment("Scrive nel log gli eventi che si attivano").define("log", false);
        b.pop();

        SPEC = b.build();
    }

    private OmbraConfig() {}
}
