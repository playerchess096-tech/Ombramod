package com.gamernoob.ombra.item;

import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.director.Fx;
import com.gamernoob.ombra.director.ShadowDirector;
import com.gamernoob.ombra.director.Waves;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.gamernoob.ombra.registry.ModSounds;
import com.gamernoob.ombra.story.Clues;
import com.gamernoob.ombra.story.Dialogue;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Gli oggetti misteriosi: pagine strappate (indizi), frammenti neri e simboli (temporanei), il Cuore dell'Ombra. */
public final class ClueItems {
    private ClueItems() {}

    private static void lore(List<Component> tips, String key) {
        tips.add(Component.translatable(key).withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC));
    }

    /** Gli oggetti temporanei si sbriciolano dopo 10 minuti nell'inventario. */
    private static void crumbleLater(ItemStack stack, Level level, Entity holder) {
        if (level.isClientSide()) return;
        CompoundTag tag = stack.getOrCreateTag();
        if (!tag.contains("OmbraExpire")) {
            tag.putLong("OmbraExpire", level.getGameTime() + 12000L);
            return;
        }
        if (level.getGameTime() > tag.getLong("OmbraExpire")) {
            stack.shrink(stack.getCount());
            if (holder instanceof ServerPlayer sp) Fx.action(sp, "§7Qualcosa si sbriciola in polvere nera.");
        }
    }

    public static class TornPage extends Item {
        public TornPage(Properties props) {
            super(props);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (!level.isClientSide() && player instanceof ServerPlayer sp) {
                PlayerProfile pr = ShadowDirector.profile(sp);
                if (Clues.discover(sp, pr)) stack.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
            lore(tips, "item.ombra.torn_page.lore");
        }
    }

    public static class BlackShard extends Item {
        public BlackShard(Properties props) {
            super(props);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (!level.isClientSide() && player instanceof ServerPlayer sp) {
                PlayerProfile pr = ShadowDirector.profile(sp);
                String line = Dialogue.memoryLine(sp, pr);
                if (line == null) line = Dialogue.line(pr);
                if (line == null) line = "...";
                Fx.say(sp, line, true);
                Fx.soundSelf(sp, ModSounds.whisper(), 0.8F, 1.0F);
                sp.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 45, 0, false, false));
                pr.tension = Math.min(100.0F, pr.tension + 6.0F);
                stack.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        @Override
        public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
            crumbleLater(stack, level, entity);
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
            lore(tips, "item.ombra.black_shard.lore");
        }
    }

    public static class UnknownSymbol extends Item {
        private static final String[] DIRS = {"est", "sud-est", "sud", "sud-ovest", "ovest", "nord-ovest", "nord", "nord-est"};

        public UnknownSymbol(Properties props) {
            super(props);
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (!level.isClientSide() && player instanceof ServerPlayer sp) {
                ShadowEntity sh = ShadowDirector.shadowOf(sp);
                if (sh == null) {
                    Fx.action(sp, "§7Il simbolo è freddo. Non senti nulla... per ora.");
                } else {
                    double dx = sh.getX() - sp.getX();
                    double dz = sh.getZ() - sp.getZ();
                    double ang = (Math.toDegrees(Math.atan2(dz, dx)) + 360.0) % 360.0;
                    String dir = DIRS[(int) Math.round(ang / 45.0) % 8];
                    int dist = (int) Math.round(Math.sqrt(dx * dx + dz * dz));
                    Fx.action(sp, "§cSenti una presenza a " + dir + ", a circa " + dist + " blocchi.");
                }
                PlayerProfile pr = ShadowDirector.profile(sp);
                pr.tension = Math.min(100.0F, pr.tension + 2.0F);
                stack.shrink(1);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        @Override
        public void inventoryTick(ItemStack stack, Level level, Entity entity, int slot, boolean selected) {
            crumbleLater(stack, level, entity);
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
            lore(tips, "item.ombra.unknown_symbol.lore");
        }
    }

    public static class ShadowHeart extends Item {
        public ShadowHeart(Properties props) {
            super(props);
        }

        @Override
        public boolean isFoil(ItemStack stack) {
            return true;
        }

        @Override
        public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
            ItemStack stack = player.getItemInHand(hand);
            if (!level.isClientSide() && player instanceof ServerPlayer sp) {
                PlayerProfile pr = ShadowDirector.profile(sp);
                if (!pr.defeated && !pr.nightmare) {
                    Fx.action(sp, "§7Il cuore batte piano. Non è ancora il momento.");
                } else if (sp.isShiftKeyDown()) {
                    Waves.toggleNightmare(sp, pr);
                } else {
                    Fx.action(sp, pr.nightmare ? "§4Modalità Incubo attiva. Maiusc + usa per disattivarla." : "§6Maiusc + usa per attivare la Modalità Incubo.");
                }
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        @Override
        public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tips, TooltipFlag flag) {
            lore(tips, "item.ombra.shadow_heart.lore");
        }
    }
}
