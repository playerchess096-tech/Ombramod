package com.gamernoob.ombra.director;

import com.gamernoob.ombra.config.OmbraConfig;
import com.gamernoob.ombra.data.OmbraData;
import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.registry.ModSounds;
import com.gamernoob.ombra.story.Clues;
import com.gamernoob.ombra.util.Rnd;
import com.gamernoob.ombra.util.Scheduler;
import com.gamernoob.ombra.util.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.WallTorchBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Modifiche al mondo. Regole di sicurezza: niente costruzioni del giocatore toccate (si agisce solo su roccia
 * e alberi naturali, lontano dai chunk dove il giocatore ha costruito), torce sempre ripristinate (anche dopo un crash).
 */
public final class WorldFx {
    private WorldFx() {}

    /** Tipi di stanza nascosta. */
    public enum Kind { ALTAR, DEADEND, ROOM, MEMORY }

    // =================================================================== torce

    private static int kindOf(BlockState s) {
        if (s.is(Blocks.TORCH)) return 0;
        if (s.is(Blocks.WALL_TORCH)) return 1;
        if (s.is(Blocks.SOUL_TORCH)) return 2;
        if (s.is(Blocks.SOUL_WALL_TORCH)) return 3;
        return -1;
    }

    private static BlockState stateOf(int kind, int face) {
        Block b = switch (kind) {
            case 0 -> Blocks.TORCH;
            case 1 -> Blocks.WALL_TORCH;
            case 2 -> Blocks.SOUL_TORCH;
            default -> Blocks.SOUL_WALL_TORCH;
        };
        BlockState s = b.defaultBlockState();
        if (kind == 1 || kind == 3) s = s.setValue(WallTorchBlock.FACING, Direction.from3DDataValue(face));
        return s;
    }

    /** Spegne alcune torce vicine; tornano da sole dopo restoreTicks (e vengono salvate nel mondo per sicurezza). */
    public static int extinguishTorches(ServerLevel level, BlockPos center, int r, int max, int restoreTicks) {
        List<BlockPos> found = new ArrayList<>();
        int ry = Math.max(3, r / 2);
        for (BlockPos pos : BlockPos.betweenClosed(center.offset(-r, -ry, -r), center.offset(r, ry, r))) {
            if (kindOf(level.getBlockState(pos)) >= 0) found.add(pos.immutable());
        }
        if (found.isEmpty()) return 0;
        Collections.shuffle(found);
        int n = Math.min(max, found.size());
        OmbraData data = OmbraData.get(level.getServer());
        long at = level.getGameTime() + restoreTicks;
        for (int i = 0; i < n; i++) {
            BlockPos pos = found.get(i);
            BlockState s = level.getBlockState(pos);
            int kind = kindOf(s);
            if (kind < 0) continue;
            OmbraData.TorchEntry t = new OmbraData.TorchEntry();
            t.dim = Util.dimId(level);
            t.x = pos.getX();
            t.y = pos.getY();
            t.z = pos.getZ();
            t.kind = kind;
            t.face = (kind == 1 || kind == 3) ? s.getValue(WallTorchBlock.FACING).get3DDataValue() : 0;
            t.at = at;
            data.torches.add(t);
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            level.playSound(null, pos, SoundEvents.FIRE_EXTINGUISH, SoundSource.BLOCKS, 0.6F, 1.0F);
            level.sendParticles(ParticleTypes.SMOKE, pos.getX() + 0.5D, pos.getY() + 0.7D, pos.getZ() + 0.5D, 6, 0.1D, 0.15D, 0.1D, 0.01D);
        }
        data.setDirty();
        final MinecraftServer server = level.getServer();
        Scheduler.later(restoreTicks + 5, () -> restoreTorches(server, false));
        return n;
    }

    /** Riaccende le torce scadute. Con force=true le riaccende tutte (avvio e chiusura del server). */
    public static void restoreTorches(MinecraftServer server, boolean force) {
        OmbraData data = OmbraData.get(server);
        if (data.torches.isEmpty()) return;
        boolean changed = false;
        for (Iterator<OmbraData.TorchEntry> it = data.torches.iterator(); it.hasNext(); ) {
            OmbraData.TorchEntry t = it.next();
            ResourceKey<Level> key = ResourceKey.create(Registries.DIMENSION, new ResourceLocation(t.dim));
            ServerLevel lvl = server.getLevel(key);
            if (lvl == null) {
                it.remove();
                changed = true;
                continue;
            }
            if (!force && lvl.getGameTime() < t.at) continue;
            BlockPos pos = new BlockPos(t.x, t.y, t.z);
            if (!force && !lvl.hasChunkAt(pos)) continue;
            BlockState cur = lvl.getBlockState(pos);
            if (cur.isAir()) {
                BlockState orig = stateOf(t.kind, t.face);
                if (orig.canSurvive(lvl, pos)) lvl.setBlock(pos, orig, 3);
                else Block.popResource(lvl, pos, new ItemStack(orig.getBlock()));
            }
            it.remove();
            changed = true;
        }
        if (changed) data.setDirty();
    }

    // =================================================================== tracce del combattimento

    /** Dopo uno scontro restano per qualche secondo particelle scure e un'eco sorda. */
    public static void lingeringTraces(ServerLevel level, BlockPos pos, int seconds) {
        for (int k = 1; k <= seconds; k++) {
            Scheduler.later(k * 20, () -> level.sendParticles(ParticleTypes.SQUID_INK, pos.getX() + 0.5D, pos.getY() + 0.2D,
                    pos.getZ() + 0.5D, 6, 1.2D, 0.1D, 1.2D, 0.0D));
        }
        Scheduler.later(seconds * 10, () -> Fx.soundAt(level, ModSounds.RUMBLE.get(), pos.getX() + 0.5D, pos.getY(),
                pos.getZ() + 0.5D, 0.4F, 0.7F));
    }

    // =================================================================== alberi innaturali

    /** Scurisce il tronco di un albero lontano e lascia un teschio con terra delle anime alla base. */
    public static boolean corruptTree(ServerPlayer p, ServerLevel level, OmbraData data) {
        BlockPos c = p.blockPosition();
        List<BlockPos> tops = new ArrayList<>();
        for (int dx = -26; dx <= 26; dx++) {
            for (int dz = -26; dz <= 26; dz++) {
                if (Math.abs(dx) + Math.abs(dz) < 12) continue;
                int x = c.getX() + dx;
                int z = c.getZ() + dz;
                BlockPos probe = new BlockPos(x, c.getY(), z);
                if (!level.hasChunkAt(probe) || data.isBuiltAt(probe)) continue;
                int h = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
                BlockPos top = new BlockPos(x, h - 1, z);
                if (level.getBlockState(top).is(BlockTags.LOGS)) tops.add(top);
            }
        }
        if (tops.isEmpty()) return false;
        BlockPos top = Rnd.pick(tops);
        BlockPos base = top;
        int guard = 0;
        while (level.getBlockState(base.below()).is(BlockTags.LOGS) && guard++ < 24) base = base.below();
        boolean leaves = false;
        for (BlockPos q : BlockPos.betweenClosed(top.offset(-2, -1, -2), top.offset(2, 2, 2))) {
            if (level.getBlockState(q).is(BlockTags.LEAVES)) {
                leaves = true;
                break;
            }
        }
        if (!leaves) return false;

        for (BlockPos q = base; q.getY() <= top.getY(); q = q.above()) {
            BlockState s = level.getBlockState(q);
            if (!s.is(BlockTags.LOGS)) continue;
            BlockState ns = Blocks.DARK_OAK_LOG.defaultBlockState();
            if (s.hasProperty(RotatedPillarBlock.AXIS)) ns = ns.setValue(RotatedPillarBlock.AXIS, s.getValue(RotatedPillarBlock.AXIS));
            level.setBlock(q, ns, 3);
        }
        for (Direction d : Direction.Plane.HORIZONTAL) {
            BlockPos g = base.relative(d).below();
            if (level.getBlockState(g).is(BlockTags.DIRT) && level.getBlockState(g.above()).isAir()) {
                level.setBlock(g, Blocks.SOUL_SOIL.defaultBlockState(), 3);
            }
        }
        Direction face = Rnd.of(Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST);
        BlockPos sp = base.relative(face);
        if (level.getBlockState(sp).isAir() && Util.solidFloor(level, sp.below())) {
            level.setBlock(sp, Blocks.SKELETON_SKULL.defaultBlockState().setValue(SkullBlock.ROTATION, Rnd.range(0, 15)), 3);
            data.symbols.add(sp.asLong());
        }
        data.setDirty();
        level.sendParticles(ParticleTypes.SOUL, base.getX() + 0.5D, base.getY() + 1.0D, base.getZ() + 0.5D, 12, 0.4D, 0.6D, 0.4D, 0.02D);
        return true;
    }

    // =================================================================== stanze nascoste

    private static boolean natural(ServerLevel l, BlockPos pos) {
        BlockState s = l.getBlockState(pos);
        return s.is(BlockTags.BASE_STONE_OVERWORLD) || s.is(BlockTags.DIRT) || s.is(Blocks.GRAVEL) || s.is(Blocks.SANDSTONE);
    }

    private static boolean noFluidAround(ServerLevel l, BlockPos pos) {
        for (Direction d : Direction.values()) {
            if (!l.getFluidState(pos.relative(d)).isEmpty()) return false;
        }
        return true;
    }

    private static boolean carvable(ServerLevel l, OmbraData data, BlockPos pos) {
        return l.hasChunkAt(pos) && !data.isBuiltAt(pos) && natural(l, pos) && noFluidAround(l, pos);
    }

    /**
     * Scava un tunnel nella parete di una caverna vicino al giocatore, che porta a una piccola stanza.
     * Restituisce il centro della stanza (o null se non c'e' posto adatto).
     */
    public static BlockPos carve(ServerPlayer p, ServerLevel level, OmbraData data, Kind kind) {
        if (level.dimension() != Level.OVERWORLD) return null;
        BlockPos feet = p.blockPosition();
        List<Direction> dirs = new ArrayList<>(List.of(Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST));
        Collections.shuffle(dirs);
        int hx = switch (kind) {
            case ALTAR -> 3;
            case MEMORY -> 2;
            case ROOM -> 2;
            default -> 0;
        };
        int hy = kind == Kind.ALTAR || kind == Kind.MEMORY ? 4 : 3;
        for (Direction dir : dirs) {
            BlockPos w = null;
            for (int s = 1; s <= 14; s++) {
                BlockPos q = feet.relative(dir, s);
                if (!level.hasChunkAt(q)) break;
                if (!Util.passable(level, q)) {
                    w = q;
                    break;
                }
            }
            if (w == null) continue;
            int len = switch (kind) {
                case ALTAR -> Rnd.range(5, 8);
                case MEMORY -> Rnd.range(6, 10);
                case ROOM -> Rnd.range(8, 12);
                default -> Rnd.range(10, 14);
            };
            // 1) il tunnel (largo 1, alto 2)
            boolean ok = true;
            List<BlockPos> cells = new ArrayList<>();
            for (int i = 0; i < len && ok; i++) {
                BlockPos a = w.relative(dir, i);
                BlockPos b = a.above();
                if (!carvable(level, data, a) || !carvable(level, data, b)) ok = false;
                else {
                    cells.add(a);
                    cells.add(b);
                }
            }
            if (!ok) continue;
            // 2) la stanza al termine del tunnel
            BlockPos cc = w.relative(dir, len + hx);
            if (hx > 0) {
                for (int x = -hx; x <= hx && ok; x++) {
                    for (int z = -hx; z <= hx && ok; z++) {
                        for (int y = 0; y < hy && ok; y++) {
                            BlockPos q = cc.offset(x, y, z);
                            if (!carvable(level, data, q)) ok = false;
                            else cells.add(q);
                        }
                    }
                }
            }
            if (!ok) continue;
            // 3) scavo
            for (BlockPos q : cells) level.setBlock(q, Blocks.AIR.defaultBlockState(), 2);
            decorate(level, data, kind, w, dir, len, cc, hx);
            OmbraData.RoomEntry r = new OmbraData.RoomEntry();
            r.dim = Util.dimId(level);
            BlockPos trigger = hx > 0 ? cc : w.relative(dir, len - 1);
            r.x = trigger.getX();
            r.y = trigger.getY();
            r.z = trigger.getZ();
            r.kind = kind.ordinal();
            if (data.rooms.size() > 60) data.rooms.remove(0);
            data.rooms.add(r);
            data.setDirty();
            level.playSound(null, trigger, ModSounds.RUMBLE.get(), SoundSource.HOSTILE, 0.35F, 0.8F);
            return trigger;
        }
        return null;
    }

    private static void put(ServerLevel l, BlockPos pos, Block b) {
        l.setBlock(pos, b.defaultBlockState(), 2);
    }

    private static void decorate(ServerLevel level, OmbraData data, Kind kind, BlockPos wall, Direction dir, int len, BlockPos cc, int hx) {
        switch (kind) {
            case ALTAR -> {
                for (int x = -2; x <= 2; x++) {
                    for (int z = -2; z <= 2; z++) put(level, cc.offset(x, -1, z), Blocks.POLISHED_BLACKSTONE_BRICKS);
                }
                put(level, cc, Blocks.CHISELED_POLISHED_BLACKSTONE);
                put(level, cc.above(), Blocks.SKELETON_SKULL);
                for (int sx : new int[]{-2, 2}) {
                    for (int sz : new int[]{-2, 2}) put(level, cc.offset(sx, 0, sz), Blocks.BLACK_CANDLE);
                }
                dropPage(level, cc.above(2));
            }
            case ROOM -> {
                for (int x = -hx; x <= hx; x++) {
                    for (int z = -hx; z <= hx; z++) put(level, cc.offset(x, -1, z), Blocks.COBBLED_DEEPSLATE);
                }
                put(level, cc.offset(-hx, 0, -hx), Blocks.BLACK_CANDLE);
                put(level, cc.offset(hx, 0, hx), Blocks.BLACK_CANDLE);
                if (Rnd.chance(0.4D)) dropPage(level, cc.above());
            }
            case MEMORY -> {
                for (int x = -hx; x <= hx; x++) {
                    for (int z = -hx; z <= hx; z++) put(level, cc.offset(x, -1, z), Blocks.BLACKSTONE);
                }
                put(level, cc.offset(-hx, -1, -hx), Blocks.CRYING_OBSIDIAN);
                put(level, cc.offset(hx, -1, hx), Blocks.CRYING_OBSIDIAN);
                put(level, cc.offset(-hx, -1, hx), Blocks.CRYING_OBSIDIAN);
                put(level, cc.offset(hx, -1, -hx), Blocks.CRYING_OBSIDIAN);
                put(level, cc, Blocks.LECTERN);
                put(level, cc.offset(-hx, 0, -hx), Blocks.SOUL_LANTERN);
                put(level, cc.offset(hx, 0, hx), Blocks.SOUL_LANTERN);
                dropPage(level, cc.above());
            }
            default -> {
                BlockPos end = wall.relative(dir, len - 1);
                put(level, end, Blocks.SKELETON_SKULL);
                put(level, end.relative(dir.getOpposite()), Blocks.BLACK_CANDLE);
            }
        }
    }

    private static void dropPage(ServerLevel level, BlockPos pos) {
        ItemEntity ie = new ItemEntity(level, pos.getX() + 0.5D, pos.getY() + 0.2D, pos.getZ() + 0.5D, Clues.page());
        ie.setDeltaMovement(Vec3.ZERO);
        level.addFreshEntity(ie);
    }

    // =================================================================== punto di osservazione

    /**
     * Sceglie dove far comparire l'Ombra a distanza: preferisce colline, alberi, imbocchi di caverna,
     * le zone dove il giocatore passa spesso e l'area attorno alla sua base.
     */
    public static BlockPos findWatchSpot(ServerPlayer p, PlayerProfile pr, OmbraData data) {
        ServerLevel level = p.serverLevel();
        BlockPos center = p.blockPosition();
        boolean cave = Util.underground(level, center);
        if (!cave && pr.hasBase && Rnd.chance(0.4D)) {
            BlockPos base = new BlockPos(pr.baseX, pr.baseY, pr.baseZ);
            if (Util.horizontalDist(p, base) < 70.0D) center = base;
        }
        double lo = cave ? 14.0D : 28.0D;
        double hi = cave ? 28.0D : 46.0D;
        BlockPos best = null;
        double bestScore = 0.0D;
        for (int i = 0; i < 26; i++) {
            BlockPos s = Util.findSpot(level, center, lo, hi, 1, null);
            if (s == null) continue;
            double sc = watchScore(level, p, pr, s, cave);
            if (sc > bestScore) {
                bestScore = sc;
                best = s;
            }
        }
        return best;
    }

    private static double watchScore(ServerLevel level, ServerPlayer p, PlayerProfile pr, BlockPos s, boolean cave) {
        double d = Math.sqrt(p.blockPosition().distSqr(s));
        if (d < (cave ? 12.0D : 24.0D) || d > (cave ? 34.0D : 60.0D)) return -1.0D;
        Vec3 head = new Vec3(s.getX() + 0.5D, s.getY() + 2.0D, s.getZ() + 0.5D);
        Vec3 feet = new Vec3(s.getX() + 0.5D, s.getY() + 0.5D, s.getZ() + 0.5D);
        if (!Util.canSee(p, head) && !Util.canSee(p, feet)) return -1.0D;
        double sc = 1.0D;
        if (s.getY() >= p.getBlockY() + 4) sc += 2.0D;
        for (Direction dir : Direction.Plane.HORIZONTAL) {
            if (level.getBlockState(s.relative(dir)).is(BlockTags.LOGS)) {
                sc += 2.0D;
                break;
            }
        }
        if (!level.canSeeSky(s.above(2)) && !cave) sc += 1.5D;
        sc += Math.min(4.0D, pr.habitCount(ChunkPos.asLong(s.getX() >> 4, s.getZ() >> 4)) / 15.0D);
        return sc + Rnd.range(0.0D, 0.8D);
    }
}
