package com.gamernoob.ombra.registry;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.util.Rnd;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Suoni originali della mod (sintetizzati, file .ogg in assets/ombra/sounds). */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS = DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, OmbraMod.MODID);

    private ModSounds() {}

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name, () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(OmbraMod.MODID, name)));
    }

    public static final RegistryObject<SoundEvent> HEARTBEAT = reg("heartbeat");
    public static final RegistryObject<SoundEvent> WHISPER_A = reg("whisper_a");
    public static final RegistryObject<SoundEvent> WHISPER_B = reg("whisper_b");
    public static final RegistryObject<SoundEvent> WHISPER_C = reg("whisper_c");
    public static final RegistryObject<SoundEvent> SCREAM = reg("scream");
    public static final RegistryObject<SoundEvent> STATIC = reg("static");
    public static final RegistryObject<SoundEvent> DOOR_CREAK = reg("door_creak");
    public static final RegistryObject<SoundEvent> BELL = reg("bell");
    public static final RegistryObject<SoundEvent> THUMP = reg("thump");
    public static final RegistryObject<SoundEvent> RISER = reg("riser");
    public static final RegistryObject<SoundEvent> BREATH = reg("breath");
    public static final RegistryObject<SoundEvent> GROWL = reg("growl");
    public static final RegistryObject<SoundEvent> SHADOW_HURT = reg("shadow_hurt");
    public static final RegistryObject<SoundEvent> SHADOW_DEATH = reg("shadow_death");
    public static final RegistryObject<SoundEvent> TELEPORT = reg("teleport");
    public static final RegistryObject<SoundEvent> GLITCH = reg("glitch");
    public static final RegistryObject<SoundEvent> STING = reg("sting");
    public static final RegistryObject<SoundEvent> RUMBLE = reg("rumble");
    public static final RegistryObject<SoundEvent> MUSIC_BOX = reg("music_box");
    public static final RegistryObject<SoundEvent> VICTORY = reg("victory");
    public static final RegistryObject<SoundEvent> ENDING_ALT = reg("ending_alt");
    public static final RegistryObject<SoundEvent> DRONE_ISOLATION = reg("drone_isolation");
    public static final RegistryObject<SoundEvent> DRONE_SKY = reg("drone_sky");
    public static final RegistryObject<SoundEvent> DRONE_MEMORY = reg("drone_memory");
    public static final RegistryObject<SoundEvent> DRONE_HUNT = reg("drone_hunt");
    public static final RegistryObject<SoundEvent> DRONE_CAVE = reg("drone_cave");
    public static final RegistryObject<SoundEvent> DRONE_NETHER = reg("drone_nether");

    public static SoundEvent whisper() {
        return Rnd.of(WHISPER_A, WHISPER_B, WHISPER_C).get();
    }
}
