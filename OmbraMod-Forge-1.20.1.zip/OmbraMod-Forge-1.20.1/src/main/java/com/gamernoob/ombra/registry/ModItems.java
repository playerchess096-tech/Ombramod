package com.gamernoob.ombra.registry;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.item.ClueItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, OmbraMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, OmbraMod.MODID);

    private ModItems() {}

    public static final RegistryObject<Item> TORN_PAGE = ITEMS.register("torn_page",
            () -> new ClueItems.TornPage(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> BLACK_SHARD = ITEMS.register("black_shard",
            () -> new ClueItems.BlackShard(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> UNKNOWN_SYMBOL = ITEMS.register("unknown_symbol",
            () -> new ClueItems.UnknownSymbol(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> SHADOW_HEART = ITEMS.register("shadow_heart",
            () -> new ClueItems.ShadowHeart(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    public static final RegistryObject<Item> SHADOW_SPAWN_EGG = ITEMS.register("shadow_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.SHADOW, 0x050507, 0xE8E8FF, new Item.Properties()));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("ombra", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.ombra"))
            .icon(() -> new ItemStack(SHADOW_HEART.get()))
            .displayItems((params, out) -> {
                out.accept(TORN_PAGE.get());
                out.accept(BLACK_SHARD.get());
                out.accept(UNKNOWN_SYMBOL.get());
                out.accept(SHADOW_HEART.get());
                out.accept(SHADOW_SPAWN_EGG.get());
            })
            .build());
}
