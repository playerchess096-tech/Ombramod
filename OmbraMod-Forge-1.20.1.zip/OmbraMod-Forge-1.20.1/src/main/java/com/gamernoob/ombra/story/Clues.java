package com.gamernoob.ombra.story;

import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.director.Fx;
import com.gamernoob.ombra.registry.ModItems;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** Le 8 pagine del diario: spiegano chi e' l'Ombra, perche' ti perseguita e perche' serve il netherite. */
public final class Clues {
    private Clues() {}

    public static final int ALL = 0xFF;

    public static final String[] TITLES = {
            "Il primo scavo", "La luce", "Il nome dimenticato", "Il fuoco profondo",
            "Perché solo il netherite", "Chi segue chi", "Il patto del drago", "L'ultima pagina"
    };

    public static final String[] TEXTS = {
            "«Oggi ho scavato più in basso di chiunque altro. La pietra ha smesso di rispondere. Sotto di me c'è solo silenzio.»",
            "«Le torce si spengono quando arriva. Non ha paura del buio: ne è fatto. Ha paura di una luce che non si spegne.»",
            "«Mi chiamavo... non ricordo. Il mondo ha cancellato il mio nome perché nessuno lo pronunciava più. Chi non è ricordato diventa ombra.»",
            "«Nel Nether, tra i resti antichi, ho trovato frammenti di chi è venuto prima di me. Piegati dal fuoco, ricordano ogni cosa che hanno ucciso.»",
            "«Il ferro dimentica. Il diamante riflette. Solo la lama nata dai resti antichi taglia ciò che esiste nel ricordo. Una spada di netherite non ferisce il corpo: ferisce l'oblio.»",
            "«Mi segue chi scava. Chi prende senza chiedere. Non per odio, ma per fame di compagnia: chi è solo da tanto non sa fare altro che stare vicino.»",
            "«Il Drago custodiva la porta. Quando cade, nulla ferma più lo sguardo che viene da sotto. Allora comincia la vera caccia.»",
            "«Se leggi questo, hai già capito. Non ti inseguo da fuori. Ogni volta che sei morto, qualcosa di te è rimasto sotto la roccia. Quel qualcosa ha imparato a camminare.»"
    };

    public static int remaining(PlayerProfile pr) {
        return 8 - Integer.bitCount(pr.clues & ALL);
    }

    public static ItemStack page() {
        return new ItemStack(ModItems.TORN_PAGE.get());
    }

    /** Legge la prossima pagina non ancora scoperta. Restituisce false se le ha gia' lette tutte. */
    public static boolean discover(ServerPlayer p, PlayerProfile pr) {
        int idx = -1;
        for (int i = 0; i < 8; i++) {
            if ((pr.clues & (1 << i)) == 0) {
                idx = i;
                break;
            }
        }
        if (idx < 0) {
            Fx.action(p, "§7Hai già letto tutte le pagine.");
            return false;
        }
        pr.clues |= 1 << idx;
        pr.tension = Math.min(100.0F, pr.tension + 3.0F);
        p.sendSystemMessage(Component.literal("§8§l[Pagina strappata " + (idx + 1) + "/8 — " + TITLES[idx] + "]"));
        p.sendSystemMessage(Component.literal("§7§o" + TEXTS[idx]));
        if ((pr.clues & ALL) == ALL) {
            Fx.sayLater(p, 100, Dialogue.allCluesLine());
        }
        return true;
    }

    /** Libro scritto: ricompensa narrativa alla sconfitta dell'Ombra. Le pagine non trovate sono illeggibili. */
    public static ItemStack diary(PlayerProfile pr, boolean alt) {
        ItemStack book = new ItemStack(Items.WRITTEN_BOOK);
        CompoundTag tag = book.getOrCreateTag();
        tag.putString("title", "Il Diario dell'Ombra");
        tag.putString("author", "L'Ombra");
        ListTag pages = new ListTag();
        pages.add(page("IL DIARIO DELL'OMBRA\n\nScritto da chi non ricordava più il proprio nome.\n\nOgni pagina che hai trovato è qui. Le altre... aspettano."));
        for (int i = 0; i < 8; i++) {
            String body = (pr.clues & (1 << i)) != 0 ? TEXTS[i] : "§k" + "▒".repeat(60);
            pages.add(page("§l" + TITLES[i] + "§r\n\n" + body));
        }
        if (alt) {
            pages.add(page("LA VERITÀ\n\nEri tu. Ogni morte che hai lasciato indietro, " + pr.deaths
                    + " in tutto, è rimasta sotto la roccia. Io ero quella parte di te che non riusciva ad andarsene.\n\nOra siamo in pace."));
        } else {
            pages.add(page("EPILOGO\n\nHai vinto con l'unica lama che poteva. Ma sotto la roccia c'è ancora qualcosa da capire.\n\nRaccogli tutte le pagine e torna a cercarmi."));
        }
        tag.put("pages", pages);
        return book;
    }

    private static StringTag page(String text) {
        return StringTag.valueOf(Component.Serializer.toJson(Component.literal(text)));
    }
}
