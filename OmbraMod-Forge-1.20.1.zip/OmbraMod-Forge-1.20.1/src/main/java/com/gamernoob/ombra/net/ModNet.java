package com.gamernoob.ombra.net;

import com.gamernoob.ombra.OmbraMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

public final class ModNet {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(OmbraMod.MODID, "main"), () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    private ModNet() {}

    public static void register() {
        CHANNEL.registerMessage(0, FxPacket.class, FxPacket::encode, FxPacket::decode, FxPacket::handle);
    }

    public static void sendTo(ServerPlayer p, FxPacket pkt) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> p), pkt);
    }
}
