package com.gamernoob.ombra.client;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.net.FxPacket;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.resources.sounds.SoundInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderGuiEvent;
import net.minecraftforge.client.event.ViewportEvent;
import net.minecraftforge.client.event.sound.PlaySoundEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.Random;

/**
 * Effetti locali: schermo che trema, buio che si chiude, glitch, jumpscare, cielo rosso, isolamento sonoro.
 * Sono SOLO overlay e camera: non toccano mai file, mondo o impostazioni (nessun rischio di crash).
 */
@Mod.EventBusSubscriber(modid = OmbraMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public final class ClientFx {
    private ClientFx() {}

    private static int shakeTicks;
    private static int shakeMax = 1;
    private static int shakePower;
    private static int closeTicks;
    private static int closeMax = 1;
    private static int glitchTicks;
    private static int glitchPower;
    private static int jumpTicks;
    private static int jumpMax = 1;
    private static int jumpVariant;
    private static int jumpLevel;
    private static int skyTicks;
    private static int skyMax = 1;
    private static int skyPower;
    private static int isoTicks;
    private static int isoMax = 1;
    private static int villageTicks;
    private static int flashTicks;
    private static int flashMax = 1;

    private static final Random RNG = new Random();
    private static final ResourceLocation[] FACES = {
            new ResourceLocation(OmbraMod.MODID, "textures/gui/jumpscare_0.png"),
            new ResourceLocation(OmbraMod.MODID, "textures/gui/jumpscare_1.png"),
            new ResourceLocation(OmbraMod.MODID, "textures/gui/jumpscare_2.png")
    };

    // ------------------------------------------------------------------ ricezione dei pacchetti

    public static void handle(FxPacket m) {
        switch (m.kind) {
            case FxPacket.SHAKE -> {
                shakeTicks = Math.max(1, m.dur);
                shakeMax = shakeTicks;
                shakePower = m.power;
            }
            case FxPacket.CLOSE -> {
                closeTicks = Math.max(10, m.dur);
                closeMax = closeTicks;
            }
            case FxPacket.GLITCH -> {
                glitchTicks = Math.max(glitchTicks, m.dur);
                glitchPower = Math.max(20, m.power);
            }
            case FxPacket.JUMPSCARE -> {
                jumpTicks = Math.max(10, m.dur);
                jumpMax = jumpTicks;
                jumpVariant = Mth.clamp(m.power, 0, 2);
                jumpLevel = m.extra;
            }
            case FxPacket.RED_SKY -> {
                skyTicks = Math.max(60, m.dur);
                skyMax = skyTicks;
                skyPower = Math.max(10, m.power);
            }
            case FxPacket.ISOLATION -> {
                isoTicks = Math.max(60, m.dur);
                isoMax = isoTicks;
                stopMusic();
            }
            case FxPacket.FLASH -> {
                flashTicks = Math.max(3, m.dur);
                flashMax = flashTicks;
            }
            case FxPacket.STOP_MUSIC -> stopMusic();
            case FxPacket.VILLAGE_SILENCE -> villageTicks = m.dur;
            case FxPacket.CLEAR -> reset();
            default -> {
                // pacchetto sconosciuto: ignorato
            }
        }
    }

    private static void stopMusic() {
        Minecraft.getInstance().getMusicManager().stopPlaying();
    }

    private static void reset() {
        shakeTicks = closeTicks = glitchTicks = jumpTicks = skyTicks = isoTicks = villageTicks = flashTicks = 0;
    }

    // ------------------------------------------------------------------ tick e camera

    @SubscribeEvent
    public static void clientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.isPaused()) return;
        if (shakeTicks > 0) shakeTicks--;
        if (closeTicks > 0) closeTicks--;
        if (glitchTicks > 0) glitchTicks--;
        if (jumpTicks > 0) jumpTicks--;
        if (skyTicks > 0) skyTicks--;
        if (villageTicks > 0) villageTicks--;
        if (flashTicks > 0) flashTicks--;
        if (isoTicks > 0) {
            isoTicks--;
            if (isoTicks % 20 == 0) stopMusic();
        }
    }

    @SubscribeEvent
    public static void loggedOut(ClientPlayerNetworkEvent.LoggingOut e) {
        reset();
    }

    @SubscribeEvent
    public static void camera(ViewportEvent.ComputeCameraAngles e) {
        if (shakeTicks <= 0) return;
        float k = (shakeTicks / (float) shakeMax) * (shakePower / 100.0F);
        e.setYaw(e.getYaw() + (RNG.nextFloat() - 0.5F) * 6.0F * k);
        e.setPitch(e.getPitch() + (RNG.nextFloat() - 0.5F) * 6.0F * k);
        e.setRoll(e.getRoll() + (RNG.nextFloat() - 0.5F) * 8.0F * k);
    }

    private static float skyIntensity() {
        float in = Math.min(1.0F, (skyMax - skyTicks) / 40.0F);
        float out = Math.min(1.0F, skyTicks / 40.0F);
        return Math.min(in, out) * (skyPower / 100.0F);
    }

    /** Cielo anomalo: la nebbia (e quindi l'orizzonte) vira al rosso. */
    @SubscribeEvent
    public static void fog(ViewportEvent.ComputeFogColor e) {
        if (skyTicks <= 0) return;
        float k = skyIntensity();
        e.setRed(Mth.lerp(k, e.getRed(), 0.45F));
        e.setGreen(Mth.lerp(k, e.getGreen(), 0.02F));
        e.setBlue(Mth.lerp(k, e.getBlue(), 0.02F));
    }

    // ------------------------------------------------------------------ isolamento: il mondo tace

    @SubscribeEvent
    public static void sound(PlaySoundEvent e) {
        if (isoTicks <= 0 && villageTicks <= 0) return;
        SoundInstance s = e.getSound();
        if (s == null) return;
        ResourceLocation loc = s.getLocation();
        if (OmbraMod.MODID.equals(loc.getNamespace())) return;
        SoundSource src = s.getSource();
        if (isoTicks > 0 && (src == SoundSource.MUSIC || src == SoundSource.AMBIENT || src == SoundSource.NEUTRAL
                || src == SoundSource.HOSTILE || src == SoundSource.WEATHER || src == SoundSource.RECORDS)) {
            e.setSound(null);
            return;
        }
        if (villageTicks > 0 && src == SoundSource.NEUTRAL
                && (loc.getPath().startsWith("entity.villager") || loc.getPath().startsWith("entity.wandering_trader"))) {
            e.setSound(null);
        }
    }

    // ------------------------------------------------------------------ overlay

    @SubscribeEvent
    public static void overlay(RenderGuiEvent.Post e) {
        if (skyTicks <= 0 && isoTicks <= 0 && flashTicks <= 0 && closeTicks <= 0 && glitchTicks <= 0 && jumpTicks <= 0) return;
        Minecraft mc = Minecraft.getInstance();
        GuiGraphics g = e.getGuiGraphics();
        int w = mc.getWindow().getGuiScaledWidth();
        int h = mc.getWindow().getGuiScaledHeight();

        if (skyTicks > 0) {
            int a = (int) (skyIntensity() * 70.0F);
            g.fill(0, 0, w, h, (a << 24) | 0x400000);
        }
        if (isoTicks > 0) {
            float k = Math.min(1.0F, Math.min((isoMax - isoTicks) / 40.0F, isoTicks / 40.0F));
            g.fill(0, 0, w, h, ((int) (k * 45.0F) << 24) | 0x101018);
        }
        if (flashTicks > 0) {
            int a = (int) (200.0F * flashTicks / (float) flashMax);
            g.fill(0, 0, w, h, (a << 24) | 0xE8E8FF);
        }
        if (closeTicks > 0) drawClose(g, w, h);
        if (glitchTicks > 0) drawGlitch(g, w, h, mc);
        if (jumpTicks > 0) drawJumpscare(g, w, h, e.getPartialTick());
    }

    /** Il buio che si chiude: bordi neri che avanzano verso il centro e poi si riaprono. */
    private static void drawClose(GuiGraphics g, int w, int h) {
        float t = (closeMax - closeTicks) / (float) closeMax;
        float p = t < 0.5F ? t * 2.0F : (1.0F - t) * 2.0F;
        for (int i = 3; i >= 0; i--) {
            float pp = Math.min(1.0F, p * (1.0F + 0.12F * i));
            int bx = (int) (pp * w * 0.5F);
            int by = (int) (pp * h * 0.5F);
            int color = i == 0 ? 0xFF000000 : 0x46000000;
            g.fill(0, 0, bx, h, color);
            g.fill(w - bx, 0, w, h, color);
            g.fill(0, 0, w, by, color);
            g.fill(0, h - by, w, h, color);
        }
    }

    /** Falsi errori visivi: barre di interferenza e testo corrotto, sempre e solo disegnati sopra lo schermo. */
    private static void drawGlitch(GuiGraphics g, int w, int h, Minecraft mc) {
        long seed = (mc.level != null ? mc.level.getGameTime() : 0L) / 2L;
        RNG.setSeed(seed * 31L + 7L);
        float k = glitchPower / 100.0F;
        int bars = 3 + (int) (9 * k);
        for (int i = 0; i < bars; i++) {
            int y = RNG.nextInt(Math.max(1, h));
            int bh = 2 + RNG.nextInt(14);
            int x0 = RNG.nextInt(Math.max(1, w / 2));
            int x1 = Math.min(w, x0 + w / 4 + RNG.nextInt(Math.max(1, w / 2)));
            int c;
            switch (RNG.nextInt(4)) {
                case 0 -> c = 0x80000000;
                case 1 -> c = 0x70C01818;
                case 2 -> c = 0x60FFFFFF;
                default -> c = 0x7000A0A0;
            }
            g.fill(x0, y, x1, Math.min(h, y + bh), c);
        }
        if (RNG.nextInt(6) == 0) g.fill(0, 0, w, h, 0x18FFFFFF);
        if (k > 0.3F && RNG.nextInt(3) == 0) {
            String[] msgs = {"ERRORE 0xDEAD", "NON GUARDARE", "SEI SOLO", "██████", "TI VEDO"};
            g.drawString(mc.font, msgs[RNG.nextInt(msgs.length)], RNG.nextInt(Math.max(1, w - 80)),
                    RNG.nextInt(Math.max(1, h - 10)), 0xFFB01818, false);
        }
    }

    /** Jumpscare: velo rosso, schermo che trema (camera) e, a livello 3, il volto a tutto schermo che lampeggia. */
    private static void drawJumpscare(GuiGraphics g, int w, int h, float partialTick) {
        float prog = Mth.clamp(1.0F - (jumpTicks - partialTick) / (float) jumpMax, 0.0F, 1.0F);
        int redA = (int) (Mth.clamp(1.0F - Math.abs(prog - 0.2F) * 1.8F, 0.0F, 1.0F) * 190.0F);
        g.fill(0, 0, w, h, (redA << 24) | 0x300000);
        if (jumpLevel < 3) return;
        float alpha = ((jumpTicks / 2) % 2 == 0 ? 1.0F : 0.55F) * Mth.clamp((1.0F - prog) * 3.0F, 0.0F, 1.0F);
        float zoom = 1.0F + 0.25F * prog;
        int size = Math.max(w, h);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        g.setColor(1.0F, 1.0F, 1.0F, alpha);
        g.pose().pushPose();
        g.pose().translate(w / 2.0F, h / 2.0F, 0.0F);
        g.pose().scale(zoom, zoom, 1.0F);
        g.pose().translate(-w / 2.0F, -h / 2.0F, 0.0F);
        g.blit(FACES[jumpVariant], (w - size) / 2, (h - size) / 2, size, size, 0.0F, 0.0F, 512, 512, 512, 512);
        g.pose().popPose();
        g.setColor(1.0F, 1.0F, 1.0F, 1.0F);
        RenderSystem.disableBlend();
    }
}
