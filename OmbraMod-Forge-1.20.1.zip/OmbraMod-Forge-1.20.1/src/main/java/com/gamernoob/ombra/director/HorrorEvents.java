package com.gamernoob.ombra.director;

import com.gamernoob.ombra.config.OmbraConfig;
import com.gamernoob.ombra.data.OmbraData;
import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.entity.ShadowEntity;
import com.gamernoob.ombra.net.FxPacket;
import com.gamernoob.ombra.registry.ModItems;
import com.gamernoob.ombra.registry.ModSounds;
import com.gamernoob.ombra.story.Clues;
import com.gamernoob.ombra.story.Dialogue;
import com.gamernoob.ombra.story.Personality;
import com.gamernoob.ombra.util.Rnd;
import com.gamernoob.ombra.util.Scheduler;
import com.gamernoob.ombra.util.Util;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

/**
 * Gli eventi horror. Ognuno e' breve, controllato (tutto passa dal Scheduler, mai bloccante) e restituisce
 * true solo se e' davvero successo qualcosa (altrimenti il direttore ne prova un altro).
 */
public final class HorrorEvents {
    private HorrorEvents() {}

    public static boolean run(HorrorEvent ev, ServerPlayer p, PlayerProfile pr, ShadowDirector.State st, OmbraData data) {
        return switch (ev) {
            case MESSAGE -> message(p, pr);
            case FRIENDLY -> friendly(p, pr);
            case FOOTSTEPS -> footsteps(p, pr);
            case DOOR -> door(p, pr);
            case THUNDER -> thunder(p, pr);
            case HEARTBEAT -> heartbeat(p, pr);
            case WATCHER -> watcher(p, pr, st, data);
            case ANIMALS -> animals(p, pr);
            case CAVE_ECHO -> caveEcho(p, pr);
            case RAIN -> rain(p, pr, st);
            case TORCHES -> torches(p, pr);
            case SIGNS -> signs(p, pr);
            case FAKE_JOIN -> fakeJoin(p, pr);
            case DARKNESS -> darkness(p, pr);
            case VILLAGERS -> villagers(p, pr);
            case TREES -> trees(p, pr, data);
            case ITEM_DROP -> itemDrop(p, pr);
            case STALK -> stalk(p, pr, st);
            case SKY -> sky(p, pr);
            case GLITCH -> glitch(p, pr);
            case FAKE_ERROR -> fakeError(p, pr);
            case STRUCTURE -> structure(p, pr, data, WorldFx.Kind.ALTAR);
            case TUNNEL -> structure(p, pr, data, Rnd.coin() ? WorldFx.Kind.DEADEND : WorldFx.Kind.ROOM);
            case CHASE -> chase(p, pr, st);
            case JUMPSCARE -> jumpscare(p, pr);
            case MEMORY_ROOM -> structure(p, pr, data, WorldFx.Kind.MEMORY);
            case ISOLATION -> isolation(p, pr);
            case AMBUSH -> ambush(p, pr, st);
        };
    }

    // =================================================================== piccoli aiuti

    private static void tension(PlayerProfile pr, float v) {
        pr.tension = Math.min(100.0F, pr.tension + v);
    }

    private static boolean isBehind(ServerPlayer p, BlockPos s) {
        Vec3 back = Util.back(p);
        double dx = s.getX() + 0.5D - p.getX();
        double dz = s.getZ() + 0.5D - p.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0E-3D) return false;
        return (dx * back.x + dz * back.z) / len > 0.35D;
    }

    /** Fulmine solo visivo (niente fuoco, niente danni). */
    private static void visualBolt(ServerLevel level, double x, double z) {
        if (!level.hasChunkAt(BlockPos.containing(x, 64.0D, z))) return;
        int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(x), Mth.floor(z));
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt == null) return;
        bolt.moveTo(x, y, z);
        bolt.setVisualOnly(true);
        level.addFreshEntity(bolt);
    }

    private static SoundEvent animalSound(Animal a) {
        if (a instanceof Sheep) return SoundEvents.SHEEP_AMBIENT;
        if (a instanceof Pig) return SoundEvents.PIG_AMBIENT;
        if (a instanceof Chicken) return SoundEvents.CHICKEN_AMBIENT;
        if (a instanceof Cow) return SoundEvents.COW_AMBIENT;
        return SoundEvents.COW_AMBIENT;
    }

    // =================================================================== chat e finta amicizia

    public static boolean message(ServerPlayer p, PlayerProfile pr) {
        if (Personality.of(pr) == Personality.SILENT) {
            Fx.soundSelf(p, ModSounds.whisper(), 0.4F, 0.9F);
            tension(pr, 1.0F);
            return true;
        }
        String line = Rnd.chance(0.35D) ? Dialogue.memoryLine(p, pr) : null;
        if (line == null) line = Dialogue.line(pr);
        if (line == null) return false;
        Fx.say(p, line, true);
        tension(pr, 2.0F);
        return true;
    }

    /** Finta amicizia: messaggi rassicuranti per qualche minuto, poi la maschera cade. */
    public static boolean friendly(ServerPlayer p, PlayerProfile pr) {
        if (pr.friendlyDone) return false;
        int stage = pr.friendlyStage;
        int len = Dialogue.friendlyArcLength();
        if (stage >= len) return false;
        Fx.say(p, Dialogue.friendlyArc(stage), true);
        if (stage == 2) Fx.soundSelfAmbient(p, ModSounds.MUSIC_BOX.get(), 0.5F, 1.0F);
        pr.friendlyStage++;
        if (stage == len - 1) {
            UUID id = p.getUUID();
            Scheduler.laterFor(id, 60, pl -> footsteps(pl, ShadowDirector.profile(pl)));
            Scheduler.laterFor(id, 200, pl -> {
                Fx.say(pl, Dialogue.reveal(), true);
                Fx.soundSelf(pl, ModSounds.STING.get(), 0.8F, 1.0F);
            });
            pr.friendlyDone = true;
            pr.personality = Personality.TAUNTING.ordinal();
            pr.personalityUntil = pr.seconds + 400;
            tension(pr, 10.0F);
        }
        return true;
    }

    // =================================================================== suoni e presenze

    /** Passi alle spalle che si avvicinano, sul materiale del terreno; poi un respiro. */
    public static boolean footsteps(ServerPlayer p, PlayerProfile pr) {
        final int steps = Rnd.range(6, 10);
        final UUID id = p.getUUID();
        for (int i = 0; i < steps; i++) {
            final int idx = i;
            Scheduler.laterFor(id, 12 + i * 9, pl -> {
                ServerLevel lv = pl.serverLevel();
                double dist = Math.max(1.8D, 8.0D - idx * 0.7D);
                Vec3 back = Util.back(pl);
                double x = pl.getX() + back.x * dist + Rnd.range(-0.6D, 0.6D);
                double z = pl.getZ() + back.z * dist + Rnd.range(-0.6D, 0.6D);
                SoundType type = lv.getBlockState(pl.blockPosition().below()).getSoundType();
                Fx.soundAt(lv, type.getStepSound(), x, pl.getY(), z, 0.9F, 0.85F);
            });
        }
        Scheduler.laterFor(id, 12 + steps * 9 + 20, pl -> {
            Vec3 back = Util.back(pl);
            Fx.soundAt(pl.serverLevel(), ModSounds.BREATH.get(), pl.getX() + back.x * 1.6D, pl.getY() + 1.0D,
                    pl.getZ() + back.z * 1.6D, 1.2F, 1.0F);
        });
        tension(pr, 4.0F);
        return true;
    }

    /** Una porta si apre da sola (e si richiude), oppure si sente scricchiolare alle spalle. */
    public static boolean door(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        BlockPos c = p.blockPosition();
        List<BlockPos> doors = new ArrayList<>();
        for (BlockPos q : BlockPos.betweenClosed(c.offset(-14, -3, -14), c.offset(14, 3, 14))) {
            BlockState s = level.getBlockState(q);
            if (s.is(BlockTags.WOODEN_DOORS) && s.hasProperty(DoorBlock.OPEN) && !s.getValue(DoorBlock.OPEN)
                    && s.getValue(DoorBlock.HALF) == DoubleBlockHalf.LOWER && q.distSqr(c) > 25.0D) {
                doors.add(q.immutable());
            }
        }
        if (doors.isEmpty()) {
            Vec3 back = Util.back(p);
            double x = p.getX() + back.x * 6.0D;
            double z = p.getZ() + back.z * 6.0D;
            Fx.soundAt(level, ModSounds.DOOR_CREAK.get(), x, p.getY() + 1.0D, z, 1.0F, 1.0F);
            Fx.soundAt(level, SoundEvents.WOODEN_DOOR_OPEN, x, p.getY() + 1.0D, z, 0.9F, 0.9F);
            tension(pr, 3.0F);
            return true;
        }
        final BlockPos pos = Rnd.pick(doors);
        BlockState s = level.getBlockState(pos);
        if (s.getBlock() instanceof DoorBlock db) {
            db.setOpen(null, level, s, pos, true);
            Fx.soundAt(level, ModSounds.DOOR_CREAK.get(), pos.getX() + 0.5D, pos.getY() + 1.0D, pos.getZ() + 0.5D, 0.9F, 1.0F);
            Scheduler.later(Rnd.range(60, 120), () -> {
                BlockState s2 = level.getBlockState(pos);
                if (s2.getBlock() instanceof DoorBlock d2 && s2.hasProperty(DoorBlock.OPEN) && s2.getValue(DoorBlock.OPEN)) {
                    d2.setOpen(null, level, s2, pos, false);
                }
            });
        }
        tension(pr, 3.0F);
        return true;
    }

    /** Tuono lontano con lampo (fulmine solo visivo). */
    public static boolean thunder(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || !level.canSeeSky(p.blockPosition())) return false;
        double ang = Rnd.range(0.0D, Math.PI * 2.0D);
        double dist = Rnd.range(40.0D, 70.0D);
        visualBolt(level, p.getX() + Math.cos(ang) * dist, p.getZ() + Math.sin(ang) * dist);
        Fx.send(p, FxPacket.FLASH, 6, 60);
        tension(pr, 3.0F);
        return true;
    }

    /** Battito del cuore che accelera. */
    public static boolean heartbeat(ServerPlayer p, PlayerProfile pr) {
        int beats = Rnd.range(8, 14);
        int t = 1;
        UUID id = p.getUUID();
        for (int i = 0; i < beats; i++) {
            final float prog = i / (float) beats;
            Scheduler.laterFor(id, t, pl -> Fx.soundSelf(pl, ModSounds.HEARTBEAT.get(), 0.6F + 0.6F * prog, 0.9F + 0.3F * prog));
            t += Math.round(26.0F - 14.0F * prog);
        }
        tension(pr, 4.0F);
        return true;
    }

    /** Eco nelle caverne: lo stesso rumore arriva piu' volte, ritardato e da direzioni diverse. */
    public static boolean caveEcho(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || !Util.underground(level, p.blockPosition())) return false;
        UUID id = p.getUUID();
        int sources = Rnd.range(2, 3);
        for (int s = 0; s < sources; s++) {
            double ang = Rnd.range(0.0D, Math.PI * 2.0D);
            double dist = Rnd.range(8.0D, 22.0D);
            final double ox = Math.cos(ang) * dist;
            final double oz = Math.sin(ang) * dist;
            final int kind = Rnd.range(0, 2);
            for (int k = 0; k < 3; k++) {
                final int kk = k;
                Scheduler.laterFor(id, 10 + s * 30 + k * (8 + 6 * k), pl -> {
                    SoundType type = kind == 0 ? SoundType.STONE : (kind == 1 ? SoundType.DEEPSLATE : SoundType.CHAIN);
                    SoundEvent ev = kind == 2 ? type.getStepSound() : type.getBreakSound();
                    double spread = 1.0D + 0.18D * kk;
                    Fx.soundAt(pl.serverLevel(), ev, pl.getX() + ox * spread, pl.getY(), pl.getZ() + oz * spread,
                            0.9F - 0.3F * kk, 0.8F - 0.07F * kk);
                });
            }
        }
        if (Rnd.chance(0.3D)) Fx.soundSelfAmbient(p, ModSounds.DRONE_CAVE.get(), 0.55F, 1.0F);
        tension(pr, 3.0F);
        return true;
    }

    // =================================================================== apparizioni fisiche

    /** Una figura lontana (collina, albero, imbocco di caverna) che sparisce se la guardi. */
    public static boolean watcher(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st, OmbraData data) {
        if (ShadowDirector.shadowOf(p) != null) return false;
        BlockPos spot = WorldFx.findWatchSpot(p, pr, data);
        if (spot == null) return false;
        ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.WATCH, Rnd.range(500, 1100));
        if (e == null) return false;
        tension(pr, 3.0F);
        return true;
    }

    /** Pedinamento: segue a distanza, sparisce se lo guardi, puo' trasformarsi in inseguimento. */
    public static boolean stalk(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st) {
        if (ShadowDirector.shadowOf(p) != null) return false;
        ServerLevel level = p.serverLevel();
        BlockPos spot = Util.findSpot(level, p.blockPosition(), 24.0D, 32.0D, 24, s -> isBehind(p, s));
        if (spot == null) return false;
        ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.STALK, Rnd.range(1500, 2400));
        if (e == null) return false;
        tension(pr, 4.0F);
        return true;
    }

    /** Inseguimento cinematografico: finisce con la luce, in base, o dopo circa 45 secondi. */
    public static boolean chase(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st) {
        if (ShadowDirector.shadowOf(p) != null) return false;
        ServerLevel level = p.serverLevel();
        BlockPos spot = Util.findSpot(level, p.blockPosition(), 22.0D, 28.0D, 24, s -> isBehind(p, s));
        if (spot == null) return false;
        ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.CHASE, 1100);
        if (e == null) return false;
        Fx.say(p, Dialogue.chaseStart(), true);
        Fx.soundSelf(p, ModSounds.RISER.get(), 0.9F, 1.0F);
        tension(pr, 8.0F);
        return true;
    }

    /** Imboscata nel buio: compare alle spalle, colpisce una volta e si ritira. */
    public static boolean ambush(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st) {
        if (ShadowDirector.shadowOf(p) != null) return false;
        ServerLevel level = p.serverLevel();
        BlockPos spot = Util.findSpot(level, p.blockPosition(), 5.0D, 8.0D, 16,
                s -> isBehind(p, s) && level.getBrightness(LightLayer.BLOCK, s) <= 6);
        if (spot == null) return false;
        ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.AMBUSH, 400);
        if (e == null) return false;
        Fx.soundAt(level, ModSounds.whisper(), spot.getX() + 0.5D, spot.getY() + 1.0D, spot.getZ() + 0.5D, 1.0F, 0.8F);
        tension(pr, 5.0F);
        return true;
    }

    /** Pioggia: la silhouette si vede solo nei lampi, e ogni volta e' piu' vicina. */
    public static boolean rain(ServerPlayer p, PlayerProfile pr, ShadowDirector.State st) {
        ServerLevel level = p.serverLevel();
        if (!level.isRaining() || level.dimension() != Level.OVERWORLD || !level.canSeeSky(p.blockPosition())) return false;
        if (ShadowDirector.shadowOf(p) != null) return false;
        BlockPos spot = Util.findSpot(level, p.blockPosition(), 40.0D, 48.0D, 20, null);
        if (spot == null) return false;
        final ShadowEntity e = ShadowDirector.spawnShadow(p, spot, ShadowEntity.Mode.WATCH, 20 * 60);
        if (e == null) return false;
        e.setScripted(true);
        e.setInvisible(true);
        final UUID id = p.getUUID();
        final int flashes = Rnd.range(4, 6);
        int t = 40;
        for (int i = 0; i < flashes; i++) {
            final int idx = i;
            t += Rnd.range(50, 80);
            Scheduler.laterFor(id, t, pl -> {
                if (!e.isAlive()) return;
                ServerLevel lv = pl.serverLevel();
                double ang = Rnd.range(0.0D, Math.PI * 2.0D);
                visualBolt(lv, pl.getX() + Math.cos(ang) * 45.0D, pl.getZ() + Math.sin(ang) * 45.0D);
                Fx.send(pl, FxPacket.FLASH, 6, 70);
                double d = Math.max(9.0D, 44.0D - idx * 7.0D);
                BlockPos nb = Util.findSpot(lv, pl.blockPosition(), d - 2.0D, d + 2.0D, 12, null);
                if (nb != null) {
                    e.moveTo(nb.getX() + 0.5D, nb.getY(), nb.getZ() + 0.5D, e.getYRot(), 0.0F);
                    e.faceOwner();
                    e.setInvisible(false);
                    Scheduler.later(14, () -> {
                        if (e.isAlive()) e.setInvisible(true);
                    });
                }
                if (idx == flashes - 1) {
                    Fx.sayLater(pl, 30, Dialogue.rainLine());
                    Scheduler.later(36, () -> {
                        if (e.isAlive()) {
                            e.setScripted(false);
                            e.setInvisible(false);
                            e.vanish(true);
                        }
                    });
                }
            });
        }
        tension(pr, 5.0F);
        return true;
    }

    // =================================================================== atmosfera e finti errori

    public static boolean torches(ServerPlayer p, PlayerProfile pr) {
        if (!OmbraConfig.TORCH_EVENTS.get()) return false;
        int n = WorldFx.extinguishTorches(p.serverLevel(), p.blockPosition(), 14, Rnd.range(4, 9), Rnd.range(300, 700));
        if (n == 0) return false;
        Fx.soundSelf(p, ModSounds.whisper(), 0.6F, 0.9F);
        if (Rnd.chance(0.5D)) Fx.sayLater(p, 40, Rnd.of("Che peccato. La luce si è stancata.", "Chi ha spento le torce?"));
        tension(pr, 4.0F);
        return true;
    }

    /** Impronte e particelle scure: una presenza vicina, senza rivelarne la posizione esatta. */
    public static boolean signs(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        boolean cave = Util.underground(level, p.blockPosition());
        double ang = Rnd.range(0.0D, Math.PI * 2.0D);
        final Vec3 start = new Vec3(p.getX() + Math.cos(ang) * 22.0D, p.getY(), p.getZ() + Math.sin(ang) * 22.0D);
        final Vec3 end = new Vec3(p.getX() + Math.cos(ang) * 9.0D, p.getY(), p.getZ() + Math.sin(ang) * 9.0D);
        final int n = 14;
        for (int i = 0; i <= n; i++) {
            final int idx = i;
            Scheduler.later(2 + i * 6, () -> {
                double f = idx / (double) n;
                double x = start.x + (end.x - start.x) * f;
                double z = start.z + (end.z - start.z) * f;
                double y = cave ? start.y : level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, Mth.floor(x), Mth.floor(z));
                double side = (idx % 2 == 0 ? 0.25D : -0.25D);
                level.sendParticles(ParticleTypes.SQUID_INK, x + side, y + 0.1D, z - side, 3, 0.1D, 0.0D, 0.1D, 0.0D);
                if (idx % 4 == 0) level.sendParticles(ParticleTypes.SOUL, x, y + 0.3D, z, 1, 0.1D, 0.2D, 0.1D, 0.01D);
            });
        }
        if (pr.hasBase && Rnd.chance(0.3D)) Fx.sayLater(p, 60, Dialogue.territorialLine());
        tension(pr, 3.0F);
        return true;
    }

    /** Finto "Ombra e' entrato nel gioco" (e dopo un po' "ha lasciato la partita"). */
    public static boolean fakeJoin(ServerPlayer p, PlayerProfile pr) {
        if (!OmbraConfig.CHAT_ENABLED.get()) return false;
        final String name = OmbraConfig.CHAT_NAME.get();
        p.sendSystemMessage(Component.translatable("multiplayer.player.joined", name).withStyle(ChatFormatting.YELLOW));
        UUID id = p.getUUID();
        Scheduler.laterFor(id, Rnd.range(60, 140), pl -> Fx.say(pl, Rnd.of("Ciao.", "Eccomi.", "Sono entrato."), true));
        Scheduler.laterFor(id, Rnd.range(300, 500), pl ->
                pl.sendSystemMessage(Component.translatable("multiplayer.player.left", name).withStyle(ChatFormatting.YELLOW)));
        tension(pr, 4.0F);
        return true;
    }

    /** Il buio si chiude: bordi neri che avanzano, effetto oscurita' e un sussurro. */
    public static boolean darkness(ServerPlayer p, PlayerProfile pr) {
        Fx.send(p, FxPacket.CLOSE, 100, 80);
        p.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 140, 0, false, false));
        Fx.soundSelf(p, ModSounds.whisper(), 0.9F, 0.9F);
        if (Rnd.chance(0.5D)) Fx.sayLater(p, 60, Rnd.of("Non c'è più luce.", "Il buio si chiude. Lo senti?"));
        tension(pr, 4.0F);
        return true;
    }

    /** Cielo anomalo: nebbia e velo rossi, tuono e un drone minaccioso. */
    public static boolean sky(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        if (level.dimension() != Level.OVERWORLD || !level.canSeeSky(p.blockPosition())) return false;
        Fx.send(p, FxPacket.RED_SKY, 20 * Rnd.range(25, 45), 70);
        Fx.soundSelfAmbient(p, ModSounds.DRONE_SKY.get(), 0.6F, 1.0F);
        double ang = Rnd.range(0.0D, Math.PI * 2.0D);
        visualBolt(level, p.getX() + Math.cos(ang) * 60.0D, p.getZ() + Math.sin(ang) * 60.0D);
        Fx.action(p, "§4Il cielo non è più lo stesso.");
        tension(pr, 5.0F);
        return true;
    }

    /** Falsi errori visivi: solo overlay e testo, nessun file toccato, nessun crash. */
    public static boolean glitch(ServerPlayer p, PlayerProfile pr) {
        Fx.send(p, FxPacket.GLITCH, 80, 60);
        Fx.soundSelf(p, ModSounds.GLITCH.get(), 0.7F, 1.0F);
        if (Rnd.chance(0.5D)) Fx.say(p, Fx.corrupt("ti sto guardando"), true);
        tension(pr, 2.0F);
        return true;
    }

    public static boolean fakeError(ServerPlayer p, PlayerProfile pr) {
        if (!OmbraConfig.CHAT_ENABLED.get()) return false;
        String[] lines = Dialogue.fakeError();
        Fx.raw(p, lines[0]);
        Fx.soundSelf(p, ModSounds.STATIC.get(), 0.6F, 1.0F);
        Fx.send(p, FxPacket.GLITCH, 40, 40);
        Scheduler.laterFor(p.getUUID(), 24, pl -> Fx.raw(pl, lines[1]));
        tension(pr, 3.0F);
        return true;
    }

    /** Isolamento: il mondo tace, la musica si interrompe e l'Ombra ti fa credere di essere solo. */
    public static boolean isolation(ServerPlayer p, PlayerProfile pr) {
        int dur = 20 * Rnd.range(45, 75);
        Fx.send(p, FxPacket.ISOLATION, dur, 0);
        Fx.soundSelfAmbient(p, ModSounds.DRONE_ISOLATION.get(), 0.8F, 1.0F);
        UUID id = p.getUUID();
        Scheduler.laterFor(id, 200, pl -> Fx.say(pl, Dialogue.isolation(), true));
        Scheduler.laterFor(id, Math.max(260, dur - 40), pl -> Fx.say(pl, Dialogue.isolationEnd(), true));
        tension(pr, 6.0F);
        return true;
    }

    /** Animali terrorizzati: fuggono o fissano un punto vuoto emettendo versi alterati. */
    public static boolean animals(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        List<Animal> list = new ArrayList<>(level.getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(26.0D, 10.0D, 26.0D)));
        if (list.isEmpty()) return false;
        Collections.shuffle(list);
        final List<Animal> chosen = new ArrayList<>(list.subList(0, Math.min(list.size(), 8)));
        double ang = Rnd.range(0.0D, Math.PI * 2.0D);
        final Vec3 scare = new Vec3(p.getX() + Math.cos(ang) * 14.0D, p.getY(), p.getZ() + Math.sin(ang) * 14.0D);
        final boolean flee = Rnd.coin();
        for (Animal a : chosen) {
            level.playSound(null, a.getX(), a.getY(), a.getZ(), animalSound(a), SoundSource.NEUTRAL, 1.2F, 0.5F);
            if (flee) {
                Vec3 away = a.position().subtract(scare);
                if (away.lengthSqr() < 1.0E-4D) away = new Vec3(1.0D, 0.0D, 0.0D);
                away = away.normalize().scale(14.0D);
                a.getNavigation().moveTo(a.getX() + away.x, a.getY(), a.getZ() + away.z, 1.6D);
            } else {
                a.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 140, 9, false, false));
            }
        }
        if (!flee) {
            for (int k = 0; k < 28; k++) {
                Scheduler.later(2 + k * 5, () -> {
                    for (Animal an : chosen) {
                        if (an.isAlive()) an.getLookControl().setLookAt(scare.x, scare.y + 1.6D, scare.z);
                    }
                });
            }
        }
        tension(pr, 3.0F);
        return true;
    }

    /** Villaggio silenzioso: i villager restano immobili a fissarti e per un po' non si sentono piu'. */
    public static boolean villagers(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        final List<AbstractVillager> list = new ArrayList<>(level.getEntitiesOfClass(AbstractVillager.class,
                p.getBoundingBox().inflate(48.0D, 20.0D, 48.0D)));
        if (list.isEmpty()) return false;
        int dur = Rnd.range(500, 900);
        for (AbstractVillager v : list) {
            v.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, dur, 9, false, false));
            v.getNavigation().stop();
        }
        for (int k = 0; k < 24; k++) {
            Scheduler.later(2 + k * 5, () -> {
                for (AbstractVillager vv : list) {
                    if (vv.isAlive()) vv.getLookControl().setLookAt(p, 30.0F, 30.0F);
                }
            });
        }
        Fx.send(p, FxPacket.VILLAGE_SILENCE, dur, 0);
        Fx.sayLater(p, 100, Dialogue.villageLine());
        tension(pr, 4.0F);
        return true;
    }

    // =================================================================== modifiche al mondo

    public static boolean trees(ServerPlayer p, PlayerProfile pr, OmbraData data) {
        if (!OmbraConfig.WORLD_CHANGES.get()) return false;
        if (!WorldFx.corruptTree(p, p.serverLevel(), data)) return false;
        tension(pr, 3.0F);
        return true;
    }

    /** Stanze/altari/tunnel sotterranei: solo in roccia naturale, lontano dalle costruzioni del giocatore. */
    public static boolean structure(ServerPlayer p, PlayerProfile pr, OmbraData data, WorldFx.Kind kind) {
        if (!OmbraConfig.STRUCTURES.get()) return false;
        ServerLevel level = p.serverLevel();
        if (!Util.underground(level, p.blockPosition())) return false;
        if (kind == WorldFx.Kind.MEMORY) {
            int open = 0;
            for (OmbraData.RoomEntry r : data.rooms) {
                if (r.kind == WorldFx.Kind.MEMORY.ordinal() && !r.done) open++;
            }
            if (open >= 2) return false;
        }
        BlockPos at = WorldFx.carve(p, level, data, kind);
        if (at == null) return false;
        tension(pr, 3.0F);
        return true;
    }

    /** Oggetti misteriosi: pagine strappate, frammenti neri, simboli sconosciuti. */
    public static boolean itemDrop(ServerPlayer p, PlayerProfile pr) {
        ServerLevel level = p.serverLevel();
        Vec3 f = Util.front(p);
        BlockPos spot = Util.standableColumn(level, Mth.floor(p.getX() + f.x * 7.0D), p.blockPosition().getY(), Mth.floor(p.getZ() + f.z * 7.0D));
        if (spot == null) spot = Util.findSpot(level, p.blockPosition(), 5.0D, 9.0D, 8, null);
        if (spot == null) return false;
        ItemStack stack;
        int roll = Rnd.range(1, 100);
        if (Clues.remaining(pr) > 0 && roll <= 55) stack = Clues.page();
        else if (roll <= 85) stack = new ItemStack(ModItems.BLACK_SHARD.get());
        else stack = new ItemStack(ModItems.UNKNOWN_SYMBOL.get());
        final BlockPos at = spot;
        ItemEntity ie = new ItemEntity(level, at.getX() + 0.5D, at.getY() + 0.4D, at.getZ() + 0.5D, stack);
        level.addFreshEntity(ie);
        for (int k = 0; k < 10; k++) {
            Scheduler.later(5 + k * 20, () ->
                    level.sendParticles(ParticleTypes.SOUL, at.getX() + 0.5D, at.getY() + 0.6D, at.getZ() + 0.5D, 3, 0.15D, 0.3D, 0.15D, 0.01D));
        }
        if (Rnd.chance(0.5D)) Fx.sayLater(p, 50, Rnd.of("Ho perso qualcosa lungo la strada. Raccoglilo.", "Un regalo. O un'esca."));
        tension(pr, 2.0F);
        return true;
    }

    // =================================================================== jumpscare (raro, configurabile)

    /**
     * Crescendo (riser + glitch) e poi: schermo che trema, titolo disturbato, urlo e volto a schermo.
     * Livello (config jumpscareLevel): 1 = suono + titolo, 2 = + schermo che trema, 3 = + volto e accecamento.
     */
    public static boolean jumpscare(ServerPlayer p, PlayerProfile pr) {
        final int lvl = OmbraConfig.JUMPSCARE_LEVEL.get();
        if (lvl <= 0 || pr.seconds < pr.jumpscareReadyAt) return false;
        pr.jumpscareReadyAt = pr.seconds + OmbraConfig.JUMPSCARE_COOLDOWN_MIN.get() * 60L + Rnd.range(0, 300);
        UUID id = p.getUUID();
        Fx.send(p, FxPacket.GLITCH, 60, 40);
        Fx.soundSelf(p, ModSounds.RISER.get(), 0.9F, 1.0F);
        Scheduler.laterFor(id, 70, pl -> {
            ServerLevel lv = pl.serverLevel();
            Vec3 f = Util.front(pl);
            BlockPos spot = Util.standableColumn(lv, Mth.floor(pl.getX() + f.x * 3.5D), pl.blockPosition().getY(),
                    Mth.floor(pl.getZ() + f.z * 3.5D));
            if (spot != null && ShadowDirector.shadowOf(pl) == null) {
                ShadowEntity e = ShadowDirector.spawnShadow(pl, spot, ShadowEntity.Mode.WATCH, 60);
                if (e != null) {
                    e.setScripted(true);
                    e.faceOwner();
                    Scheduler.later(26, () -> {
                        if (e.isAlive()) e.vanish(true);
                    });
                }
            }
            Fx.soundSelf(pl, ModSounds.SCREAM.get(), 1.0F, 1.0F);
            if (lvl >= 2) Fx.send(pl, FxPacket.SHAKE, 40, 100);
            Fx.send(pl, FxPacket.JUMPSCARE, 30, Rnd.range(0, 2), lvl);
            Fx.glitchTitle(pl, Dialogue.jumpTitle());
            if (lvl >= 3) pl.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 25, 0, false, false));
            PlayerProfile pr2 = ShadowDirector.profile(pl);
            pr2.tension = Math.min(100.0F, pr2.tension + 12.0F);
        });
        return true;
    }

    // =================================================================== stanze nascoste: cosa succede quando ci entri

    public static void roomTrigger(ServerPlayer p, PlayerProfile pr, OmbraData data) {
        if (data.rooms.isEmpty()) return;
        String dim = Util.dimId(p.level());
        BlockPos pos = p.blockPosition();
        for (OmbraData.RoomEntry r : data.rooms) {
            if (r.done || !r.dim.equals(dim)) continue;
            if (Math.abs(r.x - pos.getX()) > 3 || Math.abs(r.z - pos.getZ()) > 3 || Math.abs(r.y - pos.getY()) > 3) continue;
            r.done = true;
            data.setDirty();
            enterRoom(p, pr, r);
            return;
        }
    }

    private static void enterRoom(ServerPlayer p, PlayerProfile pr, OmbraData.RoomEntry r) {
        WorldFx.Kind[] kinds = WorldFx.Kind.values();
        WorldFx.Kind kind = kinds[Math.max(0, Math.min(kinds.length - 1, r.kind))];
        tension(pr, 8.0F);
        switch (kind) {
            case MEMORY -> {
                Fx.soundSelfAmbient(p, ModSounds.DRONE_MEMORY.get(), 0.7F, 1.0F);
                Fx.send(p, FxPacket.GLITCH, 70, 50);
                Fx.say(p, Dialogue.roomLine(), true);
                for (int n = 1; n <= 3; n++) {
                    String text = Dialogue.memoryLine(p, pr);
                    if (text != null) Fx.sayLater(p, 70 * n + 30, text);
                }
            }
            case ALTAR -> {
                Fx.soundSelfAmbient(p, ModSounds.DRONE_CAVE.get(), 0.6F, 1.0F);
                Fx.soundSelf(p, ModSounds.BELL.get(), 0.6F, 0.7F);
                Fx.say(p, Rnd.of("Qui qualcuno pregava. Non me.", "Questo altare è più vecchio di me. E io sono molto vecchio."), true);
            }
            case ROOM -> {
                Fx.soundSelfAmbient(p, ModSounds.DRONE_CAVE.get(), 0.6F, 1.0F);
                Fx.say(p, Dialogue.tunnelLine(), true);
            }
            default -> {
                Fx.soundSelf(p, ModSounds.DOOR_CREAK.get(), 0.7F, 0.8F);
                Fx.say(p, Dialogue.tunnelLine(), true);
            }
        }
    }
}
