package com.gamernoob.ombra.story;

import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.util.Rnd;

/** Le quattro "personalita'" dell'Ombra: cambiano ogni qualche minuto, senza schema fisso. */
public enum Personality {
    SILENT, TAUNTING, AGGRESSIVE, FRIENDLY;

    public static Personality of(int ordinal) {
        Personality[] v = values();
        return v[Math.max(0, Math.min(v.length - 1, ordinal))];
    }

    public static Personality of(PlayerProfile pr) {
        return of(pr.personality);
    }

    /** Sceglie una nuova personalita' pesando fase, rabbia e finta amicizia. */
    public static void rotate(PlayerProfile pr) {
        if (pr.seconds < pr.personalityUntil) return;
        double wSilent = 3.0;
        double wTaunt = 3.5;
        double wAggr = 1.0 + pr.anger / 25.0 + pr.level() / 3.0 + (pr.nightmare ? 2.0 : 0.0);
        double wFriend = (!pr.friendlyDone && pr.level() <= 2) ? 5.0 : (pr.level() <= 3 ? 0.6 : 0.0);
        double total = wSilent + wTaunt + wAggr + wFriend;
        double r = Rnd.range(0.0, total);
        Personality chosen;
        if ((r -= wSilent) < 0) chosen = SILENT;
        else if ((r -= wTaunt) < 0) chosen = TAUNTING;
        else if ((r -= wAggr) < 0) chosen = AGGRESSIVE;
        else chosen = FRIENDLY;
        pr.personality = chosen.ordinal();
        pr.personalityUntil = pr.seconds + Rnd.range(240, 540);
    }
}
