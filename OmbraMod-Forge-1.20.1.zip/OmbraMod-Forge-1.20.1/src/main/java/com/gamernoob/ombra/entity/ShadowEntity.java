package com.gamernoob.ombra.entity;

import com.gamernoob.ombra.OmbraMod;
import com.gamernoob.ombra.config.OmbraConfig;
import com.gamernoob.ombra.data.PlayerProfile;
import com.gamernoob.ombra.director.Fx;
import com.gamernoob.ombra.director.ShadowDirector;
import com.gamernoob.ombra.director.WorldFx;
import com.gamernoob.ombra.net.FxPacket;
import com.gamernoob.ombra.registry.ModItems;
import com.gamernoob.ombra.registry.ModSounds;
import com.gamernoob.ombra.story.Clues;
import com.gamernoob.ombra.story.Dialogue;
import com.gamernoob.ombra.story.Personality;
import com.gamernoob.ombra.util.Rnd;
import com.gamernoob.ombra.util.Util;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LightLayer;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.UUID;

/**
 * L'Ombra. Non e' un mob qualunque: osserva, insegue, tende imboscate, sparisce se la guardi.
 * Solo la spada di netherite (logica reale, non solo messaggi) puo' ucciderla davvero.
 */
public class ShadowEntity extends Monster {

    /** Gli "stati d'animo" dell'IA: l'Ombra alterna osservazione, pedinamento, inseguimento, imboscata e ritirata. */
    public enum Mode { WATCH, STALK, CHASE, AMBUSH, RETREAT, DUEL, FAKE_DEAD }

    public static final int F_TELEGRAPH = 1;
    public static final int F_VULNERABLE = 2;
    public static final int F_TILT = 4;
    public static final int F_FAKE_DEAD = 8;

    private static final EntityDataAccessor<Integer> DATA_FLAGS =
            SynchedEntityData.defineId(ShadowEntity.class, EntityDataSerializers.INT);

    private final ServerBossEvent bossBar = new ServerBossEvent(Component.translatable("entity.ombra.shadow"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);

    private UUID ownerId;
    private Mode mode = Mode.WATCH;
    private int modeTicks;
    private int lifeTicks;
    private int maxLife = 1200;
    private int gazeTicks;
    private int frozenTicks;
    private int attackCooldown;
    private int teleportCooldown = 100;
    private int vulnTicks;
    private int telegraphTicks;
    private int safeTicks;
    private int phase = 1;
    private int announcedPhase = 1;
    private int slamCooldown = 160;
    private int darkCooldown = 300;
    private int fakeDeadTicks;
    private boolean fakeDeathUsed;
    private boolean enraged;
    private boolean scripted;
    private boolean nightmare;
    private long lastIneffective;
    private UUID legitKillBy;

    public ShadowEntity(EntityType<? extends ShadowEntity> type, Level level) {
        super(type, level);
        this.xpReward = 300;
        this.setPersistenceRequired();
        this.bossBar.setVisible(false);
        if (!level.isClientSide()) {
            try {
                double hp = OmbraConfig.SHADOW_HEALTH.get();
                AttributeInstance inst = this.getAttribute(Attributes.MAX_HEALTH);
                if (inst != null) inst.setBaseValue(hp);
                this.setHealth((float) hp);
            } catch (Exception ignored) {
                // configurazione non ancora pronta: restano i valori di default
            }
        }
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 500.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.33D)
                .add(Attributes.ATTACK_DAMAGE, 8.0D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.ARMOR, 6.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_FLAGS, 0);
    }

    // ------------------------------------------------------------------ flag sincronizzati (per il renderer)

    private boolean hasF(int f) {
        return (this.entityData.get(DATA_FLAGS) & f) != 0;
    }

    private void setF(int f, boolean on) {
        int v = this.entityData.get(DATA_FLAGS);
        this.entityData.set(DATA_FLAGS, on ? (v | f) : (v & ~f));
    }

    public boolean isTelegraphing() { return hasF(F_TELEGRAPH); }
    public boolean isVulnerable() { return hasF(F_VULNERABLE); }
    public boolean isTilted() { return hasF(F_TILT); }
    public boolean isFakeDead() { return hasF(F_FAKE_DEAD); }

    // ------------------------------------------------------------------ configurazione dall'esterno

    public void setup(ServerPlayer owner, Mode m, int life, boolean nightmareMode) {
        this.ownerId = owner.getUUID();
        this.mode = m;
        this.maxLife = life;
        this.modeTicks = 0;
        this.nightmare = nightmareMode;
        if (nightmareMode) {
            AttributeInstance hp = this.getAttribute(Attributes.MAX_HEALTH);
            if (hp != null) hp.setBaseValue(hp.getBaseValue() * 1.5D);
            this.setHealth(this.getMaxHealth());
            AttributeInstance dmg = this.getAttribute(Attributes.ATTACK_DAMAGE);
            if (dmg != null) dmg.setBaseValue(dmg.getBaseValue() * 1.4D);
        }
        face(owner);
        if (m == Mode.DUEL) beginDuel();
    }

    public Mode getMode() { return mode; }
    public UUID getOwnerId() { return ownerId; }
    public boolean isScripted() { return scripted; }
    public void setScripted(boolean s) { this.scripted = s; }

    @Nullable
    public ServerPlayer owner() {
        if (ownerId == null || !(level() instanceof ServerLevel sl)) return null;
        return sl.getServer().getPlayerList().getPlayer(ownerId);
    }

    public void faceOwner() {
        ServerPlayer o = owner();
        if (o != null) face(o);
    }

    /** Ricalcola il percorso verso un bersaglio ogni 4 tick (o quando e' finito): molto meno costoso. */
    private void goTo(Entity target, double speed) {
        if (modeTicks % 4 == 0 || getNavigation().isDone()) getNavigation().moveTo(target, speed);
    }

    private void face(Entity e) {
        double dx = e.getX() - getX();
        double dz = e.getZ() - getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0D / Math.PI)) - 90.0F;
        setYRot(yaw);
        setYHeadRot(yaw);
        this.yBodyRot = yaw;
    }

    // ------------------------------------------------------------------ salvataggio

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerId != null) tag.putUUID("OmbraOwner", ownerId);
        tag.putInt("OmbraMode", mode.ordinal());
        tag.putBoolean("OmbraFakeUsed", fakeDeathUsed);
        tag.putBoolean("OmbraNightmare", nightmare);
        tag.putInt("OmbraLife", lifeTicks);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("OmbraOwner")) ownerId = tag.getUUID("OmbraOwner");
        Mode[] all = Mode.values();
        mode = all[Mth.clamp(tag.getInt("OmbraMode"), 0, all.length - 1)];
        fakeDeathUsed = tag.getBoolean("OmbraFakeUsed");
        nightmare = tag.getBoolean("OmbraNightmare");
        lifeTicks = tag.getInt("OmbraLife");
        if (mode == Mode.FAKE_DEAD) mode = Mode.DUEL;
        if (mode == Mode.DUEL) {
            maxLife = 0;
            bossBar.setVisible(true);
        }
    }

    // ------------------------------------------------------------------ boss bar

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        if (mode == Mode.DUEL || mode == Mode.FAKE_DEAD) bossBar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    @Override
    public void remove(Entity.RemovalReason reason) {
        bossBar.removeAllPlayers();
        super.remove(reason);
    }

    // ------------------------------------------------------------------ tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide()) return;
        try {
            serverTick();
        } catch (Exception ex) {
            OmbraMod.LOGGER.error("Errore nell'IA dell'Ombra: l'entita' viene rimossa", ex);
            this.discard();
        }
    }

    private void serverTick() {
        lifeTicks++;
        modeTicks++;
        if (attackCooldown > 0) attackCooldown--;
        if (teleportCooldown > 0) teleportCooldown--;

        if (ownerId == null) {
            // evocata con l'uovo o con /summon: adotta il giocatore piu' vicino e lo pedina
            Player near = level().getNearestPlayer(this, 64.0D);
            if (near instanceof ServerPlayer adopted) {
                ownerId = adopted.getUUID();
                mode = Mode.STALK;
                maxLife = 0;
                lifeTicks = 0;
                modeTicks = 0;
            } else {
                if (lifeTicks > 200) vanish(false);
                return;
            }
        }
        ServerPlayer owner = owner();
        if (owner == null || owner.level() != this.level() || owner.isSpectator() || !owner.isAlive()) {
            if (lifeTicks > 40) vanish(false);
            return;
        }
        double dist = this.distanceTo(owner);
        if (dist > 110.0D) {
            vanish(false);
            return;
        }
        if (mode != Mode.DUEL && mode != Mode.FAKE_DEAD && !scripted && maxLife > 0 && lifeTicks > maxLife) {
            vanish(true);
            return;
        }
        if (frozenTicks > 0) {
            tickFrozen(owner);
            return;
        }
        switch (mode) {
            case WATCH -> tickWatch(owner, dist);
            case STALK -> tickStalk(owner, dist);
            case CHASE -> tickChase(owner, dist);
            case AMBUSH -> tickAmbush(owner, dist);
            case RETREAT -> tickRetreat(owner, dist);
            case DUEL -> tickDuel(owner);
            case FAKE_DEAD -> tickFakeDead(owner);
        }
    }

    // ------------------------------------------------------------------ osservazione e sguardo

    private void tickFrozen(ServerPlayer owner) {
        frozenTicks--;
        getNavigation().stop();
        setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
        face(owner);
        setF(F_TILT, true);
        if (frozenTicks <= 0) {
            setF(F_TILT, false);
            vanish(true);
        }
    }

    private void tickWatch(ServerPlayer owner, double dist) {
        getNavigation().stop();
        face(owner);
        if (scripted) return;
        if (dist < 11.0D) {
            vanish(true);
            return;
        }
        trackGaze(owner, 0.975D);
    }

    private void tickStalk(ServerPlayer owner, double dist) {
        if (dist > 24.0D) {
            goTo(owner, 1.0D);
        } else if (dist < 14.0D) {
            Vec3 away = this.position().subtract(owner.position());
            if (away.lengthSqr() < 1.0E-4D) away = new Vec3(1.0D, 0.0D, 0.0D);
            away = away.normalize().scale(8.0D);
            getNavigation().moveTo(getX() + away.x, getY(), getZ() + away.z, 1.1D);
        } else {
            getNavigation().stop();
        }
        getLookControl().setLookAt(owner, 30.0F, 30.0F);
        trackGaze(owner, 0.96D);
        if (modeTicks == 900) {
            PlayerProfile pr = ShadowDirector.profile(owner);
            if (pr.level() >= 2 && Personality.of(pr) != Personality.FRIENDLY && Rnd.chance(0.55D)) startChase(owner);
        }
    }

    /** Se il giocatore la fissa: si immobilizza inclinando la testa, sparisce o si teletrasporta lontano. */
    private void trackGaze(ServerPlayer owner, double cos) {
        if (Util.looking(owner, this, cos)) {
            gazeTicks++;
            if (gazeTicks >= 16) reactToGaze(owner);
        } else {
            gazeTicks = Math.max(0, gazeTicks - 2);
        }
    }

    private void reactToGaze(ServerPlayer owner) {
        gazeTicks = 0;
        PlayerProfile pr = ShadowDirector.profile(owner);
        int roll = this.random.nextInt(100);
        if (roll < 35) {
            frozenTicks = 40 + this.random.nextInt(30);
            getNavigation().stop();
            if (Rnd.chance(0.4D)) Fx.say(owner, Dialogue.gazeLine());
        } else if (roll < 70) {
            if (Rnd.chance(0.25D)) Fx.say(owner, Dialogue.gazeLine());
            vanish(true);
        } else {
            teleportAway(owner, 34.0D, 56.0D);
        }
        pr.tension = Math.min(100.0F, pr.tension + 2.0F);
    }

    private void teleportAway(ServerPlayer owner, double min, double max) {
        if (!(level() instanceof ServerLevel sl)) return;
        BlockPos spot = Util.findSpot(sl, owner.blockPosition(), min, max, 16, null);
        if (spot == null) {
            vanish(true);
            return;
        }
        puff(sl);
        this.moveTo(spot.getX() + 0.5D, spot.getY(), spot.getZ() + 0.5D, getYRot(), 0.0F);
        getNavigation().stop();
        gazeTicks = 0;
        puff(sl);
    }

    // ------------------------------------------------------------------ inseguimento, imboscata, ritirata

    public void startChase(ServerPlayer owner) {
        mode = Mode.CHASE;
        modeTicks = 0;
        lifeTicks = 0;
        maxLife = 1100;
        safeTicks = 0;
        Fx.say(owner, Dialogue.chaseStart(), true);
        Fx.soundSelf(owner, ModSounds.RISER.get(), 0.9F, 1.0F);
    }

    private double chaseSpeed(ServerPlayer owner) {
        PlayerProfile pr = ShadowDirector.profile(owner);
        double s = 1.15D + 0.12D * Math.min(1.0D, pr.anger / 100.0D) + 0.02D * pr.level() + (nightmare ? 0.15D : 0.0D);
        return Math.min(1.5D, s);
    }

    private void tickChase(ServerPlayer owner, double dist) {
        goTo(owner, chaseSpeed(owner));
        getLookControl().setLookAt(owner, 40.0F, 40.0F);
        if (dist < 2.4D && attackCooldown <= 0) {
            strike(owner, 1.0F);
            attackCooldown = 30;
        }
        chaseAmbience(owner, dist);
        int light = level().getBrightness(LightLayer.BLOCK, owner.blockPosition());
        PlayerProfile pr = ShadowDirector.profile(owner);
        boolean atBase = pr.hasBase && Util.horizontalDist(owner, new BlockPos(pr.baseX, pr.baseY, pr.baseZ)) < 14.0D;
        if (light >= 12 || atBase) safeTicks++;
        else safeTicks = Math.max(0, safeTicks - 1);
        if (safeTicks > 70) {
            endChase(owner);
        } else if (modeTicks > 900) {
            endChase(owner);
        }
    }

    private void endChase(ServerPlayer owner) {
        Fx.say(owner, Dialogue.chaseEnd(), true);
        mode = Mode.RETREAT;
        modeTicks = 0;
    }

    /** Suoni e disturbi visivi progressivi: piu' si avvicina, piu' il battito accelera. */
    private void chaseAmbience(ServerPlayer owner, double dist) {
        if (modeTicks % 20 == 0) {
            float vol = (float) Mth.clamp(1.2D - dist / 30.0D, 0.15D, 1.0D);
            float pitch = (float) Mth.clamp(1.4D - dist / 40.0D, 0.8D, 1.35D);
            Fx.soundSelf(owner, ModSounds.HEARTBEAT.get(), vol, pitch);
        }
        if (dist < 12.0D && modeTicks % 40 == 0) Fx.send(owner, FxPacket.GLITCH, 25, 40);
        if (dist < 6.0D && modeTicks % 30 == 0 && OmbraConfig.SCREEN_SHAKE.get()) Fx.send(owner, FxPacket.SHAKE, 12, 25);
        if (dist < 10.0D && modeTicks % 60 == 0) owner.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 60, 0, false, false));
    }

    private void tickAmbush(ServerPlayer owner, double dist) {
        getLookControl().setLookAt(owner, 60.0F, 60.0F);
        if (modeTicks < 30) {
            getNavigation().stop();
            return;
        }
        goTo(owner, 1.7D);
        if (dist < 2.5D && attackCooldown <= 0) {
            strike(owner, 1.3F);
            Fx.soundSelf(owner, ModSounds.STING.get(), 1.0F, 1.0F);
            if (OmbraConfig.SCREEN_SHAKE.get()) Fx.send(owner, FxPacket.SHAKE, 14, 40);
            mode = Mode.RETREAT;
            modeTicks = 0;
        }
        if (modeTicks > 140) vanish(true);
    }

    private void tickRetreat(ServerPlayer owner, double dist) {
        Vec3 away = this.position().subtract(owner.position());
        if (away.lengthSqr() < 1.0E-4D) away = new Vec3(1.0D, 0.0D, 0.0D);
        away = away.normalize().scale(10.0D);
        getNavigation().moveTo(getX() + away.x, getY(), getZ() + away.z, 1.3D);
        if (modeTicks > 50 || dist > 40.0D) vanish(true);
    }

    private void strike(ServerPlayer target, float mult) {
        this.swing(InteractionHand.MAIN_HAND);
        float dmg = (float) (getAttributeValue(Attributes.ATTACK_DAMAGE) * mult * OmbraConfig.DAMAGE_MULT.get());
        boolean hit = target.hurt(damageSources().mobAttack(this), dmg);
        if (hit) {
            target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 80, 0, false, false));
            target.knockback(0.6D, getX() - target.getX(), getZ() - target.getZ());
        }
    }

    // ------------------------------------------------------------------ scontro finale

    private void beginDuel() {
        mode = Mode.DUEL;
        modeTicks = 0;
        maxLife = 0;
        gazeTicks = 0;
        frozenTicks = 0;
        scripted = false;
        setF(F_TILT, false);
        bossBar.setVisible(true);
        slamCooldown = 140;
        teleportCooldown = 120;
        if (level() instanceof ServerLevel sl) {
            for (ServerPlayer sp : sl.players()) {
                if (sp.distanceToSqr(this) < 48.0D * 48.0D) bossBar.addPlayer(sp);
            }
        }
    }

    private void tickDuel(ServerPlayer owner) {
        Player near = level().getNearestPlayer(this, 40.0D);
        ServerPlayer target = near instanceof ServerPlayer s ? s : owner;
        float frac = getHealth() / getMaxHealth();
        bossBar.setProgress(Mth.clamp(frac, 0.0F, 1.0F));
        phase = frac > 0.66F ? 1 : (frac > 0.33F ? 2 : 3);
        if (phase > announcedPhase) {
            announcedPhase = phase;
            Fx.say(owner, Dialogue.duelPhase(phase), true);
            if (OmbraConfig.SCREEN_SHAKE.get()) Fx.send(owner, FxPacket.SHAKE, 16, 40);
        }
        double dist = this.distanceTo(target);
        getLookControl().setLookAt(target, 40.0F, 40.0F);

        if (vulnTicks > 0) {
            vulnTicks--;
            if (vulnTicks % 8 == 0 && level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.END_ROD, getX(), getY() + 1.2D, getZ(), 4, 0.3D, 0.6D, 0.3D, 0.02D);
            }
            if (vulnTicks == 0) setF(F_VULNERABLE, false);
        }
        if (telegraphTicks > 0) {
            telegraphTicks--;
            getNavigation().stop();
            if (telegraphTicks == 0) {
                setF(F_TELEGRAPH, false);
                doSlam();
            }
            return;
        }

        double speed = (vulnTicks > 0 ? 0.55D : 1.05D + 0.12D * phase) * (enraged ? 1.15D : 1.0D);
        goTo(target, speed);

        if (dist < 2.6D && attackCooldown <= 0 && vulnTicks <= 0) {
            strike(target, 1.0F + 0.15F * phase);
            attackCooldown = Math.max(14, 34 - phase * 6);
        }
        if (slamCooldown > 0) slamCooldown--;
        else if (dist < 9.0D && vulnTicks <= 0) startTelegraph();

        if (teleportCooldown <= 0 && dist > 7.0D && vulnTicks <= 0) {
            tacticalTeleport(target);
            teleportCooldown = 220 - phase * 30 + this.random.nextInt(60);
        }
        if (phase >= 2) {
            if (darkCooldown > 0) darkCooldown--;
            else {
                darkPulse(target);
                darkCooldown = 360;
            }
        }
    }

    /** Gli attacchi piu' potenti sono preceduti da un rumore profondo e da occhi rossi. */
    private void startTelegraph() {
        telegraphTicks = 26;
        setF(F_TELEGRAPH, true);
        getNavigation().stop();
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.RUMBLE.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
        }
    }

    private void doSlam() {
        if (!(level() instanceof ServerLevel sl)) return;
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.THUMP.get(), SoundSource.HOSTILE, 2.5F, 0.8F);
        sl.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3D, getZ(), 5, 1.6D, 0.1D, 1.6D, 0.0D);
        sl.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 0.2D, getZ(), 70, 2.4D, 0.2D, 2.4D, 0.12D);
        float dmg = (float) (getAttributeValue(Attributes.ATTACK_DAMAGE) * 1.25D * OmbraConfig.DAMAGE_MULT.get());
        for (ServerPlayer p : sl.getEntitiesOfClass(ServerPlayer.class, getBoundingBox().inflate(5.0D, 2.0D, 5.0D))) {
            p.hurt(damageSources().mobAttack(this), dmg);
            p.knockback(1.0D, getX() - p.getX(), getZ() - p.getZ());
            if (OmbraConfig.SCREEN_SHAKE.get()) Fx.send(p, FxPacket.SHAKE, 16, 55);
        }
        WorldFx.lingeringTraces(sl, blockPosition(), 8);
        // dopo l'attacco potente l'Ombra e' lenta e vulnerabile: la finestra per colpirla
        vulnTicks = phase >= 3 ? 80 : 110;
        setF(F_VULNERABLE, true);
        slamCooldown = 260 - 35 * phase + this.random.nextInt(60);
        ServerPlayer o = owner();
        if (o != null) Fx.action(o, "§bL'Ombra è vulnerabile: colpiscila ora!");
    }

    private void tacticalTeleport(ServerPlayer target) {
        if (!(level() instanceof ServerLevel sl)) return;
        Vec3 b = Util.back(target);
        int bx = Mth.floor(target.getX() + b.x * 4.5D);
        int bz = Mth.floor(target.getZ() + b.z * 4.5D);
        BlockPos spot = Util.standableColumn(sl, bx, target.blockPosition().getY(), bz);
        if (spot == null) spot = Util.findSpot(sl, target.blockPosition(), 4.0D, 8.0D, 10, null);
        if (spot == null) return;
        puff(sl);
        this.moveTo(spot.getX() + 0.5D, spot.getY(), spot.getZ() + 0.5D, getYRot(), 0.0F);
        face(target);
        sl.playSound(null, getX(), getY(), getZ(), ModSounds.TELEPORT.get(), SoundSource.HOSTILE, 1.2F, 1.0F);
        puff(sl);
    }

    private void darkPulse(ServerPlayer target) {
        target.addEffect(new MobEffectInstance(MobEffects.DARKNESS, 120, 0, false, false));
        if (OmbraConfig.TORCH_EVENTS.get() && level() instanceof ServerLevel sl) {
            WorldFx.extinguishTorches(sl, blockPosition(), 12, 8, 400);
        }
        if (OmbraConfig.VISUAL_GLITCHES.get()) Fx.send(target, FxPacket.CLOSE, 50, 60);
    }

    // ------------------------------------------------------------------ falsa sconfitta

    private void startFakeDeath() {
        fakeDeathUsed = true;
        mode = Mode.FAKE_DEAD;
        modeTicks = 0;
        fakeDeadTicks = 110 + this.random.nextInt(60);
        setF(F_FAKE_DEAD, true);
        setF(F_VULNERABLE, false);
        setF(F_TELEGRAPH, false);
        vulnTicks = 0;
        telegraphTicks = 0;
        getNavigation().stop();
        if (level() instanceof ServerLevel sl) {
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.SHADOW_DEATH.get(), SoundSource.HOSTILE, 2.0F, 1.0F);
        }
        ServerPlayer o = owner();
        if (o != null) Fx.say(o, Dialogue.fakeDeath(), true);
    }

    private void tickFakeDead(ServerPlayer owner) {
        getNavigation().stop();
        setDeltaMovement(0.0D, getDeltaMovement().y, 0.0D);
        bossBar.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0.0F, 1.0F));
        if (modeTicks > fakeDeadTicks) wakeFromFakeDeath(owner);
    }

    /** L'unica imboscata finale: rialzarsi accanto al giocatore e colpire. */
    private void wakeFromFakeDeath(ServerPlayer target) {
        setF(F_FAKE_DEAD, false);
        mode = Mode.DUEL;
        modeTicks = 0;
        enraged = true;
        teleportCooldown = 140;
        slamCooldown = 110;
        tacticalTeleport(target);
        strike(target, 1.8F);
        Fx.say(target, Dialogue.ambushAfterFake(), true);
        Fx.soundSelf(target, ModSounds.STING.get(), 1.0F, 0.9F);
        if (OmbraConfig.SCREEN_SHAKE.get()) Fx.send(target, FxPacket.SHAKE, 20, 70);
    }

    // ------------------------------------------------------------------ danni: regola della spada di netherite

    public static boolean isLethalWeapon(Player p) {
        ItemStack w = p.getMainHandItem();
        if (w.is(Items.NETHERITE_SWORD)) return true;
        if (OmbraConfig.ALLOW_STRONG_WEAPONS.get() && !w.isEmpty()) {
            return p.getAttributeValue(Attributes.ATTACK_DAMAGE) > OmbraConfig.STRONG_WEAPON_DAMAGE.get();
        }
        return false;
    }

    @Override
    public boolean hurt(DamageSource src, float amount) {
        if (level().isClientSide()) return false;
        // /kill e il vuoto passano sempre (utile per i test e per non bloccare i server)
        if (src.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return super.hurt(src, amount);

        Entity attacker = src.getEntity();
        if (!(attacker instanceof ServerPlayer player) || src.getDirectEntity() != attacker) {
            // frecce, tridenti lanciati, esplosioni, fuoco, mob...: nessun effetto
            if (attacker instanceof ServerPlayer sp) onIneffective(sp);
            return false;
        }
        if (!isLethalWeapon(player)) {
            onIneffective(player);
            return false;
        }
        if (mode == Mode.FAKE_DEAD) {
            wakeFromFakeDeath(player);
            return false;
        }
        if (mode != Mode.DUEL) {
            beginDuel();
            ServerPlayer o = owner();
            if (o != null) Fx.say(o, Dialogue.duelStart(), true);
        }
        // fuori dalla finestra di vulnerabilita' l'Ombra incassa molto meno
        float dealt = amount * (vulnTicks > 0 ? 1.0F : 0.35F);
        float floor = getMaxHealth() * 0.13F;
        if (!fakeDeathUsed && getHealth() - dealt <= floor) {
            dealt = Math.max(0.0F, getHealth() - floor);
            boolean r = dealt > 0.0F && super.hurt(src, dealt);
            startFakeDeath();
            return r;
        }
        legitKillBy = player.getUUID();
        boolean r = super.hurt(src, dealt);
        legitKillBy = null;
        return r;
    }

    /** Arma non letale: l'Ombra ignora il danno, arretra, ringhia o risponde in chat. */
    private void onIneffective(ServerPlayer sp) {
        long now = level().getGameTime();
        if (now - lastIneffective < 25L) return;
        lastIneffective = now;
        ShadowDirector.addAnger(sp, 6.0F);
        if (!(level() instanceof ServerLevel sl)) return;
        switch (this.random.nextInt(4)) {
            case 0 -> sl.playSound(null, getX(), getY(), getZ(), ModSounds.GROWL.get(), SoundSource.HOSTILE, 1.4F, 0.8F);
            case 1 -> Fx.say(sp, Dialogue.ineffectiveLine(), true);
            case 2 -> {
                if (mode == Mode.WATCH || mode == Mode.STALK) {
                    mode = Mode.RETREAT;
                    modeTicks = 0;
                } else {
                    Vec3 away = this.position().subtract(sp.position());
                    if (away.lengthSqr() > 1.0E-4D) {
                        away = away.normalize().scale(4.0D);
                        getNavigation().moveTo(getX() + away.x, getY(), getZ() + away.z, 1.3D);
                    }
                }
            }
            default -> {
                // ignora del tutto il colpo, immobile
            }
        }
    }

    // ------------------------------------------------------------------ morte reale

    @Override
    public void die(DamageSource source) {
        UUID killer = legitKillBy;
        super.die(source);
        if (killer != null && level() instanceof ServerLevel sl) {
            WorldFx.lingeringTraces(sl, blockPosition(), 25);
            ShadowDirector.onShadowDefeated(sl, this, killer, ownerId);
        }
    }

    @Override
    protected void dropCustomDeathLoot(DamageSource src, int looting, boolean recentlyHit) {
        super.dropCustomDeathLoot(src, looting, recentlyHit);
        if (legitKillBy == null) return;
        this.spawnAtLocation(new ItemStack(ModItems.SHADOW_HEART.get()));
        this.spawnAtLocation(new ItemStack(Items.NETHER_STAR));
        this.spawnAtLocation(new ItemStack(Items.ECHO_SHARD, 3));
        ServerPlayer o = owner();
        if (o != null) {
            PlayerProfile pr = ShadowDirector.profile(o);
            this.spawnAtLocation(Clues.diary(pr, pr.clues == Clues.ALL));
        }
    }

    @Override
    protected void tickDeath() {
        if (level() instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 1.0D, getZ(), 6, 0.4D, 0.9D, 0.4D, 0.04D);
            if (deathTime % 5 == 0) sl.sendParticles(ParticleTypes.SOUL, getX(), getY() + 1.0D, getZ(), 3, 0.3D, 0.8D, 0.3D, 0.03D);
        }
        super.tickDeath();
    }

    // ------------------------------------------------------------------ varie

    public void vanish(boolean fx) {
        if (fx && level() instanceof ServerLevel sl) {
            puff(sl);
            sl.playSound(null, getX(), getY(), getZ(), ModSounds.TELEPORT.get(), SoundSource.HOSTILE, 0.8F, 1.0F);
        }
        this.discard();
    }

    private void puff(ServerLevel sl) {
        sl.sendParticles(ParticleTypes.SQUID_INK, getX(), getY() + 1.0D, getZ(), 30, 0.3D, 0.9D, 0.3D, 0.05D);
        sl.sendParticles(ParticleTypes.SMOKE, getX(), getY() + 1.0D, getZ(), 15, 0.3D, 0.9D, 0.3D, 0.02D);
    }

    @Override
    @Nullable
    protected SoundEvent getAmbientSound() {
        return (mode == Mode.DUEL || mode == Mode.CHASE) ? ModSounds.GROWL.get() : null;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return ModSounds.SHADOW_HURT.get();
    }

    @Override
    @Nullable
    protected SoundEvent getDeathSound() {
        return null;
    }

    public boolean canBeAffected(MobEffectInstance effect) {
        return false;
    }

    public boolean removeWhenFarAway(double distance) {
        return false;
    }

    public boolean shouldDespawnInPeaceful() {
        return false;
    }
}
